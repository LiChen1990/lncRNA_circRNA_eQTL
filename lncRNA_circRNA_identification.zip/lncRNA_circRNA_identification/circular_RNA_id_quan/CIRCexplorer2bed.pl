use strict;
use warnings;

my $file=$ARGV[0] ||"";

open FILE,$file;
while(<FILE>)
{
chomp;
my ($chrom,$start,$end,$strand,$junc_reads)=(split(/\t/,$_))[1-1,2-1,3-1,6-1,13-1];
print join("\t",$chrom,$start,$end,$chrom.":".$start."|".$end,$junc_reads,$strand),"\n";
}
close FILE;

#https://circexplorer2.readthedocs.io/en/latest/modules/annotate/
#chrY	2821949	2829687	circular_RNA/61	0	+	2821949	2821949	0,0,0	2	89,573	0,7165	61	circRNA	ENSG00000067646.12_8	ENST00000383052.5_3	2,3	chrY:2803487-2821949|chrY:2829687-2843135
#chrY	2829114	2829687	circular_RNA/5	0	+	2829114	2829114	0,0,0	1	573	0	5	circRNA	ENSG00000067646.12_8	ENST00000383052.5_3	3	chrY:2822038-2829114|chrY:2829687-2843135
#chrY	4898939	4925500	circular_RNA/1	1	+	4898939	4898939	0,0,0	5	169,132,106,59,571	0,316,1007,1771,25990	1	circRNA	ENSG00000099715.15_14	ENST00000698927.1_1	2,3,4,5,6	chrY:4868646-4898939|chrY:4925500-4966255
#chrY	4899946	4925500	circular_RNA/1	0	+	4899946	4899946	0,0,0	3	106,59,571	0,764,24983	1	circRNA	ENSG00000099715.15_14	ENST00000333703.8_1	2,3,4	chrY:4868646-4899946|chrY:4925500-4966255
#chrY	4899946	4968748	circular_RNA/1	0	+	4899946	4899946	0,0,0	4	106,59,571,2493	0,764,24983,66309	1	circRNA	ENSG00000099715.15_14	ENST00000333703.8_1	2,3,4,5	chrY:4868646-4899946|chrY:4968748-4972384
#
#
#Field	Description
#chrom	Chromosome
#start	Start of circular RNA
#end	End of circular RNA
#name	Circular RNA/Junction reads
#score	Flag of fusion junction realignment
#strand	+ or - for strand
#thickStart	No meaning
#thickEnd	No meaning
#itemRgb	0,0,0
#exonCount	Number of exons
#exonSizes	Exon sizes
#exonOffsets	Exon offsets
#readNumber	Number of junction reads
#circType	Type of circular RNA
#geneName	Name of gene
#isoformName	Name of isoform
#index	Index of exon or intron
#flankIntron	Left intron/Right intron