use strict;
use warnings;


my $file=$ARGV[0] || "";

### here 1 based

open FILE,$file;
while(<FILE>)
{
chomp;
my ($chrom,$start,$end,$name,$score,$strand)=split(/\t/,$_);
#chr1:3277291|3287191
$name=$chrom.":".$start."|".$end;
print join("\t",$chrom,$start,$end,$name,$score,$strand),"\n";

}
close FILE;