use strict;
use warnings;


while(<>)
{
	chomp;
	chomp;
	my ($chrom,$start,$end,$circRNA_name,$reads_num,$strand,$name,$name1)=split(/\t/,$_);
	next if $name eq ".";
	my @list_iso=();
	my @list=split(/\|\|/,$name);
	foreach my $iso (@list)
	{
			my $mRNA_name=$iso;
			$mRNA_name=~/(.*):(.*)/;
			$mRNA_name=$1;
			my @exon_list=split(/,/,$2);
			my @sorted_exon_list=sort {$a=~/(exon|utr)_(\d+)/;	my $num1=$2;	 $b=~/(exon|utr)_(\d+)/;	 my $num2=$2;	 $num1<=> $num2;} @exon_list;
			my $string=join(",",@sorted_exon_list);
			push(@list_iso,$mRNA_name.":".$string);
	}
	print join("\t",$chrom,$start,$end,$circRNA_name,$reads_num,$strand,join("||",@list_iso),$name1),"\n";
}