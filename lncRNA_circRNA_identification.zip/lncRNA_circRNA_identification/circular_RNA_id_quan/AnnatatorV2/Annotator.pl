use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;


###perl  Annotator.pl 200_circv2.txt /home2/cl/compare/all.gff3 5 5 
###perl Annotator.pl  stiChimeric.out.bed.deldup.sorted.bed  /home2/cl/compare/all.gff3 5 5  
###perl Annotator.pl   stiChimeric.out_bed_BackSplice_Count.txt   /home2/cl/compare/all.gff3 5 5  >  run.log
my $backsplice_juction_file=$ARGV[0];
my $gff3_file=$ARGV[1];
#my $genome_fasta=$ARGV[2];
my $left_range=$ARGV[2];
my $right_range=$ARGV[3];
####Final results file in directory results/${name_1}_circRNA.txt-----exonic circRNA
####                                ./intergenic_circRNA.bed ---------intergenic circRNA

#
#===========================Annotator circRNA=====================================
#####Annotate putative blacksplice junction position with bedtools intersect
my ($name_1, $path_1, $suffix_1) = fileparse ($backsplice_juction_file, (".bed",".txt"));	
&command_system(qq(perl  $bin_path/RunMe_no_strand.pl  $backsplice_juction_file $gff3_file ),0);
&command_system(qq(mkdir results),0);
#####filter/fix junction with right/left range
&command_system(qq(perl  $bin_path/Annotate_exonic_circRNA.pl $gff3_file  exonic_circRNA.txt $left_range  $right_range |perl  $bin_path/sort_exon_strand.pl > results/${name_1}_circRNA.txt),0);
&command_system(qq(perl $bin_path/results2res_bed.pl results/${name_1}_circRNA.txt >  results/${name_1}_circRNA.txt.bed),0);
&command_system(qq(perl $bin_path/results2ref_bed.pl results/${name_1}_circRNA.txt >  results/${name_1}_circRNA_ref.txt.bed),0);




sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}

__DATA__
[root@localhost ann]# /home2/cl/compare/new_compare_data/new_method_v2/reads/v3.1/Annotator/ann/bedtools2-2.25.0/bin/closestBed  -a  intergenic_circRNA.bed   -b all_gene.gff3  -t all  -k 2 
/home2/cl/compare/new_compare_data/new_method_v2/reads/v3.1/Annotator/ann/bedtools2-2.25.0/bin/closestBed: line 2: 43537 Segmentation fault      (core dumped) ${0%/*}/bedtools closest "$@"

