use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

##perl  RunMe_no_strand.pl stiChimeric.out.bed.deldup.sorted.bed   /home2/cl/compare/all.gff3 > run.log

my $circRNA_results_bed_file=$ARGV[0];
my $genome_gff3=$ARGV[1];
&command_system(qq(cut -f1-6  $circRNA_results_bed_file >$circRNA_results_bed_file.6.bed),0 );
&command_system(qq(perl $bin_path/bedtools_command_perl_v2_no_strand.pl $genome_gff3  $circRNA_results_bed_file.6.bed),0 );
&command_system(qq(perl  $bin_path/classify_circRNA.pl),0 );
&command_system(qq(perl  $bin_path/annote_circRNA_with_type_infoV2.pl   $circRNA_results_bed_file  exonic_circRNA.txt intergenic_circRNA.bed  UTR_circRNA.txt  intronic_circRNA.list >  final_bed_type_info.6.detail.txt ),0 );


sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}


__DATA__
cut -f1-6  stiChimeric.out.bed.deldup.sorted.bed >stiChimeric.out.bed.deldup.sorted.bed.6.bed
awk '{if($3=="gene")print $0}'  /home2/cl/compare/all.gff3> all_gene.gff3
###intergenic circRNA
bedtools  intersect   -a  stiChimeric.out.bed.deldup.sorted.bed.6.bed -b all_gene.gff3 -v |sort -k1,1 -k2,2n  > intergenic_circRNA.bed 
###genic circRNA
bedtools  intersect   -a  stiChimeric.out.bed.deldup.sorted.bed.6.bed -b all_gene.gff3 -f 1.0 -wa -wb   > UTR_exon_intron_genic_circRNA.bed
[root@localhost ann]# wc -l UTR_exon_intron_genic_circRNA.bed
161 UTR_exon_intron_genic_circRNA.bed
awk '{if($3!="gene" && $3!="CDS" && $3!="mRNA" && $3!="five_prime_UTR" &&$3!="three_prime_UTR" )print $0}'  /home2/cl/compare/all.gff3 > no_cds_no_gene_no_utr.gff3
bedtools  intersect   -a  UTR_exon_intron_genic_circRNA.bed    -b no_cds_no_gene_no_utr.gff3 -wa -wb   >genic_circRNA_tmp.bed
bedtools groupby -i genic_circRNA_tmp.bed  -grp 1-6  -c  24 -o collapse >exon_genic_circRNA_tmp.bed.collapse


###UTR  circRNA
awk '{if($3=="five_prime_UTR" )print $0}' /home2/cl/compare/all.gff3 > five_prime_UTR_gene.gff3
bedtools  intersect -a UTR_exon_intron_genic_circRNA.bed  -b five_prime_UTR_gene.gff3 -f 1.0 -wa -wb >five_prime_UTR_circRNA_tmp.bed
awk '{if($3=="three_prime_UTR" )print $0}' /home2/cl/compare/all.gff3 > three_prime_UTR_gene.gff3
bedtools  intersect -a UTR_exon_intron_genic_circRNA.bed -b three_prime_UTR_gene.gff3 -f 1.0 -wa -wb >three_prime_UTR_circRNA_tmp.bed
bedtools groupby -i five_prime_UTR_circRNA_tmp.bed   -grp 1-6   -c 24  -o collapse >five_prime_UTR_circRNA_tmp.bed.collapse
bedtools groupby -i three_prime_UTR_circRNA_tmp.bed   -grp 1-6  -c 24  -o collapse >three_prime_UTR_circRNA_tmp.bed.collapse

perl  get_circRNA_structure1.pl exon_genic_circRNA_tmp.bed.collapse |  perl process.pl |perl  get_exonic_circRNA.pl >exonic_circRNA.txt



[root@localhost ann]# perl  RunMe_no_strand.pl stiChimeric.out.bed.deldup.sorted.bed   /home2/cl/compare/all.gff3 
cut -f1-6  stiChimeric.out.bed.deldup.sorted.bed >stiChimeric.out.bed.deldup.sorted.bed.6.bed
perl bedtools_command_perl_v2_no_strand.pl /home2/cl/compare/all.gff3  stiChimeric.out.bed.deldup.sorted.bed.6.bed
awk '{if($3=="gene")print $0}'  /home2/cl/compare/all.gff3> all_gene.gff3
bedtools  intersect   -a  stiChimeric.out.bed.deldup.sorted.bed.6.bed -b all_gene.gff3 -v |sort -k1,1 -k2,2n  > intergenic_circRNA.bed 
bedtools  intersect   -a  stiChimeric.out.bed.deldup.sorted.bed.6.bed -b all_gene.gff3 -f 1.0 -wa -wb   > UTR_exon_intron_genic_circRNA.bed
awk '{if($3!="gene" && $3!="CDS" && $3!="mRNA" && $3!="five_prime_UTR" && $3!="three_prime_UTR")print $0}'  /home2/cl/compare/all.gff3 > no_cds_no_gene.gff3
bedtools  intersect   -a  UTR_exon_intron_genic_circRNA.bed    -b no_cds_no_gene.gff3 -wa -wb   >genic_circRNA_tmp.bed
bedtools groupby -i genic_circRNA_tmp.bed  -grp 1-6  -c  24 -o collapse >UTR_exon_genic_circRNA_tmp.bed.collapse
awk '{if($3=="five_prime_UTR" )print $0}' /home2/cl/compare/all.gff3 > five_prime_UTR_gene.gff3
bedtools  intersect -a UTR_exon_intron_genic_circRNA.bed  -b five_prime_UTR_gene.gff3 -f 1.0 -wa -wb >five_prime_UTR_circRNA_tmp.bed
awk '{if($3=="three_prime_UTR" )print $0}' /home2/cl/compare/all.gff3 > three_prime_UTR_gene.gff3
bedtools  intersect -a UTR_exon_intron_genic_circRNA.bed -b three_prime_UTR_gene.gff3 -f 1.0 -wa -wb >three_prime_UTR_circRNA_tmp.bed
bedtools groupby -i five_prime_UTR_circRNA_tmp.bed   -grp 1-6   -c 24  -o collapse >five_prime_UTR_circRNA_tmp.bed.collapse
because there are no results in the file five_prime_UTR_circRNA_tmp.bed ;
Error: The requested file (five_prime_UTR_circRNA_tmp.bed) could not be opened. Exiting!
bedtools groupby -i three_prime_UTR_circRNA_tmp.bed   -grp 1-6  -c 24  -o collapse >three_prime_UTR_circRNA_tmp.bed.collapse
awk '{print $4}'  five_prime_UTR_circRNA_tmp.bed.collapse >five_prime_UTR_circRNA_tmp.bed.collapse.list
awk '{print $4}' three_prime_UTR_circRNA_tmp.bed.collapse>three_prime_UTR_circRNA_tmp.bed.collapse.list
cat five_prime_UTR_circRNA_tmp.bed.collapse.list  three_prime_UTR_circRNA_tmp.bed.collapse.list >UTR_circRNA.list
awk '{print $4}' UTR_exon_intron_genic_circRNA.bed  >UTR_exon_intron_genic_circRNA.bed.list
awk '{print $4}' UTR_exon_genic_circRNA_tmp.bed.collapse  >UTR_exon_genic_circRNA_tmp.bed.collapse.list
total_num	186
intergenic_circRNA	1
five_UTR_circRNA	0
three_UTR_circRNA	1
UTR_circRNA	1
intronic_circRNA	0
other_circRNA	25
exonic_circRNA	159
perl  classify_circRNA.pl
perl  get_circRNA_structure1.pl UTR_exon_genic_circRNA_tmp.bed.collapse |  perl process.pl |perl  get_exonic_circRNA.pl | perl sort_exon.pl>exonic_circRNA.txt
mkdir exonic_circRNA
mkdir: cannot create directory `exonic_circRNA': File exists
cp exonic_circRNA.txt exonic_circRNA 
cat five_prime_UTR_circRNA_tmp.bed.collapse three_prime_UTR_circRNA_tmp.bed.collapse >UTR_circRNA.txt 
mkdir UTR_circRNA
mkdir: cannot create directory `UTR_circRNA': File exists
cp UTR_circRNA.txt UTR_circRNA 
mkdir intronic_circRNA
mkdir: cannot create directory `intronic_circRNA': File exists
cp intronic_circRNA.list  intronic_circRNA 
mkdir intergenic_circRNA
mkdir: cannot create directory `intergenic_circRNA': File exists
cp intergenic_circRNA.bed  intergenic_circRNA 
perl  annote_circRNA_with_type_info.pl   stiChimeric.out.bed.deldup.sorted.bed  exonic_circRNA.txt intergenic_circRNA.bed  UTR_circRNA.txt  intronic_circRNA.list >  final_bed_type_info.6.txt 
perl  annote_circRNA_with_type_info.pl   stiChimeric.out.bed.deldup.sorted.bed.6.bed  exonic_circRNA.txt intergenic_circRNA.bed  UTR_circRNA.txt  intronic_circRNA.list >  final_bed_type_info.txt 
perl  annote_circRNA_with_type_infoV2.pl   stiChimeric.out.bed.deldup.sorted.bed  exonic_circRNA.txt intergenic_circRNA.bed  UTR_circRNA.txt  intronic_circRNA.list >  final_bed_type_info.6.detail.txt 
[root@localhost ann]# more five_prime_UTR_circRNA_tmp.bed 



