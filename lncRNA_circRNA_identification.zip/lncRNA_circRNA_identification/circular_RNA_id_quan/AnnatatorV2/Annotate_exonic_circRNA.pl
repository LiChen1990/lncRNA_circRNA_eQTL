use strict;
use warnings;
use List::Util qw(max min);



###perl  $0  D:\genome_date\rice\all.gff3    exonic_circRNA.txt
###perl  Annotate_exonic_circRNA.pl  /home2/cl/compare/all.gff3  exonic_circRNA.txt  5 5  > Ann_juc.txt 


my %hash_bed=();
my $gff3_file=$ARGV[0] || 'D:\genome_date\rice\all.gff3';
#my $genome_fasta=$ARGV[1] || 'D:\genome_date\rice\Osativa_204.fa';
my $exonic_circRNA=$ARGV[1] ||'exonic_circRNA.txt';
#my $output_file=$ARGV[2] ||  "output.bed";
my $left_range=$ARGV[2] || 5;
my $right_range=$ARGV[3] || 5;
##'D:\data\circ_rna\os\mapsplice\circRNA_annotation_scripts\test_rice\results_out\exonic_circRNA\exonic_circRNA.txt'
#open FILE_OUT,">$output_file";

my %hash_gene=();

open GFF3,$gff3_file;
while(<GFF3>)
{
	chomp;
	my ($chrom,$start,$end,$name,$strand,$type)=(split(/\t/,$_))[1-1,4-1,5-1,9-1,7-1,3-1];
#	if($.==1 or $.==812006 or $.==812007)
#	{
#		next;
#	}
	if($type eq "mRNA")
	{
		$name=~/ID=(.*?);/;
		my $trans=$1;
		$name=~/Parent=(.*)/;
		my $gene=$1;
		$hash_gene{$trans}=$gene;
	}
	
	if($type eq "exon")
	{
		$name=~/ID=(.*?);/;
		$hash_bed{$1}=join("\t",$chrom,$start,$end,$strand);
	}
}
close GFF3;
#my %fasta_hash=&create_hash_($genome_fasta);

open FILE2,$exonic_circRNA;
while(<FILE2>)
{
	chomp;
	my ($chrom,$start,$end,$circRNA_name,$reads_num,$strand,$name)=split(/\t/,$_);
	$start=$start-1;
	next if $name eq ".";
	my @list=split(/\|\|/,$name);
	foreach my $iso (@list)
	{
			my $mRNA_name=$iso;
			$mRNA_name=~/(.*):(.*)/;
			$mRNA_name=$1;
			my @exon_list=split(/,/,$2);
			my $max_exon_pos=0;
			my $min_exon_pos=0;
			my @list_start=();
			my @list_end=();
			my $strand_gene="";
			foreach my $exon_name (sort {$a=~/(exon|utr)_(\d+)/;	my $num1=$2;	 $b=~/(exon|utr)_(\d+)/;	 my $num2=$2;	 $num1<=> $num2;} @exon_list)
			{
				#LOC_Os01g46710.1:exon_5
				my $key=$mRNA_name.":".$exon_name;
				if(exists $hash_bed{$key})
				{
					my ($chrom1,$start1,$end1,$strand1)=split(/\t/,$hash_bed{$key});
					$strand_gene=$strand1;
					if($chrom1 eq $chrom  )
					{
						push(@list_start,$start1);
						push(@list_end,$end1);
		#				if($start1==$start+1 and  $end1==$end)
					}
				}
			}
			my $min_start=min(@list_start);
			my $max_end=max(@list_end);
			if($min_start==$start+1 and  $max_end==$end)
			{
				#Canonical 
				#print join("\t",$min_start,$max_end),"\t",$_,"\n";
			}
				if($min_start==$start+1 and  $max_end>$end)
			{
				#alt_donor
				#print join("\t",$min_start,$max_end),"\t",$_,"\n";
			}
					if($min_start==$start+1 and  $max_end<$end)
			{
				#alt_donor_bigger
				#print join("\t",$min_start,$max_end),"\t",$_,"\n";
			}
				if($min_start<$start+1 and  $max_end==$end)
			{
				#alt_acceptor
				#print join("\t",$min_start,$max_end),"\t",$_,"\n";
			}
					if($min_start>$start+1 and  $max_end==$end)
			{
				#alt_acceptor_smaller
				#print join("\t",$min_start,$max_end),"\t",$_,"\n";
			}
			#Alt_acceptor _alt_donor  
						if($min_start!=$start+1 and  $max_end!=$end)
			{
				#Alt_acceptor _alt_donor
				#print join("\t",$min_start,$max_end),"\t",$_,"\n";
			}
			
				#if(abs($start+1-$min_start)<=$left_range and abs($max_end-$end)<=$right_range and $strand eq $strand_gene)
				if(abs($start+1-$min_start)<=$left_range and abs($max_end-$end)<=$right_range )
			{
								#Alt_acceptor_alt_donor_abs_less_5
								#gene annotation  position $chrom:$min_start-$max_end
								#circRNA jbrowse display position $chrom:$start+1..$end
								#print join("\t",$min_start,$max_end),"\t",$_,"\n";
								my $temp10=$chrom.":".$min_start."..".$max_end;
								my $start11=$start+1;
								my $temp11=$chrom.":".$start11."..".$end;
								if($min_start==$start+1 and  $max_end==$end)
							{
								#Canonical 
								#print join("\t",$min_start,$max_end),"\t",$_,"\n";
								print join("\t",$temp11,$temp10),"\t",join("\t",$chrom,$start,$end,$circRNA_name,$reads_num,$strand_gene,$name),"\t","Canonical","\t",$hash_gene{$mRNA_name},"\n";
							}
								if($min_start==$start+1 and  $max_end!=$end)
							{
								#alt_donor
								#print join("\t",$min_start,$max_end),"\t",$_,"\n";
								print join("\t",$temp11,$temp10),"\t",join("\t",$chrom,$start,$end,$circRNA_name,$reads_num,$strand_gene,$name),"\t","alt_donor","\t",$hash_gene{$mRNA_name},"\n";
							}
								if($min_start!=$start+1 and  $max_end==$end)
							{
								#alt_acceptor
								#print join("\t",$min_start,$max_end),"\t",$_,"\n";
								print join("\t",$temp11,$temp10),"\t",join("\t",$chrom,$start,$end,$circRNA_name,$reads_num,$strand_gene,$name),"\t","Alt_acceptor","\t",$hash_gene{$mRNA_name},"\n";
							}
							#Alt_acceptor _alt_donor  
										if($min_start!=$start+1 and  $max_end!=$end)
							{
								#Alt_acceptor _alt_donor
								#print join("\t",$min_start,$max_end),"\t",$_,"\n";
								print join("\t",$temp11,$temp10),"\t",join("\t",$chrom,$start,$end,$circRNA_name,$reads_num,$strand_gene,$name),"\t","Alt_acceptor,Alt_donor","\t",$hash_gene{$mRNA_name},"\n";
							}
								#print FILE_OUT $_,"\t",join("\t",$temp11,$temp10),"\n";
								last;
			}
			else 
			{
				   my $start11=$start+1;
					my  $temp11=$chrom.":".$start11."..".$end;
				   print join("\t",$temp11,"NA"),"\t",join("\t",$chrom,$start,$end,$circRNA_name,$reads_num,$strand_gene,$name),"\t","Out_of_range","\t",$hash_gene{$mRNA_name},"\n";
				   	last;
			}
	
	}
}


sub intsect_bound
{
	my ($start1,$start2,$end1,$end2)=@_;
	my $start=max($start1,$start2);
	my $end=min($end1,$end2);
	return ($start,$end);
}


sub sort_exon
{
	 $a=~/exon_(\d+)/;	my $num1=$1;	 $b=~/exon_(\d+)/;	 my $num2=$2;	 $num1<=> $num2;
}


sub create_hash_
{
	my ($file)=@_;
	my %hash=();
	open FILE, $file;
	my $title;
	while(<FILE>)
	{
		chomp;
		if(/>(.*)/)
		{
			$title=$1;
		}
		else
		{
			$hash{$title}.=$_;
		}
	}
	close FILE;
	return %hash;
}

sub get_genome_seq_return
{
	my($genome_hash,$id,$strand,$start,$end,$fasta_title)=@_;
	if(defined($fasta_title))
	{
		if($strand eq "+")
		{
			#print ">",$fasta_title,"\n";
			return substr($$genome_hash{$id},$start-1,$end-$start+1);
		}
		else
		{
			#print ">",$fasta_title,"\n";
			return &reverse_com(substr($$genome_hash{$id},$start-1,$end-$start+1));
		}
  }
  else
  {
		if($strand eq "+")
		{
			#print ">",$id,"_",$start,"_",$end,"_",$strand,"\n";
			return substr($$genome_hash{$id},$start-1,$end-$start+1);
		}
		else
		{
			#print ">",$id,"_",$start,"_",$end,"_",$strand,"\n";
			return &reverse_com(substr($$genome_hash{$id},$start-1,$end-$start+1));
		}  	
  }
}


sub reverse_com
{
	my ($seq)=@_;
	$seq= reverse $seq;
	$seq=~tr/ATCGatcg/TAGCtagc/;
	return $seq;
}