use strict;
use warnings;


my $UTR_exon_file_name=$ARGV[0] || "UTR_exon_genic_circRNA_tmp.bed.collapse";
open FILE,$UTR_exon_file_name;
my $structure_str="";
my $detail_structure="";
my %hash=();
my %hash1=();
while(<FILE>)
{
	chomp;
	my ($str)=(split(/\t/,$_))[7-1];
	my $str1=join("\t",(split(/\t/,$_))[0..5]);
	my @list=split(/,/,$str);
	foreach my $key(@list)
	{
		#ID=LOC_Os01g61814.1:exon_2;Parent=LOC_Os01g61814.1
		#LOC_Os01g61814.1:exon_2,LOC_Os01g61814.1:exon_3||LOC_Os01g61814.2:exon_3
		$key=~/ID=(.*?):(.*?);/;
		my $tmp_str=$1;
		my $tmp_str2=$2;
		if($tmp_str2 =~/exon/)
		{
			$hash1{$tmp_str}.="exon"."-";
		}
		if($tmp_str2=~/utr/)
		{
			$hash1{$tmp_str}.="UTR"."-";
		}
		
		$hash{$tmp_str}.=$tmp_str2.",";
	}
	print $str1,"\t";
	foreach my $key(sort keys %hash)
	{
			print  $key,":",$hash{$key},"||";
	}
	print "\t";
		foreach my $key(sort keys %hash1)
	{
			print  $key,":",$hash1{$key},"||";
	}
  print "\n";
  %hash=();
   %hash1=();
}