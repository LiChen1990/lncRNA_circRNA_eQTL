use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

my $bool_exec=0;
&get_exonic_circRNA();
&get_UTR_circRNA();
&get_intronic_circRNA();
&get_intergenic_circRNA();

sub get_exonic_circRNA
{
	&command_system(qq(perl  $bin_path/get_circRNA_structure1.pl UTR_exon_genic_circRNA_tmp.bed.collapse |  perl $bin_path/process.pl |perl  $bin_path/get_exonic_circRNA.pl | perl $bin_path/sort_exon_no_strand.pl>exonic_circRNA.txt),$bool_exec);
	&command_system(qq(mkdir exonic_circRNA),$bool_exec);
	&command_system(qq(cp exonic_circRNA.txt exonic_circRNA ),$bool_exec);	
}

sub get_UTR_circRNA
{
	&command_system(qq(cat five_prime_UTR_circRNA_tmp.bed.collapse three_prime_UTR_circRNA_tmp.bed.collapse >UTR_circRNA.txt ),$bool_exec);
	&command_system(qq(mkdir UTR_circRNA),$bool_exec);
	&command_system(qq(cp UTR_circRNA.txt UTR_circRNA ),$bool_exec);
}

sub get_intronic_circRNA
{
	my @list1=&load_list_from_file("UTR_exon_intron_genic_circRNA.bed.list");
	my @list2=&load_list_from_file("UTR_exon_genic_circRNA_tmp.bed.collapse.list");
	my @list=&set_A_minus_set_B(\@list1,\@list2);
	&print_list(\@list,"intronic_circRNA.list");
	&command_system(qq(mkdir intronic_circRNA),$bool_exec);
	&command_system(qq(cp intronic_circRNA.list  intronic_circRNA ),$bool_exec);
}

sub get_intergenic_circRNA
{
	&command_system(qq(mkdir intergenic_circRNA),$bool_exec);
	&command_system(qq(cp intergenic_circRNA.bed  intergenic_circRNA ),$bool_exec);
}




sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}

sub print_list
{
	my ($ref_list,$file_name)=@_;
	open FILE11 ,">$file_name";
	foreach ( @$ref_list)
	{
		print FILE11 $_,"\n";
	}
	close FILE11;
}

sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	return @list;
}


sub  set_A_minus_set_B
{
	my ($listA,$listB)=@_;
	my %listB=map{$_=>1} @$listB;
	my @list=grep {!$listB{$_}} @$listA;
	return @list;
}




