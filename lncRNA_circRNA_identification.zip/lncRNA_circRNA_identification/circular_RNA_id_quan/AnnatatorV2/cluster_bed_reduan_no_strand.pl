use strict;
use warnings;

##perl  $0 res_bed.bed   res_bed.bed 0 0 >  ref_res_bed_cluster1.bed
my  $ref_bed=$ARGV[0];
my  $res_bed=$ARGV[1];
my $left_overlap=$ARGV[2];
my $right_overlap=$ARGV[3];


#&bed1_common_bed2_strand('D:\data\circ_rna\os\mapsplice\compare\2_time\rice\find_circ\test_out_SRR1005298_circ_candidates.bed','D:\data\circ_rna\os\mapsplice\compare\2_time\rice\find_circ\test_out_SRR1005298_circ_candidates.bed');
#&bed1_common_bed2_strand('D:\data\circ_rna\os\mapsplice\compare\2_time\rice\circexplorer\SRR1005296_circ.txt','D:\data\circ_rna\os\mapsplice\compare\2_time\rice\find_circ\test_out_SRR1005296_circ_candidates.bed');
&bed1_common_bed2_strand($ref_bed,$res_bed);

sub bed1_common_bed2_strand
{
	my ($bed_file1,$bed_file2)=@_;
	my %hash1=&load_bed_file_strand($bed_file1);
	my %hash2=&load_bed_file_strand($bed_file2);
	#print scalar keys %hash1,"\n";
	#print scalar keys %hash2,"\n";
	foreach my $key1  (keys %hash1)
	{
		foreach my $key2 (keys  %hash2)
		{
			if(&compare_key($key1,$key2,$left_overlap,$right_overlap))
			{
				print $hash1{$key1},"\t\t",$hash2{$key2},"\n";
			}
		}
	}
}


sub compare_key
{
	my ($key1,$key2,$left_gap,$right_gap)=@_;
	my ($chrom1,$start1,$end1)=split(/\t/,$key1);
	my ($chrom2,$start2,$end2)=split(/\t/,$key2);
	if($chrom1 eq $chrom2 )
	{
		if(abs($start1-$start2)<=$left_gap and abs($end1-$end2)<=$right_gap)
		{
			return  1;
		}
	}
	return 0;
}


sub compare_key_exact
{
	my ($key1,$key2)=@_;
	my ($chrom1,$start1,$end1,$strand1)=split(/\t/,$key1);
	my ($chrom2,$start2,$end2,$strand2)=split(/\t/,$key2);
	if($chrom1 eq $chrom2 and $strand1 eq $strand2)
	{
		if(abs($start1-$start2)<=0 and abs($end1-$end2)<=0)
		{
			return  1;
		}
	}
	return 0;
}




sub  load_bed_file_strand
{
	my ($bed_file)=@_;
	open FILE, $bed_file;
	my %hash=();
	while(<FILE>)
	{
		chomp;
		my ($chrom,$start,$end,$strand)=(split(/\t/,$_))[1-1,2-1,3-1];
		my $key=join("\t",$chrom,$start,$end);
		$hash{$key}=$_;
	}
	return %hash;
}


