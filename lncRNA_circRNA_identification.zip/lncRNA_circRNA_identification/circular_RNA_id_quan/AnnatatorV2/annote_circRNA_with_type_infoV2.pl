use strict;
use warnings;


##perl $0 bed_file  exonic_circRNA.txt intergenic_circRNA.bed  UTR_circRNA.txt  intronic_circRNA.list >  final_bed_type_info.txt 
my $all_circRNA_file=$ARGV[0];
my $exonic_circRNA_file=$ARGV[1];
my $intergenic_circRNA_file=$ARGV[2];
my $UTR_circRNA_file=$ARGV[3];
my $intron_circRNA_file=$ARGV[4];

my %hash=();
open FILE ,$exonic_circRNA_file;
while(<FILE>)
{
	chomp;
	my ($name,$str)=(split(/\t/,$_))[4-1,7-1];
	$str=~/(.*?):/;
	my $parent_gene=$1;
	$hash{$name}=join("\t",$parent_gene,$str);
}
close FILE;


my %hash1=();
open FILE1 ,$intergenic_circRNA_file;
while(<FILE1>)
{
	chomp;
	my ($name)=(split(/\t/,$_))[4-1];
	$hash1{$name}=join("\t","-","-");
}
close FILE1;



my %hash2=();
open FILE2 ,$UTR_circRNA_file;
while(<FILE2>)
{
	chomp;
	my ($name,$str)=(split(/\t/,$_))[4-1,7-1];
	$str=~/(.*?):/;
	my $parent_gene=$1;
	$hash2{$name}=join("\t","-","-");
}
close FILE2;

my %hash3=();
open FILE3, $intron_circRNA_file;
while(<FILE3>)
{
	chomp;
	$hash3{$_}=join("\t","-","-");
}
close FILE3;




open FILE4, $all_circRNA_file;
while(<FILE4>)
{
	chomp;
	my ($name)=(split(/\t/,$_))[4-1];
	
	if(exists $hash{$name})
	{
		print "exonic\t$hash{$name}\t",$_,"\n";
		next;

	}
	
		if(exists $hash2{$name})
	{
		print "UTR\t$hash2{$name}\t",$_,"\n";
		next;
	}
	
		
		if(exists $hash1{$name})
	{
		print "intergenic\t$hash1{$name}\t",$_,"\n";
		next;
	}
	
	if(exists $hash3{$name})
	{
		print "intronic\t$hash3{$name}\t",$_,"\n";
		next;
	}
	
	
	
		if((not exists $hash{$name})  and  (not exists $hash1{$name})  and  (not exists $hash2{$name})and  (not exists $hash3{$name}) )
	{
		print "other\t-\t-\t",$_,"\n";
		next;
	}
	
	
	
	
	
	
	


	
	

}