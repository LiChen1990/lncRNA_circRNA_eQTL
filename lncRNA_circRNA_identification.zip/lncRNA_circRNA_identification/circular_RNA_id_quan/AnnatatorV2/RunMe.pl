use strict;
use warnings;

##perl RunMe.pl  all_valid_bed.txt.bed   /home2/cl/compare/all.gff3

my $circRNA_results_bed_file=$ARGV[0];
my $genome_gff3=$ARGV[1];
&command_system(qq(cut -f1-6  $circRNA_results_bed_file >$circRNA_results_bed_file.6.bed),0 );
&command_system(qq(perl bedtools_command_perl_v2_strand.pl $genome_gff3  $circRNA_results_bed_file.6.bed),0 );
&command_system(qq(perl  classify_circRNA.pl),0 );
&command_system(qq(perl  annote_circRNA_with_type_info.pl   $circRNA_results_bed_file  exonic_circRNA.txt intergenic_circRNA.bed  UTR_circRNA.txt  intronic_circRNA.list >  final_bed_type_info.6.txt ),0 );
&command_system(qq(perl  annote_circRNA_with_type_info.pl   $circRNA_results_bed_file.6.bed  exonic_circRNA.txt intergenic_circRNA.bed  UTR_circRNA.txt  intronic_circRNA.list >  final_bed_type_info.txt ),0 );
&command_system(qq(perl  annote_circRNA_with_type_infoV2.pl   $circRNA_results_bed_file  exonic_circRNA.txt intergenic_circRNA.bed  UTR_circRNA.txt  intronic_circRNA.list >  final_bed_type_info.6.detail.txt ),0 );


sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}
