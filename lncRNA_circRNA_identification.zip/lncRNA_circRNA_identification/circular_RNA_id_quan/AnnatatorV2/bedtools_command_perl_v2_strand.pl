use strict;
use warnings;

##export  PATH=$PATH:/datacenter/disk2/cl/RNA-seq/process/at_anno/test/bedtools-2.17.0/bin

#cut  -f1-6  three_find_circ.bed   >  three_find_circ_6.bed
#[root@localhost compare]# more  three_find_circ_6.bed
#Chr1	10145614	10150243	os_circ_001257	6	+
#Chr1	11275149	11275596	os_circ_002082	8	+
#Chr1	13848031	13848160	os_circ_001273	4	+
#Chr1	14451680	14462776	os_circ_000248	286	+
#Chr1	15491962	15510770	os_circ_000677	22	+
#Chr1	17561979	17562360	os_circ_000308	4	+
#Chr1	17618296	17622964	os_circ_001431	12	-
#Chr1	17618932	17619476	os_circ_001742	4	-
#Chr1	18088060	18092662	os_circ_002684	4	+
#Chr1	18152218	18152963	os_circ_002424	4	+
#Chr1	18152218	18153353	os_circ_000561	4	+
#Chr1	18926823	18928266	os_circ_000223	8	+
#Chr1	20543254	20573013	os_circ_000005	128	+
#Chr1	20544504	20574267	os_circ_001411	42	+
#Chr1	20546688	20575751	os_circ_001187	72	+
#Chr1	20583897	20584006	os_circ_001081	4	-
#Chr1	20641279	20651720	os_circ_000466	244	+
#Chr1	21424261	21426198	os_circ_000503	6	+
#perl  bedtools_command_perl_v2.pl   /datacenter/disk2/cl/RNA-seq/ok/all.gff3    three_find_circ_6.bed 
my $gff3_file_name=$ARGV[0];
my $bed_file_name=$ARGV[1];
&process($gff3_file_name,$bed_file_name);

sub process
{
	my ($gff3_file_name,$bed_file_name,$bool_exec)=@_;
	&command_system(qq(awk '{if(\$3=="gene")print \$0}'  $gff3_file_name> all_gene.gff3),$bool_exec);
	&command_system(qq(bedtools  intersect   -a  $bed_file_name -b all_gene.gff3 -v |sort -k1,1 -k2,2n  > intergenic_circRNA.bed ),$bool_exec);
	&command_system(qq(bedtools  intersect   -a  $bed_file_name -b all_gene.gff3 -f 0.95 -wa -wb -s  > UTR_exon_intron_genic_circRNA.bed),$bool_exec);
	&command_system(qq(awk '{if(\$3!="gene" && \$3!="CDS" && \$3!="mRNA" && \$3!="five_prime_UTR" && \$3!="three_prime_UTR")print \$0}'  $gff3_file_name > no_cds_no_gene.gff3),$bool_exec);
	&command_system(qq(bedtools  intersect   -a  UTR_exon_intron_genic_circRNA.bed    -b no_cds_no_gene.gff3 -wa -wb  -s >genic_circRNA_tmp.bed),$bool_exec);
	&command_system(qq(bedtools groupby -i genic_circRNA_tmp.bed  -grp 1-6  -c  24 -o collapse >UTR_exon_genic_circRNA_tmp.bed.collapse),$bool_exec);
	&command_system(qq(awk '{if(\$3=="five_prime_UTR" )print \$0}' $gff3_file_name > five_prime_UTR_gene.gff3),$bool_exec);
	&command_system(qq(bedtools  intersect -a UTR_exon_intron_genic_circRNA.bed  -b five_prime_UTR_gene.gff3 -f 1.0 -wa -wb -s>five_prime_UTR_circRNA_tmp.bed),$bool_exec);
	&command_system(qq(awk '{if(\$3=="three_prime_UTR" )print \$0}' $gff3_file_name > three_prime_UTR_gene.gff3),$bool_exec);
	&command_system(qq(bedtools  intersect -a UTR_exon_intron_genic_circRNA.bed -b three_prime_UTR_gene.gff3 -f 1.0 -wa -wb -s>three_prime_UTR_circRNA_tmp.bed),$bool_exec);
	&command_system(qq(bedtools groupby -i five_prime_UTR_circRNA_tmp.bed   -grp 1-6   -c 24  -o collapse >five_prime_UTR_circRNA_tmp.bed.collapse),$bool_exec);
	&command_system(qq(bedtools groupby -i three_prime_UTR_circRNA_tmp.bed   -grp 1-6  -c 24  -o collapse >three_prime_UTR_circRNA_tmp.bed.collapse),$bool_exec);
	&command_system(qq(awk '{print \$4}'  five_prime_UTR_circRNA_tmp.bed.collapse >five_prime_UTR_circRNA_tmp.bed.collapse.list),$bool_exec);
	&command_system(qq(awk '{print \$4}' three_prime_UTR_circRNA_tmp.bed.collapse>three_prime_UTR_circRNA_tmp.bed.collapse.list),$bool_exec);
	&command_system(qq(cat five_prime_UTR_circRNA_tmp.bed.collapse.list  three_prime_UTR_circRNA_tmp.bed.collapse.list >UTR_circRNA.list),$bool_exec);
	&command_system(qq(awk '{print \$4}' UTR_exon_intron_genic_circRNA.bed  >UTR_exon_intron_genic_circRNA.bed.list),$bool_exec);
	&command_system(qq(awk '{print \$4}' UTR_exon_genic_circRNA_tmp.bed.collapse  >UTR_exon_genic_circRNA_tmp.bed.collapse.list),$bool_exec);
	my $intergenic_circRNA=&count_lines("intergenic_circRNA.bed");
	my $UTR_exon_intron_genic_circRNA=&count_lines("UTR_exon_intron_genic_circRNA.bed");
	my $UTR_exon_genic_circRNA=&count_lines("UTR_exon_genic_circRNA_tmp.bed.collapse");
	my $five_UTR_circRNA=&count_lines("five_prime_UTR_circRNA_tmp.bed.collapse");
	my $three_UTR_circRNA=&count_lines("three_prime_UTR_circRNA_tmp.bed.collapse");
	my $UTR_circRNA=&count_lines("UTR_circRNA.list");
	my $total_num=&count_lines($bed_file_name);
	my $exonic_circRNA=$UTR_exon_genic_circRNA-$UTR_circRNA;
	my @list1=&load_list_from_file("UTR_exon_intron_genic_circRNA.bed.list");
	my @list2=&load_list_from_file("UTR_exon_genic_circRNA_tmp.bed.collapse.list");
	my @list=&set_A_minus_set_B(\@list1,\@list2);
	my $intronic_circRNA1=scalar  @list;
	my $intronic_circRNA2=$UTR_exon_intron_genic_circRNA-$UTR_exon_genic_circRNA;
	my $other_circRNA=$total_num-$intergenic_circRNA-$UTR_exon_intron_genic_circRNA+$intronic_circRNA2-$intronic_circRNA1;
	print "total_num\t$total_num\n";
	print "intergenic_circRNA\t$intergenic_circRNA\n";
	#print "UTR_exon_intron_genic_circRNA\t$UTR_exon_intron_genic_circRNA\n";
	#print "UTR_exon_genic_circRNA\t$UTR_exon_genic_circRNA\n";
	print "five_UTR_circRNA\t$five_UTR_circRNA\n";
	print "three_UTR_circRNA\t$three_UTR_circRNA\n";
	print "UTR_circRNA\t$UTR_circRNA\n";
	print "intronic_circRNA\t$intronic_circRNA1\n";
	#print "intronic_circRNA\t$intronic_circRNA2\n";
	print "other_circRNA\t$other_circRNA\n";
	print "exonic_circRNA\t$exonic_circRNA/$UTR_exon_genic_circRNA\n";
	#print $intergenic_circRNA+$UTR_circRNA+$exonic_circRNA+$intronic_circRNA1+$other_circRNA,"\n";
}

sub count_lines
{
	my ($file_name)=@_;
	open FILE,$file_name;
	my $i=0;
	while(<FILE>)
	{
		chomp;
		$i++;
	}
	close FILE;
	return $i;
}

sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}

sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	return @list;
}

sub  set_A_minus_set_B
{
	my ($listA,$listB)=@_;
	my %listB=map{$_=>1} @$listB;
	my @list=grep {!$listB{$_}} @$listA;
	return @list;
}



__DATA__
   awk '{if($3=="gene")print $0}'  /datacenter/disk2/cl/RNA\-seq/ok/all.gff3  > all_gene.gff3 
  bedtools  intersect   -a  set_plus20.bed.rename.bed  -b all_gene.gff3 -f 1.0 -wa -wb -s  > genic_circRNA.bed
 awk '{if($3!="gene" && $3!="CDS" && $3!="mRNA" )print $0}'  /datacenter/disk2/cl/RNA\-seq/ok/all.gff3  > no_cds_no_gene.gff3 
 bedtools  intersect   -a  genic_circRNA.bed    -b no_cds_no_gene.gff3 -wa -wb  -s  >  genic_circRNA_tmp.bed
 bedtools groupby -i genic_circRNA_tmp.bed  -grp 1-6  -c  24 -o collapse > genic_circRNA_tmp.bed.collapse
 wc -l genic_circRNA_tmp.bed.collapse
 
 awk '{if($3=="five_prime_UTR" )print $0}'  /datacenter/disk2/cl/RNA\-seq/ok/all.gff3  > five_prime_UTR_gene.gff3 
 bedtools  intersect   -a  genic_circRNA.bed    -b   five_prime_UTR_gene.gff3  -f 1.0  -wa -wb  -s  >  five_prime_UTR_circRNA_tmp.bed
 wc -l  five_prime_UTR_circRNA_tmp.bed
 awk '{if($3 =="three_prime_UTR" )print $0}'  /datacenter/disk2/cl/RNA\-seq/ok/all.gff3  > three_prime_UTR_gene.gff3 
  bedtools  intersect   -a  genic_circRNA.bed    -b    three_prime_UTR_gene.gff3      -f 1.0  -wa -wb  -s  >three_prime_UTR_circRNA_tmp.bed
  wc -l three_prime_UTR_circRNA_tmp.bed
  
  bedtools groupby -i five_prime_UTR_circRNA_tmp.bed   -grp 1-6   -c 24  -o collapse >five_prime_UTR_circRNA_tmp.bed.collapse
  wc -l five_prime_UTR_circRNA_tmp.bed.collapse
  bedtools groupby -i three_prime_UTR_circRNA_tmp.bed   -grp 1-6   -c 24  -o collapse >three_prime_UTR_circRNA_tmp.bed.collapse
   wc -l three_prime_UTR_circRNA_tmp.bed.collapse
   
   
   awk '{print $4}'  five_prime_UTR_circRNA_tmp.bed.collapse >five_prime_UTR_circRNA_tmp.bed.collapse.list
   awk '{print $4}' three_prime_UTR_circRNA_tmp.bed.collapse>three_prime_UTR_circRNA_tmp.bed.collapse.list
   cat five_prime_UTR_circRNA_tmp.bed.collapse.list  three_prime_UTR_circRNA_tmp.bed.collapse.list >UTR.list
   
   
Test data
[root@localhost test]# perl  bedtools_command_perl.pl  /datacenter/disk2/cl/RNA-seq/ok/all.gff3   set_plus20.bed.rename.bed   
awk '{if($3=="gene")print $0}'  /datacenter/disk2/cl/RNA-seq/ok/all.gff3> all_gene.gff3
bedtools  intersect   -a  set_plus20.bed.rename.bed -b all_gene.gff3 -v |sort -k1,1 -k2,2n  > intergenic_circRNA.bed 
bedtools  intersect   -a  set_plus20.bed.rename.bed -b all_gene.gff3 -f 1.0 -wa -wb -s  > UTR_exon_intron_genic_circRNA.bed
awk '{if($3!="gene" && $3!="CDS" && $3!="mRNA" )print $0}'  /datacenter/disk2/cl/RNA-seq/ok/all.gff3 > no_cds_no_gene.gff3
bedtools  intersect   -a  UTR_exon_intron_genic_circRNA.bed    -b no_cds_no_gene.gff3 -wa -wb  -s >genic_circRNA_tmp.bed
bedtools groupby -i genic_circRNA_tmp.bed  -grp 1-6  -c  24 -o collapse >UTR_exon_genic_circRNA_tmp.bed.collapse
awk '{if($3=="five_prime_UTR" )print $0}' /datacenter/disk2/cl/RNA-seq/ok/all.gff3 > five_prime_UTR_gene.gff3
bedtools  intersect -a UTR_exon_intron_genic_circRNA.bed  -b five_prime_UTR_gene.gff3 -f 1.0 -wa -wb -s>five_prime_UTR_circRNA_tmp.bed
awk '{if($3=="three_prime_UTR" )print $0}' /datacenter/disk2/cl/RNA-seq/ok/all.gff3 > three_prime_UTR_gene.gff3
bedtools  intersect -a UTR_exon_intron_genic_circRNA.bed -b three_prime_UTR_gene.gff3 -f 1.0 -wa -wb -s>three_prime_UTR_circRNA_tmp.bed
bedtools groupby -i five_prime_UTR_circRNA_tmp.bed   -grp 1-6   -c 24  -o collapse >five_prime_UTR_circRNA_tmp.bed.collapse
bedtools groupby -i three_prime_UTR_circRNA_tmp.bed   -grp 1-6  -c 24  -o collapse >three_prime_UTR_circRNA_tmp.bed.collapse
awk '{print $4}'  five_prime_UTR_circRNA_tmp.bed.collapse >five_prime_UTR_circRNA_tmp.bed.collapse.list
awk '{print $4}' three_prime_UTR_circRNA_tmp.bed.collapse>three_prime_UTR_circRNA_tmp.bed.collapse.list
cat five_prime_UTR_circRNA_tmp.bed.collapse.list  three_prime_UTR_circRNA_tmp.bed.collapse.list >UTR_circRNA.list
awk '{print $4}' UTR_exon_intron_genic_circRNA.bed  >UTR_exon_intron_genic_circRNA.bed.list
awk '{print $4}' UTR_exon_genic_circRNA_tmp.bed.collapse  >UTR_exon_genic_circRNA_tmp.bed.collapse.list
total_num	12037
intergenic_circRNA	705
UTR_exon_intron_genic_circRNA	7216
UTR_exon_genic_circRNA	6712
five_UTR_circRNA	181
three_UTR_circRNA	456
UTR_circRNA	637
intronic_circRNA	485
intronic_circRNA	504
other_circRNA	4135
exonic_circRNA	6075
12037

