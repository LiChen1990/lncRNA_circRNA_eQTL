use strict;
use warnings;

my $results_file=$ARGV[0];
open FILE ,$results_file;
while(<FILE>)
{
	chomp;
	my ($str1,$str2,$chrom,$start,$end,$str3)=(split(/\t/,$_,6))[1-1,2-1,3-1,4-1,5-1,6-1];
	$str1=~/(.*):(\d+)\.\.(\d+)/;
	my $circ_chrom=$1;
	my $circ_start=$2-1;
	my $circ_end=$3;
	print join("\t",$circ_chrom,$circ_start,$circ_end,$str3),"\n";
}
close FILE;
__DATA__
Chr1:10472686..10473021	Chr1:10472686-10473021	Chr1	10472685	10473021	circ66	0	+	LOC_Os01g18584.1:exon_4	LOC_Os01g18584.1:exon
