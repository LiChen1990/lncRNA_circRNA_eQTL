use strict;
use warnings;
my @list=&load_list_from_file('UTR_circRNA.list');

while(<>)
{
	chomp;
	my ($name)=(split(/\t/,$_))[4-1];
	print $_,"\n";
#	if(not &is_in_list(\@list,$name))
#	{
#		print $_,"\n";
#	}
}



sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	return @list;
}



sub  is_in_list
{
	my ($ref_list,$str)=@_;
	my %hash=();
	foreach my $key(@$ref_list)
	{
		$hash{$key}=1;
	}
  if(exists $hash{$str})
  {
  	return 1;
  }
  else
  {
		return 0;
	}
}