use strict;
use warnings;

my $results_file=$ARGV[0];
my %hash=();
open FILE ,$results_file;
while(<FILE>)
{
	chomp;
	my ($str1,$str2,$chrom,$start,$end,$name,$count,$strand,$str3)=(split(/\t/,$_,9))[1-1,2-1,3-1,4-1,5-1,6-1,7-1,8-1,9-1];
	$str2=~/(.*):(\d+)\.\.(\d+)/;
	my $ann_chrom=$1;
	my $ann_start=$2-1;
	my $ann_end=$3;
	$hash{join("\t",$ann_chrom,$ann_start,$ann_end,$strand)}=join("\t",$chrom,$start,$end,$name,$count,$strand,$str3);
	#print join("\t",$ann_chrom,$ann_start,$ann_end,$str3),"\n";
}
close FILE;

foreach my $key (sort keys %hash)
{
	print $hash{$key},"\n";
}
__DATA__
Chr1:10472686..10473021	Chr1:10472686-10473021	Chr1	10472685	10473021	circ66	0	+	LOC_Os01g18584.1:exon_4	LOC_Os01g18584.1:exon
