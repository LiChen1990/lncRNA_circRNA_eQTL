use strict;
use warnings;

my $file=$ARGV[0] || "CMC_PITT_183_R1_val_1.gtf";

print join("\t","chrom","start","end","circ_id","exp","strand","circ_type","bsj","fsj","junc_ratio","gene_id","gene_name","gene_type"),"\n";

open FILE,$file;
while(<FILE>)
{
 chomp;
 next if /^#/;
 my ($chrom,$source,$type,$start,$end,$exp_val,$strand,$tmp,$str)=split(/\t/,$_);
 if($type eq "circRNA")
 {
 		my %hash=();
	  my (@list)=split(/; /,$str);
	  foreach my $str1 (@list)
	  {
	  	$str1=~s/;$//;
	    my @list1=split(/ /,$str1);
	    $list1[1]=~s/\"//g;
	    $hash{$list1[0]}=$list1[1];
	  }
	  
	  my $circ_id=&check_exists_hash("circ_id",%hash);
	  my $circ_type=&check_exists_hash("circ_type",%hash);
	  my $bsj=&check_exists_hash("bsj",%hash);
	  my $fsj=&check_exists_hash("fsj",%hash);
	  my $junc_ratio=&check_exists_hash("junc_ratio",%hash);
	  my $gene_id=&check_exists_hash("gene_id",%hash);
	  my $gene_name=&check_exists_hash("gene_name",%hash);
	  my $gene_type=&check_exists_hash("gene_type",%hash);

   	print join("\t",$chrom,$start,$end,$circ_id,$exp_val,$strand,$circ_type,$bsj,$fsj,$junc_ratio,$gene_id,$gene_name,$gene_type),"\n";
 }
 
}
close FILE;



sub  check_exists_hash
{
	my ($key,%hash)=@_;
	if(exists $hash{$key})
	{
	  return $hash{$key};
	}
	else
	{
		return "";
	}
}

