use strict;
use warnings;

my $file=$ARGV[0];
open FILE,$file;
while(<FILE>)
{
  chomp;
  next if $.==1;
  my ($circRNA_ID	,$chr	,$circRNA_start	,$circRNA_end, $junction_reads	,$SM_MS_SMS,	$non_junction_reads	,$junction_reads_ratio	,$circRNA_type	,$gene_id	,$strand	,$junction_reads_ID)=split(/\t/,$_);
  if($junction_reads>=2 and $junction_reads_ratio >=0.05)
  {
   print join("\t",$chr,$circRNA_start	,$circRNA_end,$circRNA_ID,1,$strand),"\n";
  }
  
}
close FILE;
