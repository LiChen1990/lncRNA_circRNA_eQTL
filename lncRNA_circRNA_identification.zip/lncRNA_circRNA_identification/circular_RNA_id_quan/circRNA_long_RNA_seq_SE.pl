use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

my $genome_file="";###genome_index_name
my $config_file="";
my $gtf_file="";
my $debug;
my %hash_config=();
my $thread_num;
my $type="";
my $map_file="";
my $STAR_index_dir="";
my $RSEM_index_files="";


GetOptions(
          "debug!"=>\$debug,
          "conf=s"=>\$config_file,
          "genome=s"=>\$genome_file,
          "type=s"=>\$type,
          "gtf_file=s"=>\$gtf_file,
          "thread=i"=>\$thread_num
);

my  $conf = Config::General->new($config_file);
%hash_config = $conf->getall;

my @list1=();
my @list1_bam=();
my @list2=();
my @list2_bam=();

my @list_samples=();



#&command_system(qq(dos2unix $config_file ),$debug);



foreach my $sample_name (keys %{$hash_config{"sample"}})
{
	push(@list1,(split(/,/,$hash_config{"sample"}{$sample_name}))[0]);
	push(@list_samples,$sample_name);
}

##bwa index -a bwtsw ref.fa 


if($type eq "local")
{
	for(my $i=0;$i<scalar @list1; $i++)
	{
		my $fastq1=$list1[$i];
		my ($name_1, $path_1, $suffix_1) = fileparse ($fastq1, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));	
		&command_system(qq(source ~/.bashrc ),$debug);	
		&command_system(qq(conda activate   /storage/yangjianLab/chenli/softwares/condalocal/scvi-env  ),$debug);		
		&command_system(qq(mkdir $pwd/$name_1 ),$debug);	
		&command_system(qq(cd  $pwd/$name_1 ),$debug);		
		##CIRI-long call -i test_reads.fa   -o ./test_call  -r mm10_chr12.fa   -p test   -a mm10_chr12.gtf   -t 8
		&command_system(qq(bwa mem -t 4  -T 19 $genome_file  $fastq1  1> $name_1.sam 2> $name_1.log ),$debug);
		&command_system(qq(CIRI-long call -i $fastq1   -o $name_1  -r $genome_file  -p $name_1   -a  $gtf_file    -t 8  ),$debug);
		&command_system(qq(echo -e "$name_1\\t./$name_1/$name_1.cand_circ.fa" > $name_1.lst ),$debug);
		&command_system(qq(CIRI-long collapse -i ./$name_1.lst  -o ./${name_1}_collpase  -p ${name_1}     -r $genome_file    -a $gtf_file   -t 8),$debug);
		&command_system(qq(perl $bin_path/convert_bed.py ${name_1}_collpase/$name_1.info $name_1.bed   ## 1-based  ),$debug);

	}
   
}


sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}


