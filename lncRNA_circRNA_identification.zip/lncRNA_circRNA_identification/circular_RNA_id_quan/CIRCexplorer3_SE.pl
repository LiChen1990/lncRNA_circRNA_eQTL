use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

my $genome_file="";###genome_index_name
my $config_file="";
my $gtf_file="";
my $debug;
my %hash_config=();
my $thread_num;
my $type="";
my $map_file="";
my $STAR_index_dir="";
my $RSEM_index_files="";


GetOptions(
          "debug!"=>\$debug,
          "conf=s"=>\$config_file,
          "genome=s"=>\$genome_file,
          "type=s"=>\$type,
          "gtf_file=s"=>\$gtf_file,
          "thread=i"=>\$thread_num
);

my  $conf = Config::General->new($config_file);
%hash_config = $conf->getall;

my @list1=();
my @list1_bam=();
my @list2=();
my @list2_bam=();

my @list_samples=();



#&command_system(qq(dos2unix $config_file ),$debug);



foreach my $sample_name (keys %{$hash_config{"sample"}})
{
	push(@list1,(split(/,/,$hash_config{"sample"}{$sample_name}))[0]);
	push(@list_samples,$sample_name);
}

##bwa index -a bwtsw ref.fa 


if($type eq "local")
{
	for(my $i=0;$i<scalar @list1; $i++)
	{
		my $fastq1=$list1[$i];
		my ($name_1, $path_1, $suffix_1) = fileparse ($fastq1, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));	
			&command_system(qq(source ~/.bashrc ),$debug);	
		&command_system(qq(conda activate /storage/yangjianLab/chenli/softwares/condalocal/py27   ),$debug);		
#		&command_system(qq(mkdir $pwd/$name_1 ),$debug);	
#		&command_system(qq(cd  $pwd/$name_1 ),$debug);	
### https://github.com/YangLab/CLEAR/tree/master	
		&command_system(qq(python /storage/yangjianLab/chenli/softwares/circRNA/Test_CMC/circexplorer/CLEAR-master/src/run.py  -1 $list1[$i]    -g $genome_file  -i $genome_file  -j $genome_file  -G   $gtf_file   -o $name_1  -p 5 ),$debug);
		&command_system(qq(perl $bin_path/CIRCexplorer2bed.pl  $name_1/circ/circular.txt   > $name_1/$name_1.CIRCexplorer.bed ),$debug);
		&command_system(qq(cp  $name_1/quant/quant.txt  $name_1/quant.txt  ),$debug);
		&command_system(qq(cp  $name_1/circ/circular.txt  $name_1/circular.txt  ),$debug);
		&command_system(qq(rm -rf $name_1/fusion ),$debug);
		&command_system(qq(rm -rf $name_1/hisat ),$debug);
		&command_system(qq(rm -rf $name_1/circ ),$debug);
		&command_system(qq(rm -rf $name_1/quant ),$debug);

	}
   
}


sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}


