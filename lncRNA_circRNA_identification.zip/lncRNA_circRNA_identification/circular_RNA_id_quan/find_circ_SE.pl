use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

my $genome_file="";###genome_index_name
my $config_file="";
my $gtf_file="";
my $debug;
my %hash_config=();
my $thread_num;
my $type="";
my $map_file="";
my $STAR_index_dir="";
my $RSEM_index_files="";
my $chromsome_dir="";


GetOptions(
          "debug!"=>\$debug,
          "conf=s"=>\$config_file,
          "genome=s"=>\$genome_file,
          "type=s"=>\$type,
          "chromsome_dir=s"=>\$chromsome_dir,
          "gtf_file=s"=>\$gtf_file,
          "thread=i"=>\$thread_num
);

my  $conf = Config::General->new($config_file);
%hash_config = $conf->getall;

my @list1=();
my @list1_bam=();
my @list2=();
my @list2_bam=();

my @list_samples=();



#&command_system(qq(dos2unix $config_file ),$debug);



foreach my $sample_name (keys %{$hash_config{"sample"}})
{
	push(@list1,(split(/,/,$hash_config{"sample"}{$sample_name}))[0]);
	push(@list_samples,$sample_name);
}

##bwa index -a bwtsw ref.fa 


if($type eq "local")
{
	for(my $i=0;$i<scalar @list1; $i++)
	{
		my $fastq1=$list1[$i];
		my ($name_1, $path_1, $suffix_1) = fileparse ($fastq1, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));	
		&command_system(qq(source ~/.bashrc  ),$debug);
		&command_system(qq(conda activate /storage/yangjianLab/chenli/softwares/condalocal/py27  ),$debug);		
		&command_system(qq(mkdir $pwd/$name_1 ),$debug);	
		&command_system(qq(cd  $pwd/$name_1 ),$debug);		
		&find_circRNA_SE($genome_file,$fastq1,"no",$chromsome_dir,$name_1,$debug);
		&filter_bed_file("${name_1}.sites.bed",$name_1,$debug);
    &command_system(qq(rm -rf  $name_1.bam  ),$debug);	
    &command_system(qq(rm -rf  $name_1.sites.reads ),$debug);
    &command_system(qq(rm -rf  unmapped_${name_1}.bam ),$debug);	
    &command_system(qq(rm -rf  unmapped_${name_1}_anchors.qfa ),$debug);	
	}
   
}






sub find_circRNA_SE
{
		my($genome_index,$fastq_file,$sample_description_file,$chr_dir,$prefix,$bool_exec)=@_;
		##unless(-e "${genome_index}.1.bt2")
		my $bowtie2_path="/storage/yangjianLab/chenli/softwares/condalocal/tensorflow20_py36/bin/bowtie2  ";
		my $samtools_path="samtools ";
		my $find_circRNA_path="/storage/yangjianLab/chenli/scripts/circular_RNA_id_quan/find_circ";
		my ($name, $path, $suffix) = fileparse ($fastq_file, (".fastq",".fq",".fastq.gz",".fq.gz"));
		my $command1=qq($bowtie2_path  -p16 --very-sensitive --mm -M20 --score-min=C,-15,0 -x  $genome_index    -U  $fastq_file   2> ${name}_bt2_firstpass.log | $samtools_path  view -hbuS - | $samtools_path  sort -  -o $name.bam );
	  print $command1,"\n";
		system($command1) if not $bool_exec;
		my $command2=qq($samtools_path   view -hf 4  ${name}.bam | $samtools_path  view -Sb - > unmapped_${name}.bam);
		print $command2,"\n";
		system($command2)if not $bool_exec;
		my $command3=qq(python  $find_circRNA_path/unmapped2anchors.py   unmapped_${name}.bam  > unmapped_${name}_anchors.qfa);
		print  $command3,"\n";
		system($command3)if not $bool_exec;
		
		if($sample_description_file=~/^no$/i)
		{
			my $command5=qq($bowtie2_path  --reorder --mm -M20 --score-min=C,-15,0 -q -x  $genome_index  -U unmapped_${name}_anchors.qfa  2> bt2_secondpass_test.log | python  $find_circRNA_path/find_circ.py   -G $chr_dir -p $prefix -s $name.sites.log > $name.sites.bed 2> $name.sites.reads );
			print $command5,"\n";
			system($command5)if not $bool_exec;		
		}
		else
		{
			my $command5=qq($bowtie2_path  --reorder --mm -M20 --score-min=C,-15,0 -q -x  $genome_index  -U unmapped_${name}_anchors.qfa  2> bt2_secondpass_test.log | python  $find_circRNA_path/find_circ.py -r $sample_description_file  -G $chr_dir -p $prefix -s $name.sites.log > $name.sites.bed 2> $name.sites.reads );
			print $command5,"\n";
			system($command5)if not $bool_exec;
		}
}

sub find_circRNA_PE
{
		my($genome_index,$fastq_file1,$fastq_file2,$sample_description_file,$chr_dir,$prefix,$bool_exec)=@_;
		##unless(-e "${genome_index}.1.bt2")
		my $bowtie2_path="/storage/yangjianLab/chenli/softwares/condalocal/tensorflow20_py36/bin/bowtie2   ";
		my $samtools_path="samtools ";
		my $find_circRNA_path="/storage/yangjianLab/chenli/scripts/circular_RNA_id_quan/find_circ";
		my ($name, $path, $suffix) = fileparse ($fastq_file1, (".fastq",".fq",".fastq.gz",".fq.gz"));
		my $command1=qq($bowtie2_path  -p16 --very-sensitive --mm -M20 --score-min=C,-15,0 -x  $genome_index   -1  $fastq_file1  -2  $fastq_file2  2> ${name}_bt2_firstpass.log | $samtools_path  view -hbuS - | $samtools_path  sort - -o $name.bam);
	  print $command1,"\n";
		system($command1) if not $bool_exec;
		my $command2=qq($samtools_path   view -hf 4  ${name}.bam | $samtools_path  view -Sb - > unmapped_${name}.bam);
		print $command2,"\n";
		system($command2)if not $bool_exec;
		my $command3=qq(python  $find_circRNA_path/unmapped2anchors.py   unmapped_${name}.bam  > unmapped_${name}_anchors.qfa);
		print  $command3,"\n";
		system($command3)if not $bool_exec;
		if($sample_description_file=~/^no$/i)
		{
			my $command5=qq($bowtie2_path  --reorder --mm -M20 --score-min=C,-15,0 -q -x  $genome_index  -U unmapped_${name}_anchors.qfa  2> bt2_secondpass_test.log | python  $find_circRNA_path/find_circ.py   -G $chr_dir -p $prefix -s $name.sites.log > $name.sites.bed 2> $name.sites.reads );
			print $command5,"\n";
			system($command5)if not $bool_exec;		 
		}
		else
		{
			my $command5=qq($bowtie2_path  --reorder --mm -M20 --score-min=C,-15,0 -q -x  $genome_index  -U unmapped_${name}_anchors.qfa  2> bt2_secondpass_test.log | python  $find_circRNA_path/find_circ.py -r $sample_description_file  -G $chr_dir -p $prefix -s $name.sites.log > $name.sites.bed 2> $name.sites.reads );
			print $command5,"\n";
			system($command5)if not $bool_exec;
		}
}


###################################################################################################################################################################
# usage : &find_circRNA_for_fastq_list($genome_index,\@fastq_list,$sample_name,$sample_file,$chromsome_dir,$prefix);
#  input file :SRR384963_1.fastq,sample2.fastq,sample3.fastq samples_example.txt /datacenter/disk1/cl/human_data/Chromosomes  hsa_   T3 
#	output file: T3.bam(sorted bam file) ==> ummapped_T3.bam ==> unmapped_T3_anchors.qfa ==> test_out_T3/sites.bed
###################################################################################################################################################################
sub find_circRNA_for_fastq_list
{
		my($genome_index,$ref_fastq_file_list,$sample_name,$sample_description_file,$chr_dir,$prefix,$bool_exec)=@_;
		##unless(-e "${genome_index}.1.bt2")
		my $bowtie2_path="bowtie2 ";
		my $samtools_path="samtools ";
		my $find_circRNA_path="/storage/yangjianLab/chenli/softwares/circRNA/find_circ";
		my $name=$sample_name;
		my $string_fastq_list=join("  ",@$ref_fastq_file_list);
		my $command1=qq(cat $string_fastq_list | $bowtie2_path  -p16 --very-sensitive --mm -M20 --score-min=C,-15,0 -x  $genome_index  -q  -U  -   2> ${name}_bt2_firstpass.log | $samtools_path  view -hbuS - | $samtools_path  sort -  $name);
	  print $command1,"\n";
		system($command1) if not $bool_exec;
		my $command2=qq($samtools_path   view -hf 4  ${name}.bam | $samtools_path  view -Sb - > unmapped_${name}.bam);
		print $command2,"\n";
		system($command2)if not $bool_exec;
		my $command3=qq(python  $find_circRNA_path/unmapped2anchors.py   unmapped_${name}.bam  > unmapped_${name}_anchors.qfa);
		print  $command3,"\n";
		system($command3)if not $bool_exec;
		if(not -e "test_out_$name" )
		{
			my $command4=qq(mkdir test_out_$name);
			print $command4,"\n";
			system($command4) if not $bool_exec;
		}
		if($sample_description_file=~/^no$/i)
		{
			my $command5=qq($bowtie2_path  --reorder --mm -M20 --score-min=C,-15,0 -q -x  $genome_index  -U unmapped_${name}_anchors.qfa  2> bt2_secondpass_test.log | python  $find_circRNA_path/find_circ.py   -G $chr_dir -p $prefix -s test_out_$name/sites.log > test_out_$name/sites.bed 2> test_out_$name/sites.reads );
			print $command5,"\n";
			system($command5)if not $bool_exec;		
		}
		else
		{
			my $command5=qq($bowtie2_path  --reorder --mm -M20 --score-min=C,-15,0 -q -x  $genome_index  -U unmapped_${name}_anchors.qfa  2> bt2_secondpass_test.log | python  $find_circRNA_path/find_circ.py -r $sample_description_file  -G $chr_dir -p $prefix -s test_out_$name/sites.log > test_out_$name/sites.bed 2> test_out_$name/sites.reads );
			print $command5,"\n";
			system($command5)if not $bool_exec;
		}
}



##grep circ sites.bed | grep -v chrM | ./sum.py -2,3 | ./scorethresh.py -16 1 | ./scorethresh.py -15 2 | ./scorethresh.py -14 2 | ./scorethresh.py 7 2 | ./scorethresh.py 8,9 35 | ./scorethresh.py -17 100000 > circ_candidates.bed
sub filter_bed_file
{
	my ($bed_file,$sample_name,$bool_exec)=@_;
	my $find_circRNA_path="/storage/yangjianLab/chenli/softwares/circRNA/find_circ";
	my $command=qq(grep circ $bed_file | grep -v chrM | $find_circRNA_path/sum.py -2,3 | $find_circRNA_path/scorethresh.py -16 1 | $find_circRNA_path/scorethresh.py -15 2 | $find_circRNA_path/scorethresh.py -14 2 | $find_circRNA_path/scorethresh.py 7 2 | $find_circRNA_path/scorethresh.py 8,9 35 | $find_circRNA_path/scorethresh.py -17 100000 > $sample_name.circ_candidates.bed);
	print $command,"\n";
	system($command) if not $bool_exec;
}

sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}


