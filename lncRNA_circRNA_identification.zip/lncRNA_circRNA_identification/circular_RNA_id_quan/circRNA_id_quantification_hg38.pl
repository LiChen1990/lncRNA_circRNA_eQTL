use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

my $genome_file="";###genome_index_name
my $config_file="";
my $gtf_file="";
my $debug;
my %hash_config=();
my $thread_num;
my $type="";
my $map_file="";
my $STAR_index_dir="";
my $RSEM_index_files="";


GetOptions(
          "debug!"=>\$debug,
          "conf=s"=>\$config_file,
          "genome=s"=>\$genome_file,
          "type=s"=>\$type,
          "gtf_file=s"=>\$gtf_file,
          "thread=i"=>\$thread_num
);

my  $conf = Config::General->new($config_file);
%hash_config = $conf->getall;

my @list1=();
my @list1_bam=();
my @list2=();
my @list2_bam=();

my @list_samples=();



#&command_system(qq(dos2unix $config_file ),$debug);



foreach my $sample_name (keys %{$hash_config{"sample"}})
{
	push(@list1,(split(/,/,$hash_config{"sample"}{$sample_name}))[0]);
	push(@list2,(split(/,/,$hash_config{"sample"}{$sample_name}))[1]);
	push(@list_samples,$sample_name);
}

##bwa index -a bwtsw ref.fa 


if($type eq "local")
{
	for(my $i=0;$i<scalar @list1; $i++)
	{
		my $fastq1=$list1[$i];
		my $fastq2=$list2[$i];
		my ($name_1, $path_1, $suffix_1) = fileparse ($fastq1, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));	
		my ($name_2, $path_2, $suffix_2) = fileparse ($fastq2, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));	
		&command_system(qq(source ~/.bashrc),$debug);
		&command_system(qq(conda activate /storage/yangjianLab/chenli/softwares/condalocal/tensorflow20_py36 ),$debug);		
		&command_system(qq(mkdir $pwd/$name_1 ),$debug);	
		&command_system(qq(cd  $pwd/$name_1 ),$debug);		
		&command_system(qq(bwa mem -t 4  -T 19 $genome_file  $fastq1  $fastq2  1> $name_1.sam 2> $name_1.log),$debug);
		&command_system(qq(perl /storage/yangjianLab/chenli/softwares/circRNA/CIRI_v2.0.6/CIRI2.pl -I $name_1.sam  -O $name_1.ciri  -F $genome_file  -A   $gtf_file ),$debug);
		&command_system(qq(perl /storage/yangjianLab/chenli/softwares/circRNA/CIRI_AS_v1.2.pl  -S $name_1.sam  -C $name_1.ciri   -F $genome_file  -A $gtf_file   -O $name_1.ciri_as -D yes ),$debug);
		&command_system(qq(/storage/yangjianLab/chenli/softwares/circRNA/Test_CMC/FLASH-1.2.11-Linux-x86_64/flash  -t 4  -m 10 -M 65  $fastq1  $fastq2   --compress   -o $name_1),$debug);
		&command_system(qq(bwa mem -T 19  $genome_file $name_1.extendedFrags.fastq.gz  > $name_1.ro1.sam ),$debug);
		&command_system(qq(java -jar /storage/yangjianLab/chenli/softwares/circRNA/CIRI-full_v2.0/CIRI-full.jar RO2 -r $genome_file   -s $name_1.ro1.sam  -l 250 -o $name_1  ),$debug);
		&command_system(qq(java -jar /storage/yangjianLab/chenli/softwares/circRNA/CIRI-full_v2.0/CIRI-full.jar Merge -c $name_1.ciri  -as $name_1.ciri_as_jav.list  -ro ${name_1}_ro2_info.list -a $gtf_file -r $genome_file   -o $name_1 ),$debug);
#		&command_system(qq(unset DISPLAY ),$debug);
#		&command_system(qq(java -jar /storage/yangjianLab/chenli/softwares/circRNA/CIRI-full_v2.0/CIRI-vis.jar -i ${name_1}_merge_circRNA_detail.anno  -l $name_1.ciri_as_library_length.list   -r  $genome_file   -d CIRI-vis_out -min 1 ),$debug);
  	&command_system(qq(conda activate /storage/yangjianLab/chenli/softwares/condalocal/py27  ),$debug);
		&command_system(qq(perl $bin_path/ciri2bed.pl  $name_1.ciri  > $name_1.ciri.bed ),$debug);
		&command_system(qq(CIRIquant -t 4  -1 $fastq1    -2 $fastq2    --config $bin_path/hg38.genome.yml       -o $name_1       -p $name_1  --bed $name_1.ciri.bed ),$debug);
		&command_system(qq(perl $bin_path/CIRIquant_gtf2table.pl  $name_1/$name_1.gtf > $name_1.CIRIquant.table.txt),$debug); 
		&command_system(qq(cp  $name_1/$name_1.gtf  $name_1.CIRIquant.gtf ),$debug); 
		&command_system(qq(rm -rf $name_1.notCombined_1.fastq.gz ),$debug);
		&command_system(qq(rm -rf $name_1.notCombined_2.fastq.gz ),$debug);
		&command_system(qq(rm -rf $name_1.extendedFrags.fastq.gz ),$debug);
		&command_system(qq(rm -rf $name_1.ciri_as_coverage.list ),$debug);		
		&command_system(qq(rm -rf $name_1.ro1.sam ),$debug);
		&command_system(qq(rm -rf $name_1.sam ),$debug);
		&command_system(qq(rm -rf $name_1.ro2.sam ),$debug);
    &command_system(qq(rm -rf $name_1 ),$debug);
	}
   
}


sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}


