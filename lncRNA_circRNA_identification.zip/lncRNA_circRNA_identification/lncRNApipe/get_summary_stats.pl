use strict;
use warnings;

my $file1=$ARGV[0] || "flower_lncRNA_type.txt";
my $orf_list_file1=$ARGV[1] || "test_RNAlen_ORFlen_info.txt";
my $orf_list_file2=$ARGV[2] || 'orf_list.txt';
my $db_filter_list_file=$ARGV[3]|| 'db_filter_list.txt';
my $coding_p_list_file1=$ARGV[4] || 'candidate_TU.cpc2.txt';
my $coding_p_list_file2=$ARGV[5] || 'noncoding_list.txt';
my $final_candidate_lncRNA_list=$ARGV[6] || "final_candidate_lncRNA_list.txt";

my %orf_list_file2=&list_file2hash($orf_list_file2);
my %orf_list_file1=();

my %db_filter_list_file=&list_file2hash($db_filter_list_file);

my %coding_p_list_file2=&list_file2hash($coding_p_list_file2);
my %coding_p_list_file1=();

my %final_candidate_lncRNA_list=&list_file2hash($final_candidate_lncRNA_list);


open FILE,$orf_list_file1;
while(<FILE>)
{
	chomp;
	if(1==$.)
	{
		next;
	}
	my ($seqname)=(split(/\t/,$_))[0];
	$orf_list_file1{$seqname}=$_;
}
close FILE;

open FILE,$coding_p_list_file1;
while(<FILE>)
{
	chomp;
	if(1==$.)
	{
		next;
	}
	my ($seqname)=(split(/\t/,$_))[0];
	$coding_p_list_file1{$seqname}=$_;
}
close FILE;

##seqname	transcriptlen	ORF1	ORF2	ORF3	revORF1	revORF2	revORF3
###ID	peptide_length	Fickett_score	pI	ORF_integrity	coding_probability	label
print join("\t","g_name","t_name","type","str1","str2","strand","seqname","transcriptlen","ORF1","ORF2","ORF3","revORF1","revORF2","revORF3","Yes/No","Yes/No","ID","peptide_length","Fickett_score","pI","ORF_integrity","coding_probability","label-fromCPC","Yes/No","Yes/No"),"\n";

##Yes means the potential lncRNA
##No means not the potential lncRNA


open FILE111,$file1;
while(<FILE111>)
{
	chomp;
	my ($gname,$tname)=(split(/\t/,$_))[0,1];
	if(exists $orf_list_file1{$tname})
	{
		print $_,"\t",$orf_list_file1{$tname},"\t";
	}
	else
	{
		print $_,"\t",join("\t","","","","","","","",""),"\t";
	}
	if(exists $orf_list_file2{$gname})
	{
		print "Yes","\t";
	}
	else
	{
		print "No","\t";
	}
	
	if(exists $db_filter_list_file{$gname})
	{
		print "No","\t";
	}
	else
	{
		print "Yes","\t";
	}
	
	if(exists $coding_p_list_file1{$tname})
	{
		print $coding_p_list_file1{$tname},"\t";
	}
	else
	{
		###ID	peptide_length	Fickett_score	pI	ORF_integrity	coding_probability	label
		print join("\t","","","","","","",""),"\t";
	}
	if(exists $coding_p_list_file2{$gname})
	{
		print "Yes","\t";
	}
	else
	{
		print "No","\t";
	}
	
	if(exists $final_candidate_lncRNA_list{$gname})
	{
		print "Yes","\n";
	}
	else
	{
		print "No","\n";
	}
}
close FILE111;

sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}

sub list_file2hash
{
	my ($list_file)=@_;
	open FILE,$list_file;
	my %hash=();
	while(<FILE>)
	{
		chomp;
		$hash{$_}++;
	}
	close FILE;
	return %hash;
}
