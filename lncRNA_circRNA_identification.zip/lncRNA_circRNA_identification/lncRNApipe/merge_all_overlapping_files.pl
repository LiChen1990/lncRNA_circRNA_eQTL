use strict;
use warnings;

my $merge_bed=$ARGV[0] || "";
my $filelist=$ARGV[1] || "";

my @list=&load_list_from_file($filelist);

my %hash=();

open FILE,$merge_bed;
while(<FILE>)
{
	chomp;
	my ($chrom,$start,$end,$name)=split(/\t/,$_);
	$hash{$name}=$_;
}
close FILE;

my %hash_res=();

print join("\t","Chr","start","end","name",@list),"\n";
foreach my $filename (@list)
{
		my %hash2=();
		my %hash_res_tmp=();
		next if $filename eq "";
		open FILE,$filename;
		while(<FILE>)
		{
			chomp;
			my ($chrom,$start,$end,$name_in)=split(/\t/,$_);
			if(exists $hash{$name_in})
			{
				$hash2{$name_in}++;
			}
		}
		close FILE;
		foreach my $name_in (keys %hash2)
		{
			$hash_res{$name_in}.="1\t";
		}
		my @list1=keys %hash;
		my @list2=keys %hash2;
		my @list3=&set_A_minus_set_B(\@list1,\@list2);
		foreach my $name1 (@list3)
		{
			$hash_res{$name1}.="0\t";
		}
		#print scalar keys %hash_res,"\n";
		@list1=();
		@list2=();
		@list3=();
}

foreach my $name (keys %hash)
{
	$hash_res{$name}=~s/\t$//;
	print $hash{$name},"\t",$hash_res{$name},"\n";
}

sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}

sub  set_A_minus_set_B
{
	my ($listA,$listB)=@_;
	my %listB=map{$_=>1} @$listB;
	my @list=grep {!$listB{$_}} @$listA;
	return @list;
}
