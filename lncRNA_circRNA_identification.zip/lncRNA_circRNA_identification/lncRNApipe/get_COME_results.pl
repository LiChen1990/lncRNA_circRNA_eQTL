use strict;
use warnings;

my $file=$ARGV[0]|| 'result.txt';

open FILE,$file;

my %hash=();
while(<FILE>)
{
	chomp;
	next if $.==1;
	my ($id,$score,$desc)=split(/\t/,$_);
	if($desc eq "noncoding")
	{
		if($id=~/(.*)\.(\d+)/)
		{
		##MSTRG.10016.3
		$hash{$1}++;
		}
	}
}

close FILE;

foreach (keys %hash)
{
	print $_,"\n";
}


__DATA__
[lichen@flower pv1.2]$ more  result.txt  
transcript_ID	Coding_Potential	Prediction	subclass	DNA_Cons	Protein_Cons	PolyA-	PolyA+	smallRNA	GC_content	H3K36me3	RNA_Structure	H3K4me3
	Transcript_length
Atlnc.10000.1	0.2017	noncoding	1	0.8940	0.5942	0.0258	0.3228	1.0000	0.9091	0.0506	0.0000	0.0401	1977
Atlnc.10002.1	0.0976	noncoding	1	0.9422	0.6443	0.0000	0.7090	0.4635	0.6971	0.0730	0.0000	0.0092	517
Atlnc.10003.1	0.1578	noncoding	1	0.8680	0.0000	0.0000	0.0000	0.2433	0.3938	0.0000	0.0000	0.0250	353
Atlnc.10004.1	0.7232	coding	1	0.9465	0.8366	0.0468	0.1921	0.4541	0.5756	0.0642	0.0000	0.0250	884
Atlnc.10005.1	0.0761	noncoding	1	0.8117	0.3808	0.0000	0.6377	0.6249	0.4847	0.0503	0.0000	0.0018	510
Atlnc.10006.1	0.1761	noncoding	1	0.8857	0.0000	0.0000	0.0000	0.4022	0.1818	0.0000	0.0000	0.0250	265
Atlnc.10007.1	0.5408	coding	1	0.8063	0.6851	0.0000	0.0000	0.3332	0.5150	0.0000	0.0000	0.0244	244