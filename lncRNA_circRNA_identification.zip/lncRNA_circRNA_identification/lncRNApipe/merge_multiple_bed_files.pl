use strict;
use warnings;
use File::Basename;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

my $filelist=$ARGV[0] || "";
my $debug=$ARGV[1] || "";

my @list=&load_list_from_file($filelist);

open FILE_OUT,">merge_all.bed";
foreach my $filename (@list)
{
	open FILE,$filename;
	while(<FILE>)
	{
		print FILE_OUT $_;
	}
	close FILE;
}
close FILE_OUT;

&command_system(qq(sort -k1,1 -k2,2n merge_all.bed > merge_all.sort.bed),$debug);
&command_system(qq(bedtools merge -i merge_all.sort.bed  -d 0  -c 4  -o collapse -delim ";" > merge_all.merge.bed ),$debug);
my @list_overlap=();

foreach my $filename (@list)
{
	my ($name_1, $path_1, $suffix_1) = fileparse ($filename , (".bed",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));	
	&command_system(qq(bedtools intersect -a merge_all.merge.bed  -b $filename -wa -wb > $name_1),$debug);
	push(@list_overlap,qq($name_1));
}

&print_list_to_file(\@list_overlap,"filelist.txt");
&command_system(qq(perl  $bin_path/merge_all_overlapping_files.pl merge_all.merge.bed filelist.txt ),$debug);



sub print_list_to_file
{
	my ($ref_list,$filename)=@_;
	open FILE_OUT,">$filename";
	foreach (@$ref_list)
	{
		print FILE_OUT $_,"\n";
	}
	close FILE_OUT;
}


##&command_system(qq(),0);
sub command_system
{
	my ($command,$bool_exec)=@_;
	#print $command,"\n";
	system($command) if not $bool_exec;
}

sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}

