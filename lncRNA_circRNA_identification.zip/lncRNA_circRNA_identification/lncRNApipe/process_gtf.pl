use strict;
use warnings;

##
my $gtf_file=$ARGV[0] || "candidate_TU.gtf";
my $label=$ARGV[1] || "Athlnc";
my $type1=$ARGV[2] || "taco"; ##stringtie  taco cuffmerge cufflinks


my $i=0;
my $j=0;
my $num_cufflinks=0;
my $tname_cufflinks="";

open FILE,$gtf_file;

while(<FILE>)
{
	chomp;
	next if /^#/;
	my ($chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str)=split(/\t/,$_);
	if($type1 eq "taco")
	{
		if($type eq "transcript")
		{
			$i=0;
			$str=~/transcript_id "(.*?)"; gene_id "(.*?)";/;
			my $gname=$2;
			my $tname=$1;
			$tname=~/TU(\d+)/;
			my $tnum=$1;
			$gname=~/G(\d+)/;
			my $gnum=$1;
			my $str1="gene_id \"$label$gnum\"; transcript_id \"$label$gnum.$tnum\";";
			print join("\t",$chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str1),"\n";
		}
		if($type eq "exon")
		{
			$i++;
			$str=~/transcript_id "(.*?)"; gene_id "(.*?)";/;
			my $gname=$2;
			my $tname=$1;
			$tname=~/TU(\d+)/;
			my $tnum=$1;
			$gname=~/G(\d+)/;
			my $gnum=$1;
			my $str1="gene_id \"$label$gnum\"; transcript_id \"$label$gnum.$tnum\"; exon_number \"$i\";";
			print join("\t",$chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str1),"\n";
		}
		
		
	}
	if($type1 eq "cuffmerge")
	{
		if($type eq "gene")
		{
			next;
		}
		if($type eq "mRNA")
		{
			$i=0;
			$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
			my $gname=$1;
			my $tname=$2;
			$tname=~/TCONS_(\d+)/;
			my $tnum=$1;
			$gname=~/XLOC_(\d+)/;
			my $gnum=$1;
			my $str1="gene_id \"$label$gnum\"; transcript_id \"$label$gnum.$tnum\";";
			print join("\t",$chrom,"cuffmerge","transcript",$start,$end,$x,$strand,$y,$str1),"\n";
		}
		if($type eq "exon")
		{
			$i++;
			$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
			my $gname=$1;
			my $tname=$2;
			$tname=~/TCONS_(\d+)/;
			my $tnum=$1;
			$gname=~/XLOC_(\d+)/;
			my $gnum=$1;
			my $str1="gene_id \"$label$gnum\"; transcript_id \"$label$gnum.$tnum\"; exon_number \"$i\";";
			print join("\t",$chrom,"cuffmerge",$type,$start,$end,$x,$strand,$y,$str1),"\n";
		}
		
		
	}
	if($type1 eq "stringtie")
	{
		print $_,"\n";
	}
	if($type1 eq "cufflinks")
	{
		$num_cufflinks++;
		if($type eq "gene")
		{
			next;
		}
		if($type eq "transcript")
		{
			$i=0;
			$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
			my $gname=$1;
			my $tname=$2;
			$gname=~/CUFF\.(\d+)/;
			my $gnum=$1;
			$tname_cufflinks=$tname;
			$j++;
			my $str1="gene_id \"$label$gnum\"; transcript_id \"$label$gnum.$j\";";			
			print join("\t",$chrom,"cufflinks","transcript",$start,$end,$x,$strand,$y,$str1),"\n";
			
		}
		if($type eq "exon")
		{
			$i++;
			$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
			my $gname=$1;
			my $tname=$2;
			$gname=~/CUFF\.(\d+)/;
			my $gnum=$1;
			if($tname_cufflinks eq $tname)
			{
				my $str1="gene_id \"$label$gnum\"; transcript_id \"$label$gnum.$j\"; exon_number \"$i\";";
				print join("\t",$chrom,"cufflinks",$type,$start,$end,$x,$strand,$y,$str1),"\n";
			}
			else
			{

			}
		}
		
		
	}
}

close FILE;


__DATA__
Chr1	taco	transcript	3631	6159	1000	+	.	tss_id "TSS2"; locus_id "L1"; abs_frac "1.00000"; rel_frac "1.00000"; expr "25.058"; transcript_id "TU2"; gene_id "G2";
Chr1	taco	exon	3631	3913	1000	+	.	tss_id "TSS2"; locus_id "L1"; transcript_id "TU2"; gene_id "G2";
Chr1	taco	exon	3996	4276	1000	+	.	tss_id "TSS2"; locus_id "L1"; transcript_id "TU2"; gene_id "G2";
Chr1	taco	exon	4486	4605	1000	+	.	tss_id "TSS2"; locus_id "L1"; transcript_id "TU2"; gene_id "G2";
Chr1	taco	exon	4706	5095	1000	+	.	tss_id "TSS2"; locus_id "L1"; transcript_id "TU2"; gene_id "G2";
Chr1	taco	exon	5174	5326	1000	+	.	tss_id "TSS2"; locus_id "L1"; transcript_id "TU2"; gene_id "G2";
Chr1	taco	exon	5439	5993	1000	+	.	tss_id "TSS2"; locus_id "L1"; transcript_id "TU2"; gene_id "G2";


(py27) glogin6:/scratch/usr/bebchenl/data/RNAseqTest/polyA/linc-cuffmerge $ more t_cuffmerge_merged_v_strand.gtf   
Chr1	stringtie	gene	3631	6159	.	+	.	gene_id "XLOC_000001";
Chr1	stringtie	mRNA	4486	5899	.	+	.	gene_id "XLOC_000001"; transcript_id "TCONS_00000001";
Chr1	Cufflinks	exon	4486	4605	.	+	.	gene_id "XLOC_000001"; transcript_id "TCONS_00000001"; exon_number "3"; gene_name "AT1G01010"; oId "PAC:19656964"; cont
ained_in "TCONS_00000004"; nearest_ref "PAC:19656964"; class_code "="; tss_id "TSS1";
Chr1	Cufflinks	exon	4706	5095	.	+	.	gene_id "XLOC_000001"; transcript_id "TCONS_00000001"; exon_number "4"; gene_name "AT1G01010"; oId "PAC:19656964"; cont
ained_in "TCONS_00000004"; nearest_ref "PAC:19656964"; class_code "="; tss_id "TSS1";
Chr1	Cufflinks	exon	5174	5326	.	+	.	gene_id "XLOC_000001"; transcript_id "TCONS_00000001"; exon_number "5"; gene_name "AT1G01010"; oId "PAC:19656964"; cont
ained_in "TCONS_00000004"; nearest_ref "PAC:19656964"; class_code "="; tss_id "TSS1";
Chr1	Cufflinks	exon	5439	5899	.	+	.	gene_id "XLOC_000001"; transcript_id "TCONS_00000001"; exon_number "6"; gene_name "AT1G01010"; oId "PAC:19656964"; cont
ained_in "TCONS_00000004"; nearest_ref "PAC:19656964"; class_code "="; tss_id "TSS1";