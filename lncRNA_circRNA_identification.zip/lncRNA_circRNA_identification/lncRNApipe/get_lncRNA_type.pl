use strict;
use warnings;
use File::Basename;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

##perl get_lncRNA_type.pl  flower_lncRNA_type.txt   final_candidate_lncRNA_list.txt final_candidate_lncRNA.gff3 strtcmp.stringtie_merged_flower.gtf.tmap   /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3  1  lincRNA_class.txt 

my $file1=$ARGV[0] || 'flower_lncRNA_type.txt';
my $file2=$ARGV[1] || "final_candidate_lncRNA_list.txt";
my $file3=$ARGV[2] || 'final_candidate_lncRNA.gff3';
my $file4=$ARGV[3] || "strtcmp.stringtie_merged_flower.gtf.tmap";
my $genome_ann_gff3=$ARGV[4] || "/home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3";
my $num_neigh_bour=$ARGV[5] || 1;
my $output_file=$ARGV[6] || "lincRNA_class.txt";
my $genome_fa=$ARGV[7] || "";







##############lincRNA
&command_system(qq(perl $bin_path/get_lincRNA_type.pl  $file1  $file2   $file3   $genome_ann_gff3  $num_neigh_bour $output_file $genome_fa),0);

##############antisense lncRNA
&command_system(qq(perl  $bin_path/get_antisense_lncRNA_type.pl  $file3  $file4  $genome_ann_gff3 ),0);


##############intronic lncRNA
&command_system(qq(perl $bin_path/get_intron_lncRNA_parentgene.pl $file4  strtcmp.annotated.gtf  >  intron_parentgene.txt ),0);
&command_system(qq(perl $bin_path/get_intronlncRNA_list_gff3.pl intron_parentgene.txt   final_candidate_lncRNA_list.txt  flower_lncRNA_type.txt > intron_lncRNA_parentgene.txt  ),0);
&command_system(qq(cut -f1,1 intron_lncRNA_parentgene.txt  | sort | uniq  > intron_lncRNA_list.txt ),0);
&command_system(qq(perl $bin_path/get_list_from_bed.pl intron_lncRNA_list.txt    final_candidate_lncRNA.bed > intron_lncRNA.bed  ),0);



###########stat
#&command_system(qq(wc -l  lincRNA_class.txt ),0);
#&command_system(qq(perl $bin_path/count_antisense.pl  antisenselncRNA_type.txt ),0);
#&command_system(qq(wc -l  intron_lncRNA_parentgene.txt ),0);
#&command_system(qq(wc -l  final_candidate_lncRNA_list.txt ),0);


sub command_system
{
	my ($command,$bool_exec)=@_;
	print "CMD::\t",$command,"\n";
	system($command) if not $bool_exec;
}