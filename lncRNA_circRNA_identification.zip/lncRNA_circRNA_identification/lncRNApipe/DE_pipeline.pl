use strict;
use warnings;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path= $Bin;
my $pwd=cwd;
my $bin_name=$0;

##perl DE_pipeline.pl  DGE_rawcount/gene_count_matrix_genenames_SUB.csv  sample_file_DE.txt   DESeq2  2 0.05

my $count_matrix_file=$ARGV[0] || "DGE_rawcount/gene_count_matrix_genenames_SUB.csv";
my $DE_file=$ARGV[1] || "sample_file_DE.txt";
my $method=$ARGV[2] || "DESeq2";
my $fc=$ARGV[3] || 2;
my $q_value=$ARGV[4] || 0.05;

my $trinity_path="/mnt/h/Linux/software/trinityrnaseq-2.2.0";

if($method eq "DESeq2")
{
		######DE  test ;  DESeq2; edgeR
		##/scratch/usr/bebchenl/scripts/lncRNApipe/trinityrnaseq-Trinity-v2.4.0/Analysis/DifferentialExpression
		if(-e "DESeq2_res")
		{
			&command_system(qq(rm -rf DESeq2_res),0);
		}
		&command_system(qq(perl $bin_path/trinityrnaseq-Trinity-v2.4.0/Analysis/DifferentialExpression/run_DE_analysis.pl    --matrix  $count_matrix_file  --method  $method    --samples_file   $DE_file     -o DESeq2_res),0);
		&command_system(qq(find \$(pwd)/DESeq2_res  -name "*.DE_results" >  DEFILE_list.txt ),0);
		##find $(pwd)  -name "*.DE_results" >  DEFILE_list.txt 
		##perl  filter_DGE_genes_DESeq2.pl  DEFILE_list.txt  >  newdata_DEres.txt 
		&command_system(qq(perl  $bin_path/filter_DGE_genes_DESeq2.pl  DEFILE_list.txt $fc $q_value >  newdata_DEres.txt),0);
		&command_system(qq(perl  $bin_path/filter_DGE_genes_DESeq2.pl  DEFILE_list.txt 1.0 $q_value >  newdata_DEres.fc1.0.txt),0);
		&command_system(qq(perl  $bin_path/filter_DGE_genes_DESeq2.pl  DEFILE_list.txt 0.0001 $q_value >  newdata_DEres.noFC.txt),0);
}
if ($method eq "edgeR")
{
			if(-e "DESeq2_res")
		{
			&command_system(qq(rm -rf DESeq2_res),0);
		}
		&command_system(qq(perl $bin_path/trinityrnaseq-Trinity-v2.4.0/Analysis/DifferentialExpression/run_DE_analysis.pl    --matrix  $count_matrix_file  --method  $method    --samples_file   $DE_file     -o DESeq2_res),0);
		&command_system(qq(find \$(pwd)/DESeq2_res  -name "*.DE_results" >  DEFILE_list.txt ),0);
		##find $(pwd)  -name "*.DE_results" >  DEFILE_list.txt 
		##perl  filter_DGE_genes_DESeq2.pl  DEFILE_list.txt  >  newdata_DEres.txt 
		&command_system(qq(perl  $bin_path/filter_DGE_genes_edgeR.pl  DEFILE_list.txt $fc $q_value >  newdata_DEres.edgeR.txt),0);
		&command_system(qq(perl  $bin_path/filter_DGE_genes_edgeR.pl  DEFILE_list.txt 1.0 $q_value >  newdata_DEres.edgeR.fc1.0.txt),0);
		&command_system(qq(perl  $bin_path/filter_DGE_genes_edgeR.pl  DEFILE_list.txt 0.0001 $q_value >  newdata_DEres.edgeR.noFC.txt),0);
}

sub command_system
{
	my ($command,$bool_exec)=@_;
	print "CMD::\t",$command,"\n";
	system($command) if not $bool_exec;
}
