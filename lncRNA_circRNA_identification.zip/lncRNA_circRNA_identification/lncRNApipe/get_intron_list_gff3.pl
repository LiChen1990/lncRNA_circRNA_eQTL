use strict;
use warnings;

my $file=$ARGV[0] || 'H:\LncRNA\lncRNA_identification\public_datasets\plant_genome_wide_lnc\all_ath_lncRNA\LncRNA_type\lncRNA_type_intron.txt';
my $file1=$ARGV[1] || 'H:\LncRNA\lncRNA_identification\public_datasets\plant_genome_wide_lnc\all_ath_lncRNA\lncRNA.gff3';

my %hash=();

open FILE,$file;
while(<FILE>)
{
	chomp;
	my ($name)=(split(/\t/,$_))[0];
	$hash{$name}++;
}
close FILE;

open FILE1,$file1;
while(<FILE1>)
{
	chomp;
	my ($str)=(split(/\t/,$_))[9-1];
	##gene_id "MSTRG.3884";
	##ID=MSTRG.21060;Name=MSTRG.21060
	$str=~/ID=(.*?);/;
	if(exists $hash{$1})
	{
		print $_,"\n";
	}
}