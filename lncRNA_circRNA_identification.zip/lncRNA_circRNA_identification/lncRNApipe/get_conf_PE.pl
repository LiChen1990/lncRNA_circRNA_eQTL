use strict;
use warnings;

###perl  get_conf_PE.pl  samples_PE.txt  /home/lichen/lncRNA_project_chen/lncRNA_v2.0/chip/datasets/at/Chua_PP2016_clf  > input_conf_file_PE.txt

my $file=$ARGV[0] ;
my $str=$ARGV[1] || "/home/lichen/lncRNA_project_chen/lncRNA_v2.0/chip/datasets/at/Carles_2017_H3k4";


print "<sample>\n";
open FILE,$file;
while(<FILE>)
{
	chomp;
	my (@list)=split(/\t/,$_);
	print $list[1],"=",$str,"/$list[0]_1.fastq.gz",",",$str,"/$list[0]_2.fastq.gz\n";
}
close FILE;
print "</sample>\n";


__DATA__
SRR2136676	L_1	GSM1838953
SRR2136677	L_2	GSM1838954
SRR2136678	L_3	GSM1838955
SRR2136679	t0_1	GSM1838956
SRR2136680	t0_2	GSM1838957
SRR2136681	t0_3	GSM1838958
SRR2136682	t2_1	GSM1838959
SRR2136683	t2_2	GSM1838960
SRR2136684	t2_3	GSM1838961
SRR2136685	I_1	GSM1838962
SRR2136686	I_2	GSM1838963
SRR2136687	I_3	GSM1838964


