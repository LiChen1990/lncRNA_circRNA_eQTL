use strict;
use warnings;

my $file=$ARGV[0] || 'strtcmp.annotated.gtf';

open FILE,$file;
while(<FILE>)
{
	chomp;
	my ($chrom,$type,$start,$end,$strand,$other)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,7-1,9-1];
	if($type eq "transcript")
	{
		 $other=~/class_code \"(.*?)\";/;
		 my $class_code=$1;
		 $other=~/gene_id \"(.*?)\";/;
		my $genename=$1;
			 $other=~/transcript_id \"(.*?)\";/;
		my $transname=$1;
		my $str1=$chrom.":".$start."-".$end;
		my $str2=$chrom.":".$start."..".$end;
				if($class_code eq "i")
		{
			print join("\t",$genename,$transname,"IntronicLnRNA_i",$str1,$str2,$strand),"\n";
		}
				if($class_code eq "p")
		{
			print join("\t",$genename,$transname,"lincRNA_p",$str1,$str2,$strand),"\n";
		}
				if($class_code eq "u")
		{
			print join("\t",$genename,$transname,"lincRNA_u",$str1,$str2,$strand),"\n";
		}
				if($class_code eq "x")
		{
			print join("\t",$genename,$transname,"antisenselncRNA_x",$str1,$str2,$strand),"\n";
		}
#				if($class_code eq "s")
#		{
#			print join("\t",$genename,$transname,"antisenselncRNA_s",$str1,$str2,$strand),"\n";
#		}
#				if($class_code eq "e")
#		{
#			print join("\t",$genename,$transname,"senselncRNA_e",$str1,$str2,$strand),"\n";
#		}
#						if($class_code eq "o")
#		{
#			print join("\t",$genename,$transname,"senselncRNA_o",$str1,$str2,$strand),"\n";
#		}
#						if($class_code eq "c")
#		{
#			print join("\t",$genename,$transname,"senselncRNA_c",$str1,$str2,$strand),"\n";
#		}
#						if($class_code eq "=")
#		{
#			print join("\t",$genename,$transname,"senselncRNA_eq",$str1,$str2,$strand),"\n";
#		}
	}
}
close FILE;