use strict;
use warnings;
use List::Util qw(first max maxstr min minstr reduce shuffle sum);


my $gtf_file=$ARGV[0]  || "trans_final_lncRNA.gtf";


open FILE , $gtf_file;
my %hash=();
my %hash1=();
my %hash2=();
my $gene_flag=0;
my $mRNA_flag=0;
my $gene_name="";
my $transcript="";

while(<FILE>)
{
	chomp;
	 my ($chrom,$type,$start,$end,$strand,$str)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,7-1,9-1];
	 #$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;	
	 if($type  eq "gene")
	 {
	 	$str=~/gene_id "(.*?)";/;
	 	$hash1{$1}=join("\t",$chrom,$start,$end,$strand);
		}
	 	if($type eq "transcript")
	 	{
	 		$mRNA_flag=1;
	 		$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
	 	   $gene_name=$1;
	 		 $transcript=$2;
	 		 $hash2{$gene_name}{$transcript}=join("\t",$chrom,$start,$end,$strand);
	 	}
	 	if($type eq "exon")
	 	{
	 		my $key=join("\t",$chrom,$start,$end,$strand);
	 		$hash{$gene_name}{$transcript}.=$key."||";
	 	}
}
close FILE ;

my $seq="";

foreach my $key  (sort keys %hash)
{
	my ($gchrom,$gstart,$gend,$gstrand)=split(/\t/,$hash1{$key});
	print join("\t",$gchrom,"stringtie","gene",$gstart,$gend,".",$gstrand,".","ID=$key;Name=$key"),"\n";
	foreach my $key1 (sort keys %{$hash{$key}})
	{
		my @list=split(/\|\|/,$hash{$key}{$key1});
		my ($tchrom,$tstart,$tend,$tstrand)=split(/\t/,$hash2{$key}{$key1});
		print join("\t",$tchrom,"stringtie","transcript",$tstart,$tend,".",$tstrand,".","ID=$key1;Name=$key1;Parent=$key"),"\n";
		foreach my $str (@list)
		{
			my ($chrom,$start,$end,$strand)=split(/\t/,$str);
			print join("\t",$chrom,"stringtie","exon",$start,$end,".",$strand,".","ID=$key||$key1;Parent=$key1"),"\n";
		}
	}
}






#$hash{'orange'}{'red'} = 'red orange';
#$hash{'orange'}{'green'} = 'green orange';
#$hash{'apple'}{'red'} = 'red apple';
#$hash{'apple'}{'green'} = 'green apple';
# 
#foreach $fruit (keys %hash)
#{
#    foreach $color (keys %{$hash{$fruit}})
#    {
#        print $hash{$fruit}{$color},"\n";
#    }
#}



sub get_genome_seq_return
{
	my($genome_hash,$id,$strand,$start,$end,$fasta_title)=@_;
	if(defined($fasta_title))
	{
		if($strand eq "+")
		{
			#print ">",$fasta_title,"\n";
			return substr($$genome_hash{$id},$start-1,$end-$start+1);
		}
		else
		{
			#print ">",$fasta_title,"\n";
			return &reverse_com(substr($$genome_hash{$id},$start-1,$end-$start+1));
		}
  }
  else
  {
		if($strand eq "+")
		{
			#print ">",$id,"_",$start,"_",$end,"_",$strand,"\n";
			return substr($$genome_hash{$id},$start-1,$end-$start+1);
		}
		else
		{
			#print ">",$id,"_",$start,"_",$end,"_",$strand,"\n";
			return &reverse_com(substr($$genome_hash{$id},$start-1,$end-$start+1));
		}  	
  }
}


sub reverse_com
{
	my ($seq)=@_;
	$seq= reverse $seq;
	$seq=~tr/ATCGatcg/TAGCtagc/;
	return $seq;
}