use strict;
use warnings;

##
my $gtf_file=$ARGV[0] || "candidate_TU.gtf";

open FILE,$gtf_file;

while(<FILE>)
{
	chomp;
	my ($chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str)=split(/\t/,$_);
	$chrom=~s/Chr/chr/;
	if($strand eq ".")
	{
		$strand="+";
	}
	if($chrom ne "chrC" and  $chrom ne "chrM")
	{
		#print join("\t",$chrom,@list),"\n";
		print join("\t",$chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str),"\n";
	}
}

close FILE;