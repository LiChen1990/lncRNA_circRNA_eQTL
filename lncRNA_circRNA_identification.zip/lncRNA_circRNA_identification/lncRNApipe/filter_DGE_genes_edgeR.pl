use strict;
use warnings;
use File::Basename;

my $file_list=$ARGV[0];
my $fc_min=$ARGV[1] || 2;
my $q_value_max=$ARGV[2] || 0.05;

my @list=&load_list_from_file($file_list);

##id	Stage0_vs_Stage4	DESeq2	log2FoldChange	pvalue	padj
print join("\t","id","Cmp_group","DE_method","log2FoldChange","pvalue","padj"),"\n";


foreach my $file (sort @list)
{
	#print "processing $file\n";
	&filter_file($file);
}



sub filter_file
{
	my ($file_name)=@_;
	##table_count.txt.Air_treatment_vs_E-vapor.edgeR.DE_results
	##gene_count_matrix.csv.ag-11_ap2-43_rep_vs_ag-11_rep.DESeq2.DE_results
	my ($name_1, $path_1, $suffix_1) = fileparse ($file_name, (".DE_results"));
	##merge200.filter.txt.polyA.Stage0_vs_polyA.Stage2.edgeR.DE_results 
	$name_1=~/txt\.(.*)\.(.*)$/;
	##print $name_1,"\n";
	my $comp=$1;
	my $method=$2;
	open FILE, $file_name;
	while(<FILE>)
	{
		chomp;
		if(/logFC/)
		{
			next;
		}
		my ($name,$fc,$p_value,$q_value)=(split(/\t/,$_))[1-1,4-1,6-1,7-1];
		if($q_value<=$q_value_max and ($fc<=-$fc_min or  $fc>=$fc_min) )
		{
			print $name,"\t",join("\t",$comp,$method,$fc,$p_value,$q_value),"\n";
		}
	}
	close FILE;
}

sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	return @list;
}


__DATA__
[lichen@flower DGE_rawcount]$ more  /home/lichen/lncRNA_project_chen/lncRNA_v2.0/merge_all_lncRNA_mapping/DGE_rawcount/edgeR_res/gene_count_matrix.csv.Stage0_vs_Stage2.edgeR.DE_results 
sampleA	sampleB	logFC	logCPM	PValue	FDR
AT3G22142	Stage0	Stage2	-16.759580251226	7.85615293895158	8.11440450475378e-72	1.72244464422409e-67
AT1G61730	Stage0	Stage2	14.4453235843462	6.12831912422758	4.82460771453915e-38	5.12059739782613e-34
AT2G23120	Stage0	Stage2	14.3961333982031	6.07919757478944	8.69720813219892e-38	6.15385456740622e-34
AT2G02100	Stage0	Stage2	-7.18537459372551	5.71644597114859	4.69056926654671e-26	2.48916784552468e-22
AT2G23520	Stage0	Stage2	-13.5177109910928	4.61777064781955	1.62886488815338e-25	6.91518299616636e-22
AT5G39570	Stage0	Stage2	6.31958055948535	7.61489836772632	3.48795166922046e-25	1.23397916804238e-21