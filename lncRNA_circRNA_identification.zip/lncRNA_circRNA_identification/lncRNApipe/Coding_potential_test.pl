use strict;
use warnings;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

###perl   Coding_potential_test.pl  /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta  CNCI
###perl   Coding_potential_test.pl  /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta  CPAT
###perl   Coding_potential_test.pl  /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta  CPC2
###perl   Coding_potential_test.pl  /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta  PLEK

my $file=$ARGV[0] || "COME_input.gtf";
my $method=$ARGV[1] || "COME";
###COME CNCI CPAT PLEK iSeeRNA  CPC2


##bash /path/to/bin_subfolder/COME_main.sh /path/to/your/transcripts.gtf  /path/to/your/output_folder/    /path/to/bin_subfolder/ species model;
if($method eq "COME")
{
	&command_system(qq(perl $bin_path/prepare_COME_input_gtf.pl  $file  >  COME_input.gtf ),0);
	&command_system(qq(perl $bin_path/COME_Coding_potential_test.pl COME_input.gtf plant ),0);
	&command_system(qq(perl  $bin_path/get_COME_results.pl result.txt > noncoding_list.txt ),0);
}

if($method eq "CNCI")
{
	my $dir = $pwd;
	##&command_system(qq(cd /home/lichen/software/CPAT-1.2.3/test ),0);
	##chdir "/home/lichen/software/CPAT-1.2.3/test";
	##python /home/lichen/software/CPAT-1.2.3/test/CNCI_package/CNCI.py -f /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta -o output_dir -m pl  -p 8
	##https://github.com/www-bioinfo-org/CNCI 
	&command_system(qq(python /mnt/h/Linux/software/CNCI_package/CNCI.py -f $file.fasta   -o $dir/output_dir_CNCI -m pl  -p 8 ),0);
	&command_system(qq(perl  $dir/get_CNCI_results.pl   $dir/output_dir_CNCI/CNCI.index  > $dir/noncoding_list.txt ),0);
	##&command_system(qq(cd $dir ),0);
	chdir $dir;
}

if($method eq "CPAT")
{
	##cpat.py -g /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta     -d  /home/lichen/software/CPAT-1.2.3/test/arab.logit.RData   -x /home/lichen/software/CPAT-1.2.3/test/arab_Hexamer.tsv   -o   candidate_TU.cpat.txt  
	&command_system(qq(cpat.py -g $file.fasta      -d  /home/lichen/software/CPAT-1.2.3/test/arab.logit.RData   -x /home/lichen/software/CPAT-1.2.3/test/arab_Hexamer.tsv   -o   candidate_TU.cpat.txt   ),0);
	&command_system(qq(perl  $bin_path/get_CPAT_results.pl   candidate_TU.cpat.txt  > noncoding_list.txt ),0);
}

if($method eq "PLEK")
{
	
	## python /home/lichen/software/CPAT-1.2.3/test/PLEK.1.2/PLEK.py   -range arab.range -model arab.model  -fasta /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta   -out predicted -thread 10
	&command_system(qq( /usr/bin/python /home/lichen/software/CPAT-1.2.3/test/PLEK.1.2/PLEK.py   -range arab.range -model arab.model  -fasta $file.fasta   -out plek.results -thread 10    ),0);
	&command_system(qq(perl  $bin_path/get_PLEK_results.pl  plek.results    > noncoding_list.txt ),0);
}

if($method eq "CPC2")
{
	&command_system(qq(python $bin_path/CPC2-beta/bin/CPC2.py -i $file.fasta   -o candidate_TU.cpc2.txt    ),0);
	&command_system(qq(perl  $bin_path/get_CPC2_results.pl  candidate_TU.cpc2.txt   > noncoding_list.txt ),0);

}



sub command_system
{
	my ($command,$bool_exec)=@_;
	print "CMD::\t",$command,"\n";
	system($command) if not $bool_exec;
}