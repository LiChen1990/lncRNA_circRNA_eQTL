use strict;
use warnings;
use File::Basename;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

####perl  merge_a3_modules.pl   stringtie_merged_v.gtf      orf.txt   db_filter_list.txt  noncoding_list.txt  

my $merged_gtf_file=$ARGV[0] || "stringtie_merged_v.gtf";
my $orf_list_file=$ARGV[1] || 'orf.txt';
my $db_filter_list_file=$ARGV[2]|| 'db_filter_list.txt';
my $coding_p_list_file=$ARGV[3] || 'noncoding_list.txt';


my ($base, $path, $suffix) = fileparse( $merged_gtf_file, qr{.gtf} );


&command_system(qq(perl $bin_path/transform_stringtie_gtf_file2.pl  $merged_gtf_file > trans_$base.gtf ),0);
&command_system(qq(perl $bin_path/get_final_lncRNA_list.pl $orf_list_file $db_filter_list_file $coding_p_list_file> final_candidate_lncRNA_list.txt),0);
&command_system(qq(perl $bin_path/get_lncRNA_gtf_final1.pl final_candidate_lncRNA_list.txt $merged_gtf_file > final_candidate_lncRNA.tmp.gtf  ),0);
&command_system(qq(perl $bin_path/transform_stringtie_gtf_file2.pl  final_candidate_lncRNA.tmp.gtf >  final_candidate_lncRNA.gtf ),0);
&command_system(qq(perl $bin_path/gtf2refFlat.pl final_candidate_lncRNA.gtf  > final_candidate_lncRNA.refFlat.txt ),0);
&command_system(qq(perl $bin_path/Gtf2gff3_mine_lncRNA.pl final_candidate_lncRNA.gtf > final_candidate_lncRNA.gff3 ),0);
&command_system(qq(perl $bin_path/gtf2bed.pl final_candidate_lncRNA.gtf  gene > final_candidate_lncRNA.bed ),0);
&command_system(qq(perl $bin_path/lncRNA_trans_gtf_to_MSU_likegff3.pl final_candidate_lncRNA.gtf  > final_candidate_lncRNAMSU_likegff3.gff3 ),0);
&command_system(qq(perl $bin_path/get_g_id.pl final_candidate_lncRNA_list.txt flower_lncRNA_type.txt > final_candidate_lncRNA_list.g_id.txt ),0);

sub command_system
{
	my ($command,$bool_exec)=@_;
	print "CMD::\t",$command,"\n";
	system($command) if not $bool_exec;
}