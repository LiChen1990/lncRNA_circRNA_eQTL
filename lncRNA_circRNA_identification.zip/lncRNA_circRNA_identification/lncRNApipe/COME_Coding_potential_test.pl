use strict;
use warnings;


my $COME_gtf_file=$ARGV[0] || "COME_input.gtf";
my $species=$ARGV[1] || "plant";



##bash /path/to/bin_subfolder/COME_main.sh /path/to/your/transcripts.gtf  /path/to/your/output_folder/    /path/to/bin_subfolder/ species model;
##bash   /home/lichen/lncRNA_project_chen/lncRNA_v2.0/coding_potential/COME-master/bin/COME_main.sh   /home/lichen/lncRNA_project_chen/lncRNA_v2.0/new_data_mapping/test_cp/COME_input.gtf ./  /home/lichen/lncRNA_project_chen/lncRNA_v2.0/coding_potential/COME-master/bin   plant         plant.model  
&command_system(qq(bash   /home/lichen/lncRNA_project_chen/lncRNA_v2.0/coding_potential/COME-master/bin/COME_main.sh $COME_gtf_file  ./   /home/lichen/lncRNA_project_chen/lncRNA_v2.0/coding_potential/COME-master/bin   $species    $species.model  ),0);

sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}