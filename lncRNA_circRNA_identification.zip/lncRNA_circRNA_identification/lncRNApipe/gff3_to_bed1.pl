use strict;
use warnings;

&gff3_to_bed($ARGV[0],$ARGV[1]);


sub  gff3_to_bed
{
	my ($gff3,$feature)=@_;
	open FILE,$gff3;
	while(<FILE>)
	{
		chomp;
		if(/^#/ or /^\s*$/)
		{
			next;
		}
		my ($chrom,$type,$start,$end,$strand,$str)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,7-1,9-1];
		if($type eq "gene")
		{
#			$str=~/Name=(.*);?/;
#			print join("\t",$chrom,$start-1,$end,$1,$feature,$strand),"\n";
			my %hash=();
		  my (@list)=split(/;/,$str);
		  foreach my $str1 (@list)
		  {
		    my @list1=split(/=/,$str1);
		    $hash{$list1[0]}=$list1[1];
		  }
		  my $gene_id=&check_exists_hash("gene_id",%hash);
		  my $gene_type=&check_exists_hash("gene_type",%hash);
		  my $gene_name=&check_exists_hash("gene_name",%hash);
		  my $hgnc_id=&check_exists_hash("hgnc_id",%hash);
		  #print join("\t",$gene_id,$gene_name,$hgnc_id,$gene_type,$chrom,$start,$end,$strand),"\n";
		  my @list_names=("gene_name","gene_id","ID","Name");
		  foreach my $name (@list_names)
		  {
		  	if(exists $hash{$name})
		  	{
		  		print join("\t",$chrom,$start-1,$end,$hash{$name},$feature,$strand),"\n";
		  		last;
		  	}
		  }
		}
	}
	close FILE;
}

sub  check_exists_hash
{
	my ($key,%hash)=@_;
	if(exists $hash{$key})
	{
	  return $hash{$key};
	}
	else
	{
		return "";
	}
}

