use strict;
use warnings;

my $list_file=$ARGV[0];
my $bed_file=$ARGV[1];

my %hash=&list_file2hash($list_file);


open FILE,$bed_file;
while(<FILE>)
{
	chomp;
	my ($chrom,$start,$end,$name,$score,$strand)=split(/\t/,$_);
	if(exists $hash{$name})
	{
		print $_,"\n";
	}
	
}
close FILE;


sub list_file2hash
{
	my ($list_file)=@_;
	open FILE,$list_file;
	my %hash=();
	while(<FILE>)
	{
		chomp;
		$hash{$_}++;
	}
	close FILE;
	return %hash;
}
