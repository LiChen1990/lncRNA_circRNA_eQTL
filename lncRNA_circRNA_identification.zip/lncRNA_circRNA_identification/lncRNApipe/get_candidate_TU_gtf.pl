use  strict;
use warnings;


##perl get_candidate_TU_gtf.pl flower_lncRNA_type.txt  stringtie_merged_v.gtf >  candidate_TU.gtf 
my $file=$ARGV[0] || "flower_sample_lncRNA_type.txt";
my $gtf_file=$ARGV[1] || "stringtie_merged_v.gtf";


open FILE,$file;
my %hash=();
while(<FILE>)
{
	chomp;
#my ($chrom,$type,$start,$end,$name,$strand)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,9-1,7-1];
  my ($g_name,$t_name)=(split(/\t/,$_))[1-1,2-1];
  $hash{$t_name}++;
}
close FILE;


open FILE, $gtf_file;
while(<FILE>)
{
	chomp;
	next if /^#/;
	my ($chrom,$type,$start,$end,$name,$strand)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,9-1,7-1];
	 $name=~/transcript_id "(.*?)";/;
	 my $t_name=$1;
	 if(exists $hash{$t_name})
	 {
	 	print $_,"\n";
	 }
}
close FILE;