use strict;
use warnings;
use File::Basename;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

##perl  get_lincRNA_neighbour_genes_list.pl  lincRNA.gff3  /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3    1   lincRNA_class.txt
my $lincRNA_gff3=$ARGV[0] ||'lincRNA.gff3';
my $genome_gff3=$ARGV[1] || '/home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3';
my $num_neigh=$ARGV[2] || 1;
my $out_name=$ARGV[3] || "lincRNA_class.txt";

&command_system(qq(dos2unix  $lincRNA_gff3 ),0);
&command_system(qq(perl $bin_path/gff3_to_bed.pl $lincRNA_gff3 lincRNA > l_bed.bed),0);
&command_system(qq(perl $bin_path/gff3_to_bed.pl $genome_gff3  gene > g_bed.bed),0);
&command_system(qq(perl $bin_path/get_nei_list_many.pl g_bed.bed l_bed.bed $num_neigh > $out_name ),0);
##&command_system(qq(sort -k1,1 -k2,2n -k6,6 ALL_bed.bed >  ALL_sort.bed),0);
##&command_system(qq(perl  get_nei_list.pl ALL_sort.bed $lincRNA_list $num_neigh > $out_name),0);

sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}