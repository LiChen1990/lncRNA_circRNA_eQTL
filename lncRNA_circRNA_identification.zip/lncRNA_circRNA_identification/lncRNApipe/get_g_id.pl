use strict;
use warnings;

my $file1=$ARGV[0] || "final_candidate_lncRNA_list.txt"; 
my $file2=$ARGV[1] || "flower_lncRNA_type.txt";

my %hash=();
open FILE,$file2;
while(<FILE>)
{
	chomp;
	my ($g_id,$t_id,$type)=split(/\t/,$_);
	$hash{$t_id}=$g_id;
}
close FILE;

my %hash1=();
open FILE,$file1;
while(<FILE>)
{
	chomp;
	my $t_id=$_;
	if(exists $hash{$t_id})
	{
	   $hash1{$hash{$t_id}}++; 
	}
}
close FILE;

foreach (keys %hash1)
{
  print $_,"\n";
}