use strict;
use warnings;
use List::Util qw(first max maxstr min minstr reduce shuffle sum);


my $gtf_file=$ARGV[0] ||  "merged.gtf";
open FILE , $gtf_file;
my %hash=();
my %hash1=();
while(<FILE>)
{
	chomp;
	#next if $.==1 or $.==2;
	 my ($chrom,$start,$end,$strand,$str)=(split(/\t/,$_))[1-1,4-1,5-1,7-1,9-1];
	$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
	 my $gene_name=$1;
	 my $transcript=$2;
	$hash{$gene_name}{$transcript}.=join("\t",$start,$end)."\t";
	$hash1{$gene_name}.=join("\t",$start,$end)."\t";
}
close FILE ;

foreach my $key  (keys %hash)
{
	foreach my $key1 (keys %{$hash{$key}})
	{
		my @list=split(/\t/,$hash{$key}{$key1});
		my $start=min @list;
		my $end=max @list;
		$hash{$key}{$key1}=join("\t",$start,$end);
	}
}

foreach my $key  (keys %hash1)
{
			my @list=split(/\t/,$hash1{$key});
		my $start=min @list;
		my $end=max @list;
		$hash1{$key}=join("\t",$start,$end);
}


open FILE , $gtf_file;
while(<FILE>)
{
	chomp;
	#next if $.==1 or $.==2;
	 my ($chrom,$type,$start,$end,$strand,$str)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,7-1,9-1];
	$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
	 my $gene_name=$1;
	 my $transcript=$2;
	 		if(exists $hash1{$gene_name})
	{
		print join("\t",$chrom,"stringtie\tgene",$hash1{$gene_name},".\t$strand\t.","gene_id \"$gene_name\"; gene_type \"lncRNA\"; transcript_type \"lncRNA\";"),"\n";
		delete  $hash1{$gene_name};
	}
	if(exists $hash{$gene_name}{$transcript})
	{
		print join("\t",$chrom,"stringtie\ttranscript",$hash{$gene_name}{$transcript},".\t$strand\t.","gene_id \"$gene_name\"; transcript_id \"$transcript\"; gene_type \"lncRNA\"; transcript_type \"lncRNA\";"),"\n";
		delete  $hash{$gene_name}{$transcript};
	}
	if($type ne "transcript")
	{
		#print $_,"\n";
		print join(" ",$_,"gene_type \"lncRNA\";","transcript_type \"lncRNA\";"),"\n";
	}
}
close FILE ;




#$hash{'orange'}{'red'} = 'red orange';
#$hash{'orange'}{'green'} = 'green orange';
#$hash{'apple'}{'red'} = 'red apple';
#$hash{'apple'}{'green'} = 'green apple';
# 
#foreach $fruit (keys %hash)
#{
#    foreach $color (keys %{$hash{$fruit}})
#    {
#        print $hash{$fruit}{$color},"\n";
#    }
#}