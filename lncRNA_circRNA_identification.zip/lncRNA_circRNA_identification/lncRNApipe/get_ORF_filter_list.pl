use strict;
use warnings;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;


my $transcripts_seq=$ARGV[0] || "candidate_TU.gtf.fasta";

&command_system(qq(perl $bin_path/get_orf_size.pl $transcripts_seq ),0);
&command_system(qq(perl $bin_path/get_orf_results_list.pl test_lenfilterleft.fa > orf.txt),0);

sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}