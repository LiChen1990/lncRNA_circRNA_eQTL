use strict;
use warnings;
use File::Basename;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;


### perl  get_final_candidate_lncRNA.pl  stringtie_merged_flower.gtf db_filter_list.txt  > log.txt

my $merged_gtf_file=$ARGV[0] || "stringtie_merged_v.gtf";
my $db_filter_list_file=$ARGV[1]|| '/mnt/h/Linux/lncRNApipe/db_filter_list.txt';
my $reference_ann_file=$ARGV[2] || "/mnt/h/Linux/Athaliana_167_gene.gff3";
my $ref_genome_fasta=$ARGV[3] || "/mnt/h/Linux/Athaliana_167.fa";
my $cp_software=$ARGV[4] || "COME";
#####COME CNCI CPAT PLEK iSeeRNA  CPC2

###input files: 
###output results files:
#final_candidate_lncRNA_list.txt
#final_candidate_lncRNA.gtf
#final_candidate_lncRNA.refFlat.txt 
#final_candidate_lncRNA.gff3
#final_candidate_lncRNAMSU_likegff3.gff3

##lincRNA_class.txt
##antisenselncRNA_type.txt 
##intron_lncRNA_parentgene.txt  

my ($base, $path, $suffix) = fileparse($merged_gtf_file, (".txt",".gtf") );
##../strtcmp.stringtie_merged_v.gtf.tmap
my $tmap_file="$path/strtcmp.$base$suffix.tmap";

################get_candidate_TU_seq
&command_system(qq(perl  $bin_path/get_candidate_TU_seq.pl  $merged_gtf_file  $reference_ann_file $ref_genome_fasta ),0);

################get_ORF_filter_list
&command_system(qq(perl  $bin_path/get_ORF_filter_list.pl   candidate_TU.gtf.fasta),0);

################coding potential
&command_system(qq(perl  $bin_path/Coding_potential_test.pl candidate_TU.gtf  $cp_software ),0);

################db filter list
&command_system(qq(),0);

################merge results
&command_system(qq(perl  $bin_path/merge_a3_modules.pl $merged_gtf_file   orf.txt   $db_filter_list_file noncoding_list.txt  ),0);
&command_system(qq(perl  $bin_path/get_summary_stats.pl  flower_lncRNA_type.txt  test_RNAlen_ORFlen_info.txt orf.txt  $db_filter_list_file candidate_TU.cpc2.txt noncoding_list.txt  final_candidate_lncRNA_list.txt   > final_candidate_lncRNA_list.summary.txt  ),0);

################stat of results
##another solution for getting cDNA fasta ?? perl  $bin_path/Get_gtf_cds_seq.pl final_candidate_lncRNA.gtf fasta 
&command_system(qq(perl  $bin_path/trinityrnaseq-Trinity-v2.4.0/util/cufflinks_gtf_genome_to_cdna_fasta.pl final_candidate_lncRNA.gtf $ref_genome_fasta  > final_candidate_lncRNA.gtf.transcripts.fasta),0);

&command_system(qq(perl  $bin_path/get_lncRNA_type_forgffcompare.pl strtcmp.annotated.gtf >  flower_lncRNA_type.txt ),0);  ##../strtcmp.stringtie_merged_v.gtf.tmap
&command_system(qq(perl $bin_path/get_lncRNA_type.pl  flower_lncRNA_type.txt   final_candidate_lncRNA_list.g_id.txt  final_candidate_lncRNA.gff3 $tmap_file   $reference_ann_file  1  lincRNA_class.txt $ref_genome_fasta ),0);

&command_system(qq(perl  $bin_path/Ann_type_for_lncRNA_v2.pl  final_candidate_lncRNA_list.g_id.txt  lincRNA_class.txt   intron_lncRNA_parentgene.txt  antisense_lncRNA_parentgene.type.txt   final_candidate_lncRNA.gff3 > final_candidate_lncRNA_list_type.txt ),0);
 

####put all final results files  into a fold
if(not -e "all_final_results")
{
  &command_system(qq(mkdir all_final_results),0);
}
else 
{
	&command_system(qq(rm -rf  all_final_results),0);
	&command_system(qq(mkdir all_final_results),0);
}

&command_system(qq(cp final_candidate_lncRNA_list.txt all_final_results/ ),0);
&command_system(qq(cp final_candidate_lncRNA_list.g_id.txt all_final_results/ ),0);
&command_system(qq(cp log2.txt all_final_results/ ),0);
&command_system(qq(cp final_candidate_lncRNA_list.summary.txt all_final_results/ ),0);
&command_system(qq(cp final_candidate_lncRNA_list_type.txt all_final_results/ ),0);
&command_system(qq(cp final_candidate_lncRNA.gtf  all_final_results/ ),0);
&command_system(qq(cp final_candidate_lncRNA.refFlat.txt   all_final_results/ ),0);
&command_system(qq(cp final_candidate_lincRNA.refFlat.txt   all_final_results/ ),0);
&command_system(qq(cp final_candidate_lncRNA.gff3  all_final_results/ ),0);
&command_system(qq(cp final_candidate_lncRNAMSU_likegff3.gff3  all_final_results/ ),0);
&command_system(qq(cp final_candidate_lncRNA.gtf.transcripts.fasta  all_final_results/ ),0);
&command_system(qq(cp lincRNA_class.txt  all_final_results/ ),0);
&command_system(qq(cp antisense_lncRNA_parentgene.type.txt  all_final_results/ ),0);
&command_system(qq(cp antisense_lncRNA_list.txt   all_final_results/ ),0);
&command_system(qq(cp antisense_lncRNA.bed  all_final_results/ ),0);
&command_system(qq(cp intron_lncRNA_parentgene.txt    all_final_results/ ),0);
&command_system(qq(cp intron_lncRNA_list.txt    all_final_results/ ),0);
&command_system(qq(cp intron_lncRNA.bed     all_final_results/ ),0);
&command_system(qq(cp lincRNA.gene.gff3    all_final_results/ ),0);
&command_system(qq(cp  lincRNA_class.classify.txt    all_final_results/ ),0);
&command_system(qq(cp  lincRNA_list_loci_seq.fasta    all_final_results/ ),0);
&command_system(qq(cp  lincRNA_transcripts_seq.fasta    all_final_results/ ),0);
&command_system(qq(cp  lincRNA_list_loci.txt   all_final_results/ ),0);
&command_system(qq(cp  lincRNA.bed  all_final_results/ ),0);
&command_system(qq(cp  final_candidate_lincRNA.gff3   all_final_results/ ),0);
&command_system(qq(cp  final_candidate_lincRNA.bed12  all_final_results/ ),0);
&command_system(qq(cp  final_candidate_lncRNA.bed12   all_final_results/ ),0);
&command_system(qq(cp  final_candidate_lincRNA.gtf  all_final_results/ ),0);


sub command_system
{
	my ($command,$bool_exec)=@_;
	print "CMD::\t",$command,"\n";
	system($command) if not $bool_exec;
}


#CMD::	wc -l  lincRNA_class.txt 
#365 lincRNA_class.txt
#CMD::	perl count_antisense.pl  antisenselncRNA_type.txt 
#195	antisenselncRNA_type.txt
#CMD::	wc -l  intron_lncRNA_parentgene.txt 
#12 intron_lncRNA_parentgene.txt
#CMD::	wc -l  final_candidate_lncRNA_list.txt 
#572 final_candidate_lncRNA_list.txt