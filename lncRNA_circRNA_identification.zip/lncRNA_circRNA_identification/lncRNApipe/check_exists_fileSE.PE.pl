use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

my $genome_file="";###genome_index_name
my $config_file="";
my $gtf_file="";
my $debug;
my %hash_config=();
my $thread_num;
my $aver_file="";


GetOptions(
          "debug!"=>\$debug,
          "conf=s"=>\$config_file,
          "genome=s"=>\$genome_file,
          "thread=i"=>\$thread_num
);

my  $conf = Config::General->new($config_file);
%hash_config = $conf->getall;

my @list1=();
my @list1_bam=();


my $MAX_PROCESSES=$thread_num;




&command_system(qq(dos2unix $config_file ),$debug);



foreach my $sample_name (keys %{$hash_config{"sample"}})
{
	push(@list1,(split(/,/,$hash_config{"sample"}{$sample_name}))[0]);
}

foreach  my $fastq_name (@list1)
{
	
	my ($name_1, $path_1, $suffix_1) = fileparse ($fastq_name, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));	
	my $SE_PE="SE";
	my $tmp_name=$name_1;
	$tmp_name=~s/_1$/_2/;
	#print "$path_1$tmp_name$suffix_1","\n";
	if(-e "$path_1$tmp_name$suffix_1")
	{
		$SE_PE="PE";
		#print "$path_1$tmp_name$suffix_1","\n";
	}
	if(not -e $fastq_name)
	{
		print $SE_PE,"\t",$fastq_name ,"\n";
	}
}



#$aver_file=$kallisto_averfile;
#
#####Get expression
#&command_system(qq(perl  $bin_path/merge_featurecount_value.pl  kallisto_abund_list.txt  >  chrX_genes_results_genenames_SUB.txt  ),$debug);
#&command_system(qq(perl $bin_path/filter_low_expressed_genes.pl  chrX_genes_results_genenames_SUB.txt 0.5 1   > chrX_genes_results_genenames_SUB_filter_low.txt  ),$debug);
#&command_system(qq(perl  $bin_path/get_average_val_noRPKM.pl  $aver_file  chrX_genes_results_genenames_SUB_filter_low.txt  chrX_genes_results_genenames_SUB_filter_low_aver.txt  ),$debug);
#my $aver_sample_file1=$aver_file;
#$aver_file=~s/\.txt$//;
#&command_system(qq( perl $bin_path/process-aver-file2DE-file.pl $aver_sample_file1 > ${aver_file}-DE.txt  ),$debug);
#
####DE
#&command_system(qq(perl  $bin_path/merge_featurecount_value.pl  kallisto_count_list.txt  >  merge200.txt ),$debug);
#&command_system(qq(perl  $bin_path/filter_low_expressed_genes.pl  merge200.txt  2 1  merge200.txt  >  merge200.filter.txt ),$debug);
###&command_system(qq(perl  $bin_path/DE_pipeline.pl  merge200.filter.txt  ${aver_file}-DE.txt  DESeq2  2 0.05),$debug);
#
#
####=====results
#&command_system(qq(mkdir results-kallisto-DESeq2),$debug);
#&command_system(qq(cp chrX_genes_results_genenames_SUB_filter_low_aver.txt results-kallisto-DESeq2/  ),$debug);
#&command_system(qq(cp chrX_genes_results_genenames_SUB_filter_low.txt results-kallisto-DESeq2/  ),$debug);
###&command_system(qq(cp   newdata_DEres.txt  results-kallisto-DESeq2/   ),$debug);
###&command_system(qq(cp  newdata_DEres.fc1.0.txt  results-kallisto-DESeq2/   ),$debug);
#&command_system(qq(cp   merge200.filter.txt  results-kallisto-DESeq2/   ),$debug);

sub build_kallisto_index
{
	my ($fasta_file,$debug)=@_;
	my $kallisto_path="kallisto";
	&command_system(qq($kallisto_path index -i ${fasta_file}_index    -k 31  $fasta_file ),$debug);
}

sub  kallisto_PE
{
	my($index_name,$fastq1,$fastq2,$out_name,$debug)=@_;
	my $kallisto_path="/gfs1/work/bebchenl/lncRNA/lichen/RNAseq/kallisto_linux-v0.44.0/kallisto";
	&command_system(qq(rm -rf run_pbs.$out_name.sh ),$debug);
	&command_pbs(qq($kallisto_path quant -t 6 -i $index_name -o $out_name --single -l 200 -s 20 $fastq1  $fastq2 ),$out_name,$debug);
	&command_pbs_app(qq(cut -f1,5  $out_name/abundance.tsv | sed '1,1d' > $out_name/TPM_abundance.txt),$out_name,$debug);
	&command_pbs_app(qq(cut -f1,4  $out_name/abundance.tsv | sed '1,1d' > $out_name/Count_abundance.txt),$out_name,$debug);
	&command_pbs_app(qq(find \$(pwd)/$out_name  -name "TPM_abundance.txt" >> kallisto_abund_list.txt),$out_name,$debug);
	&command_pbs_app(qq(find \$(pwd)/$out_name  -name "Count_abundance.txt" >> kallisto_count_list.txt),$out_name,$debug);
	&command_system(qq(msub  run_pbs.$out_name.sh ),$debug);
}

sub  kallisto_SE
{
	my($index_name,$fastq1,$out_name,$debug)=@_;
	my $kallisto_path="/gfs1/work/bebchenl/lncRNA/lichen/RNAseq/kallisto_linux-v0.44.0/kallisto";
	&command_system(qq(rm -rf run_pbs.$out_name.sh ),$debug);
	&command_pbs(qq($kallisto_path quant -t 6 -i $index_name -o $out_name --single -l 200 -s 20 $fastq1),$out_name,$debug);
	&command_pbs_app(qq(cut -f1,5  $out_name/abundance.tsv | sed '1,1d' > $out_name/TPM_abundance.txt),$out_name,$debug);
	&command_pbs_app(qq(cut -f1,4  $out_name/abundance.tsv | sed '1,1d' > $out_name/Count_abundance.txt),$out_name,$debug);
	&command_pbs_app(qq(find \$(pwd)/$out_name  -name "TPM_abundance.txt" >> kallisto_abund_list.txt),$out_name,$debug);
	&command_pbs_app(qq(find \$(pwd)/$out_name  -name "Count_abundance.txt" >> kallisto_count_list.txt),$out_name,$debug);
	
	&command_system(qq(msub  run_pbs.$out_name.sh ),$debug);

}


#  &command_pbs("aprun  bash $name_1.sh",$name_1,$bool_exec);	
#  &command_system(qq(msub  run_pbs.$name_1.sh ),$bool_exec);
  
sub command_pbs
{
	my ($command,$name,$bool_exec)=@_;
	open FILE,">>run_pbs.$name.sh";
	print FILE "#PBS -l walltime=48:0:00\n";
	print FILE "#PBS -l nodes=1:ppn=4\n";
	print FILE "#PBS -l feature=prepost2\n";
	print FILE $command,"\n";
	close FILE;
}

sub command_pbs_app
{
	my ($command,$name,$bool_exec)=@_;
	open FILE,">>run_pbs.$name.sh";
#	print FILE "#PBS -l walltime=48:0:00\n";
#	print FILE "#PBS -l nodes=1:ppn=4\n";
#	print FILE "#PBS -l feature=prepost2\n";
	print FILE $command,"\n";
	close FILE;
}

sub command_system_bash
{
	my ($command,$bool_exec)=@_;
	my $num=int(rand()*100000000);
	open FILE,">$num.sh";
	print FILE $command,"\n";
	close FILE;
	print $command,"\n";
	system("bash $num.sh") if not $bool_exec;
	unlink("$num.sh");
}


sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}


__DATA__
kallisto index -i Trinity_tit_chnage.fasta_index    -k 31  Trinity_tit_chnage.fasta 
kallisto quant -i Trinity_tit_chnage.fasta_index  -o output --single -l 200 -s 20 reads.left.fq 
kallisto quant -i Trinity_tit_chnage.fasta_index -o  PE_res.txt reads.left.fq  reads.right.fq 


