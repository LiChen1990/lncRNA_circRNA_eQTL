use strict;
use warnings;

my $file=$ARGV[0] || " antisenselncRNA_type.txt";

my %hash=();
open FILE,$file;
while(<FILE>)
{
	chomp;
	my ($name)=(split(/\t/,$_))[0];
	$hash{$name}++;
}
close FILE;

my $count=scalar  keys  %hash;
print $count,"\t",$file,"\n"; ;