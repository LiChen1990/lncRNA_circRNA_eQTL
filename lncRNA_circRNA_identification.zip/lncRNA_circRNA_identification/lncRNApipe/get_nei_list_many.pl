use strict;
use warnings;

###perl  get_nei_list_many.pl  g_bed.bed   l_bed.bed  10  >  res10.txt 

my $file=$ARGV[0] || 'H:\LncRNA\lncRNA_identification\public_datasets\plant_genome_wide_lnc\all_ath_lncRNA\neighbour_genes\list\g_bed.bed';
my $lincRNA=$ARGV[1] ||'H:\LncRNA\lncRNA_identification\public_datasets\plant_genome_wide_lnc\all_ath_lncRNA\neighbour_genes\list\l_bed.bed';
#my $is_strand=$ARGV[2] || 0;
my $num_neigh=$ARGV[2] || 1;


my @array_2D=&load_2D_array_from_file($file);

open FILE, $lincRNA;
while(<FILE>)
{
	chomp;
	my ($chrom,$start,$end,$name,$score,$strand)=split(/\t/,$_);
	my @array_2D_tmp=@array_2D;
	push(@array_2D_tmp,[split(/\t/,$_)]);
	@array_2D_tmp=sort {$a->[0] cmp $b->[0] || $a->[1] <=> $b->[1]} @array_2D_tmp;
	for(my $i=0;$i<scalar @array_2D_tmp;$i++)
	{
		my $name1=$array_2D_tmp[$i]->[3];
		if($name1 eq $name)
		{
						for(my $j=1;$j<=$num_neigh;$j++)
			{
				#print  join("\t",$name,$list[$rank-2],$list[$rank]),"\n";
				#print $name,"\t",$list[$rank-1-$i],"\t",$list[$rank-1+$i],"\t";
				my $left_chr=$array_2D_tmp[$i-$j]->[0];
				my $left_start=$array_2D_tmp[$i-$j]->[1];
				my $left_end=$array_2D_tmp[$i-$j]->[2];
				my $left_strand=$array_2D_tmp[$i-$j]->[5];
				my  $left_name=$array_2D_tmp[$i-$j]->[3];
				
					my $right_chr=$array_2D_tmp[$i+$j]->[0];
				my $right_start=$array_2D_tmp[$i+$j]->[1];
				my $right_end=$array_2D_tmp[$i+$j]->[2];
				my $right_strand=$array_2D_tmp[$i+$j]->[5];
				my  $right_name=$array_2D_tmp[$i+$j]->[3];
				print join("\t",$left_name,$name1,$right_name,$start-$left_end,$left_strand,$right_start-$end,$right_strand,$strand),"\t";
				if($strand eq ".")
				{
					if($start-$left_end <$right_start-$end)
					{

						print $left_name,"\t","lincRNA.unknownstrand\n";
						next;
	
					}
					else
					{
						print $right_name,"\t","lincRNA.unknownstrand\n";
						next;
					}
				}
				if($start-$left_end <$right_start-$end)
				{
					if($strand eq $left_strand)
					{
						if ($start-$left_end<=2000)
						{
							print $left_name,"\t","lincRNA.artifacts.terminator\n";
						}
						else
						{
							print $left_name,"\t","lincRNA.SSlincRNA.downstream\n";
						}
					}
					else
					{
						 if($strand eq "+" and $left_strand eq "-")
						 {
							 	if ($start-$left_end<=2000)
							 	{
							 		print $left_name,"\t","lincRNA.divergent.promoter\n";
							 	}
							 	else
							 	{
							 		print $left_name,"\t","lincRNA.divergent.other\n";
							 	}
							}
							if($strand eq "-" and $left_strand eq "+")
						 {
						 	  if ($start-$left_end<=2000)
						 	  {
						 	  	print $left_name,"\t","lincRNA.convergent.terminator\n";
						 	  }
						 	  else
						 	  {
						 	  	print $left_name,"\t","lincRNA.convergent.other\n";
						 	  }
							}
					}
				}
				else
				{
										if($strand eq $right_strand)
					{
						#AT1G41830	Di2014PJ_lncRNA_40__TCONS_00010026	AT1G41875	36074	-	5858	+	-	
						if ($right_start-$end<=2000)
						{
							print $right_name,"\t","lincRNA.artifacts.promoter\n";
						}
						else
						{
							print $right_name,"\t","lincRNA.SSlincRNA.upstream\n";
						}
					}
					else
					{
						 if($strand eq "+" and $right_strand eq "-")
						 {
							 	if ($right_start-$end<=2000)
							 	{
							 		print $right_name,"\t","lincRNA.convergent.terminator\n";
							 	}
							 	else
							 	{
							 		print $right_name,"\t","lincRNA.convergent.other\n";
							 	}
							}
							if($strand eq "-" and $right_strand eq "+")
						 {
						 	  if ($right_start-$end<=2000)
						 	  {
						 	  	print $right_name,"\t","lincRNA.divergent.promoter\n";
						 	  }
						 	  else
						 	  {
						 	  	print $right_name,"\t","lincRNA.divergent.other\n";
						 	  }
							}
					}
				}
			}
		}
	}
}

close FILE;
 


 

 

sub load_2D_array_from_file
{
	my ($filename)=@_;
	my @ref_array;
	open ARRAY_FILE,$filename;
	while(<ARRAY_FILE>)
	{
		chomp;
		push(@ref_array,[split(/\t/,$_)]);
	}
	close ARRAY_FILE;
	return @ref_array;
}