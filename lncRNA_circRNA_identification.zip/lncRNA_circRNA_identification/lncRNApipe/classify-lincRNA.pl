use strict;
use warnings;

my $file=$ARGV[0] || 'H:\LncRNA\lncRNA_identification\public_datasets\plant_genome_wide_lnc\all_ath_lncRNA\Reducnt_lncRNA\res\scripts\result_v1\final_candidate_lincRNA_list_type.txt';


open FILE,$file;

while(<FILE>)
{
	chomp;
	my ($name,$type)=(split(/\t/,$_))[1-1,10-1];
	if($type eq "lincRNA.convergent.terminator")
	{
		print "LC\t","LCP","\t",$_,"\n";
	}
	
		if($type eq "lincRNA.convergent.other")
	{
		print "LC\t","LCD","\t",$_,"\n";
	}
	
		if($type eq "lincRNA.divergent.promoter")
	{
		print "LD\t","LDP","\t",$_,"\n";
	}
	
		if($type eq "lincRNA.divergent.other")
	{
		print "LD\t","LDD","\t",$_,"\n";
	}
	
		if($type eq "lincRNA.artifacts.promoter" or $type eq "lincRNA.artifacts.terminator")
	{
		print "LS\t","LSP","\t",$_,"\n";
	}
	
		if($type eq "lincRNA.SSlincRNA.upstream" or $type eq "lincRNA.SSlincRNA.downstream")
	{
		print "LS\t","LSD","\t",$_,"\n";
	}
	
	
	
	
}

