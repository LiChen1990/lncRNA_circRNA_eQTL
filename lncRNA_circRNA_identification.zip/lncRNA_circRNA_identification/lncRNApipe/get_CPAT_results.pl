use strict;
use warnings;

my $file=$ARGV[0];

my %hash=();
open FILE,$file;
while(<FILE>)
{
	chomp;
	next if $.==1;
	my ($id ,$score)=(split(/\t/,$_))[1-1,5-1];
	if($score < 0.36)
	{
		if($id=~/(.*)\.(\d+)/)
		{
		##MSTRG.10016.3
		$hash{$1}++;
		}
	}
}
close FILE;

foreach (sort keys %hash)
{
	print $_,"\n";
}



__DATA__
cpat.py -g /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta     -d  /home/lichen/software/CPAT-1.2.3/test/arab.logit.RData   -x /home/lichen/software/CPAT-1.2.3/test/arab_Hexamer.tsv   -o   candidate_TU.cpat.txt  

[lichen@flower pv1.2]$ more  candidate_TU.cpat.txt  
mRNA_size	ORF_size	Fickett_score	Hexamer_score	coding_prob
ATLNC.5175.1	327	147	0.9927	-0.217843851503	2.13904371247684e-07
ATLNC.5742.1	782	147	0.8946	-0.048560606353	2.22044604925031e-16
ATLNC.4166.1	932	186	0.6122	-0.287085737165	2.22044604925031e-16
ATLNC.6571.1	201	84	0.9317	-0.342087975501	1.76140113748899e-05
ATLNC.2750.1	725	120	0.711	-0.155936333745	2.22044604925031e-16
ATLNC.4019.1	340	90	0.9167	-0.111915410641	5.6906497953181e-10
ATLNC.3917.1	242	207	0.6845	-0.299241510015	0.0741897896068312
ATLNC.2840.1	263	138	1.0171	0.0643938615081	0.000108975158067995
ATLNC.4970.1	980	249	0.7862	-0.107255645139	2.22044604925031e-16
ATLNC.3744.1	1298	162	0.9151	-0.209237597045	2.22044604925031e-16
ATLNC.3973.1	232	36	0.7143	-0.582824149416	3.85520556843266e-09