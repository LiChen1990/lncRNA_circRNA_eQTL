use strict;
use warnings;
use File::Basename;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

###perl  get_antisense_lncRNA_type.pl  final_candidate_lncRNA.gff3  strtcmp.stringtie_merged_flower.gtf.tmap  /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3

my $file1=$ARGV[0] || "final_candidate_lncRNA.gff3";
my $file2=$ARGV[1] || "strtcmp.stringtie_merged_flower.gtf.tmap";
my $file3=$ARGV[2] || "/home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3";


&command_system(qq(perl $bin_path/get_antisense_lncRNA_parentgene.pl $file2 strtcmp.annotated.gtf   > antisense_parentgene.txt  ),0);
&command_system(qq(perl $bin_path/get_antisenselncRNA_list_gff3.pl  antisense_parentgene.txt   final_candidate_lncRNA_list.txt  flower_lncRNA_type.txt > antisense_lncRNA_parentgene.txt ),0);
&command_system(qq(cut -f1,1  antisense_lncRNA_parentgene.txt | sort | uniq  > antisense_lncRNA_list.txt  ),0);
&command_system(qq(perl $bin_path/get_list_from_bed.pl antisense_lncRNA_list.txt   final_candidate_lncRNA.bed > antisense_lncRNA.bed ),0);
&command_system(qq(perl $bin_path/gff3_to_bed1.pl $file3  gene > g_bed1.bed),0);
&command_system(qq(perl $bin_path/get_special_antisenselncRNA.pl  antisense_lncRNA.bed  g_bed1.bed antisense_lncRNA_parentgene.txt  > antisense_lncRNA_parentgene.type.txt ),0);
##&command_system(qq( ),0);

sub command_system
{
	my ($command,$bool_exec)=@_;
	print "CMD::\t",$command,"\n";
	system($command) if not $bool_exec;
}