use strict;
use warnings;


my $list_file=$ARGV[0]|| 'H:\LncRNA\lncRNA_identification\pipeline_hisat2_stringtie\identification_lncRNA\final_results\final_lncRNA_list.txt';
my $trans_gtf_file=$ARGV[1] || 'H:\LncRNA\lncRNA_identification\pipeline_hisat2_stringtie\identification_lncRNA\trans_stringtie_merged_v2.0.gtf';


open FILE,$list_file;
my %hash=();


while(<FILE>)
{
	chomp;
	my ($name)=split(/\t/,$_);
	$hash{$name}++;
}
close FILE;

open FILE1,$trans_gtf_file;
while(<FILE1>)
{
	chomp;
	next if /^#/;
	my ($type,$str)=(split(/\t/,$_))[3-1,9-1];
	$str=~/gene_id \"(.*?)\";/;
	my $name1=$1;
	my $name2="";
	my $g_id="";
	if($type eq "transcript" or $type eq "exon")
	{
		$str=~/transcript_id \"(.*?)\";/;
		$name2=$1;
		$name2=~s/\.\d+$//;
		$str=~/gene_id \"(.*?)\";/;
		$g_id=$1;
	}
	#foreach my $line (keys %hash)
	{
		if(exists $hash{$name1} or exists $hash{$name2})
		{
			$hash{$g_id}++;
			#print $_,"\n";
		}
	}
}
close FILE1;


open FILE1,$trans_gtf_file;
while(<FILE1>)
{
	chomp;
	next if /^#/;
	my ($type,$str)=(split(/\t/,$_))[3-1,9-1];
	$str=~/gene_id \"(.*?)\";/;
	my $name1=$1;
	my $name2="";
	my $g_id="";
	if($type eq "transcript" or $type eq "exon")
	{
		$str=~/transcript_id \"(.*?)\";/;
		$name2=$1;
		$name2=~s/\.\d+$//;
		$str=~/gene_id \"(.*?)\";/;
		$g_id=$1;
	}
	#foreach my $line (keys %hash)
	{
		if(exists $hash{$name1} or exists $hash{$name2})
		{
			#$hash{$g_id}++;
			print $_,"\n";
		}
	}
}
close FILE1;

#Chr1	stringtie	gene	258717	258963	.	-	.	gene_id "Athlnc.64";
#Chr1	stringtie	transcript	258717	258963	.	-	.	gene_id "Athlnc.64"; transcript_id "AT1G04037.1";
#Chr1	StringTie	exon	258717	258963	1000	-	.	gene_id "Athlnc.64"; transcript_id "AT1G04037.1"; exon_number "1"; ref_gene_id "AT1G04037"; 
#Chr1	stringtie	gene	2397442	2400527	.	-	.	gene_id "Athlnc.640";