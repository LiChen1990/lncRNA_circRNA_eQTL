use strict;
use warnings;

my $gff=$ARGV[0];
open FILE,$gff;
while(<FILE>)
{
	chomp;
	my ($chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str)=split(/\t/,$_);
	if($type eq "gene")
	{
		$str=~/ID=(.*);Name=(.*)/;
		my $str1="gene_id \"$1\"; gene_name \"$2\";";
		print join("\t",$chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str1),"\n";
	}
	if($type eq "transcript")
	{
		$str=~/ID=(.*);Name=(.*);Parent=(.*)/;
		my $str1="gene_id \"$3\"; transcript_id \"$2\";";
		print join("\t",$chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str1),"\n";
	}
	if($type eq "exon")
	{
		$str=~/ID=(.*);Parent=(.*)/;
		my $trans_id=$2;
		my $gene_id=$trans_id;
		$gene_id=~s/\.\d+$//;
		my $str1="gene_id \"$gene_id\"; transcript_id \"$trans_id\";";
		print join("\t",$chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str1),"\n";
	}
}
close FILE;