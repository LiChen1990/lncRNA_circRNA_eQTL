use strict;
use warnings;



my $orf_list_file=$ARGV[0] || 'H:\LncRNA\lncRNA_identification\pipeline_hisat2_stringtie\identification_lncRNA\ORF_find\orf_list.txt';
my $db_filter_list_file=$ARGV[1]|| 'H:\LncRNA\lncRNA_identification\pipeline_hisat2_stringtie\identification_lncRNA\filter_db\db_filter_list.txt';
my $coding_p_list_file=$ARGV[2] || 'H:\LncRNA\lncRNA_identification\pipeline_hisat2_stringtie\identification_lncRNA\coding_potenial\COME_results\CP_list.txt';


my @list_orf=&load_list_from_file($orf_list_file);
my @list_db_filter=&load_list_from_file($db_filter_list_file);
my @list_cp=&load_list_from_file($coding_p_list_file);

my @list1=&set_A_common_set_B(\@list_orf,\@list_cp);
my @list2=&set_A_minus_set_B(\@list1,\@list_db_filter);

foreach (sort @list2)
{
	print $_,"\n";
}

sub  set_A_minus_set_B
{
	my ($listA,$listB)=@_;
	my %listB=map{$_=>1} @$listB;
	my @list=grep {!$listB{$_}} @$listA;
	return @list;
}

sub set_A_plus_set_B
{
	my ($listA,$listB)=@_;
	my %hash=();
		foreach (@$listA)
	{
		$hash{$_}=1;
	}
	foreach (@$listB)
	{
		$hash{$_}=1;
	}
	return keys %hash;
}


sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}

sub  set_A_common_set_B
{
	my($listA,$listB)=@_;
	my %hash_A;
	my %hash_B;
	my @list;
	foreach (@$listA)
	{
		$hash_A{$_}=1;
	}
	foreach (@$listB)
	{
		$hash_B{$_}=1;
	}
	foreach my $key(keys %hash_A)
	{
		if( exists $hash_B{$key})
		{
		  push(@list,$key);
		}
	}
	return @list;
}
