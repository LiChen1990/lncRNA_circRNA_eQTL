use strict;
use warnings;


my $file=$ARGV[0] || "flower_lncRNA_type.txt";
open FILE,$file;
while(<FILE>)
{
	chomp;
	my ($name,$str)=(split(/\t/,$_))[1-1,4-1];
	$str=~/(.*):/;
	if($1 eq "ChrC" or $1 eq "ChrM")
	{
		print $name,"\n";
	}
}

close FILE;