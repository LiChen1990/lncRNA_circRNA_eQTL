use strict;
use warnings;


my $lincRNA=$ARGV[1] || 'lincRNA_class.txt';
my $intron_lncRNA=$ARGV[2] || 'intron_lncRNA_parentgene.txt';
my $antisense=$ARGV[3] ||'antisenselncRNA_type.txt';
my $gff3_lncRNA=$ARGV[4] || 'final_candidate_lncRNA.gff3';
my $DE_res=$ARGV[0]|| '';

my %hash_linc=();
my %hash_linc1=();
my %hash_linc2=();
my %hash_linc3=();
open FILE,$lincRNA;
while(<FILE>)
{
	chomp;
my ($lncname,$type,$neigh_gene,$g1,$g2)=(split(/\t/,$_))[2-1,10-1,9-1,1-1,3-1];
$hash_linc{$lncname}=$type;
$hash_linc1{$lncname}=$neigh_gene;
$hash_linc2{$lncname}=join(",",$g1,$g2);
$hash_linc3{$lncname}=$type;
}
close FILE;

my %hash_intr=();
my %hash_intr1=();
open FILE,$intron_lncRNA;
while(<FILE>)
{
	chomp;
my ($lncname,$type,$g_name)=(split(/\t/,$_))[1-1,4-1,3-1];
$hash_intr{$lncname}=$type;
$hash_intr1{$lncname}=$g_name;
}
close FILE;

my %hash_anti=();
my %hash_anti1=();
open FILE,$antisense;
while(<FILE>)
{
	chomp;
my ($lncname,$type,$g_name)=(split(/\t/,$_))[1-1,4-1,3-1];
$hash_anti{$lncname}=$type;
$hash_anti1{$lncname}=$g_name;
}
close FILE;

my %hash_sense=();
my %hash_sense1=();
#open FILE,$sense;
#while(<FILE>)
#{
#	chomp;
#my ($lncname,$type,$g_name)=(split(/\t/,$_))[1-1,3-1,2-1];
#$hash_sense{$lncname}=$type;
#$hash_sense1{$lncname}=$g_name;
#}
#close FILE;


my %hash_pos=();
open FILE,$gff3_lncRNA;
while(<FILE>)
{
	chomp;
	my ($chrom,$type,$start,$end,$strand,$str)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,7-1,9-1];
	$str=~/ID=(.*?);/;
	my $id_name=$1;
	my $name2="";
	if($type eq "transcript")
	{
		$str=~/Name=\"(.*?)\";/;
		$name2=$1;
		$name2=~s/\.\d+$//;
	}
	$hash_pos{$name2}=join("\t",$chrom,$start,$end,$strand);
	$hash_pos{$id_name}=join("\t",$chrom,$start,$end,$strand);
}
close FILE;

open FILE,$DE_res;
while(<FILE>)
{
	chomp;
	my ($genename)=(split(/\t/,$_))[1-1];
	if(exists $hash_pos{$genename})
	{
	my ($chrom,$start,$end,$strand)=split(/\t/,$hash_pos{$genename});
	my $str1=$chrom.":".$start."-".$end;
	my $str2=$chrom.":".$start."..".$end;
	if(exists $hash_linc{$genename})
	{
		print $_,"\t",$str1,"\t",$str2,"\t","lincRNA\t",$hash_linc{$genename},"\t",$hash_linc1{$genename}, "\t",$hash_linc2{$genename},"\n";
		next;
	}
	
		if(exists $hash_anti{$genename})
	{
		#print $hash_anti{$genename},"\t",$_,"\n";
		print $_,"\t",$str1,"\t",$str2,"\t","antisenselncRNA\t",$hash_anti{$genename},"\t",$hash_anti1{$genename},"\t",$hash_anti1{$genename},"\n";
		next;
	}
	
		if(exists $hash_intr{$genename})
	{
		#print $hash_intr{$genename},"\t",$_,"\n";
		print $_,"\t",$str1,"\t",$str2,"\t","introniclncRNA\t",$hash_intr{$genename},"\t",$hash_intr1{$genename},"\t",$hash_intr1{$genename},"\n";
		next;
	}
 
 		if(exists $hash_sense{$genename})
	{
		#print $hash_intr{$genename},"\t",$_,"\n";
		print $_,"\t",$str1,"\t",$str2,"\t","senselncRNA\t",$hash_sense{$genename},"\t",$hash_sense1{$genename},"\t",$hash_sense1{$genename},"\n";
		
	}
  else
  {
  	print $_,"\t",$str1,"\t",$str2,"\t","other","","\t","","\t","","\n";
  }
	}
	else
	{
		print  $genename ,"\n";
	}
	
}