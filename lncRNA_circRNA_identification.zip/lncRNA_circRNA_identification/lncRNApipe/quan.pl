use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path= $Bin;
my $pwd=cwd;
my $bin_name=$0;

my $genome_file="";###genome_index_name
my $config_fileSE="";
my $config_filePE="";
my $gtf_file="";
my $debug;
my %hash_config=();
my $thread_num;
my $averfileSE="";
my $averfilePE="";
my $suffixname="";
my $cDNAlincfile="";

GetOptions(
          "debug!"=>\$debug,
          "confSE=s"=>\$config_fileSE,
          "confPE=s"=>\$config_filePE,
          "genome=s"=>\$genome_file,
          "thread=i"=>\$thread_num,
          "averfileSE=s"=>\$averfileSE,
          "averfilePE=s"=>\$averfilePE,
          "gtf_file=s"=>\$gtf_file,
          "cDNAlinc=s"=>\$cDNAlincfile,
          "suffix=s"=>\$suffixname
);


&command_system_cd(qq( PE ),$debug);
&command_system(qq(perl  /mnt/h/Linux/RNA-seqKallisto/kallisto-PE.pl  --conf  ../$config_filePE   --genome  $cDNAlincfile     --averfile  ../$averfilePE   --thread 3  &  ),$debug);
&command_system_cd(qq( ../SE ),$debug);
&command_system(qq(perl  /mnt/h/Linux/RNA-seqKallisto/kallisto-SE.pl  --conf  ../$config_fileSE   --genome  $cDNAlincfile     --averfile  ../$averfileSE   --thread 3  &  ),$debug);


sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}

sub command_system_cd
{
	my ($command,$bool_exec)=@_;
	print "cd  ",$command,"\n";
	chdir($command) if not $bool_exec;
}