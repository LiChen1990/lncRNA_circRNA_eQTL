use strict;
use warnings;

my $gtf_file=$ARGV[0] || 'trans_final_lncRNA.gtf';

open FILE,$gtf_file;
my %hash=();
my %hash1=();
my %hash2=();
my $gene_flag=0;
my $mRNA_flag=0;
my $gene_name="";
my $transcript="";

while(<FILE>)
{
	chomp;
	 my ($chrom,$type,$start,$end,$strand,$str)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,7-1,9-1];
	 #$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;	
	 if($type  eq "gene")
	 {
	 	$str=~/gene_id "(.*?)";/;
	 	$hash1{$1}=join("\t",$chrom,$start,$end,$strand);
		}
	 	if($type eq "transcript")
	 	{
	 		$mRNA_flag=1;
	 		$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
	 	   $gene_name=$1;
	 		 $transcript=$2;
	 		 $hash2{$gene_name}{$transcript}=join("\t",$chrom,$start,$end,$strand);
	 	}
	 	if($type eq "exon")
	 	{
	 		my $key=join("\t",$chrom,$start,$end,$strand);
	 		$hash{$gene_name}{$transcript}.=$key."||";
	 	}
}
close FILE ;


#Field	Description
#geneName	Name of gene
#isoformName	Name of isoform
#chrom	Reference sequence
#strand	+ or - for strand
#txStart	Transcription start position
#txEnd	Transcription end position
#cdsStart	Coding region start
#cdsEnd	Coding region end
#exonCount	Number of exons
#exonStarts	Exon start positions
#exonEnds	Exon end positions

my $seq="";

foreach my $key  (sort keys %hash)
{
	#my ($chrom,$start,$end,$strand)=split(/\t/,$hash1{$key});
	#print join("\t",$chrom,"stringtie","gene",$start,$end,".",$strand,".","ID=$key;Name=$key"),"\n";
	foreach my $key1 (sort keys %{$hash{$key}})
	{
		my $genename=$key;
		my $t_name=$key1;
		my @list=split(/\|\|/,$hash{$key}{$key1});
		my $exon_number=scalar @list;
		my @list_start=();
		my @list_end=();
		my ($tchrom,$tstart,$tend,$tstrand)=split(/\t/,$hash2{$genename}{$t_name});
		#print join("\t",$chrom,"stringtie","mRNA",$start,$end,".",$strand,".","ID=$key1;Name=$key1;Parent=$key"),"\n";
		foreach my $str (@list)
		{
			my ($chrom,$start,$end,$strand)=split(/\t/,$str);
			push(@list_start,$start);
			push(@list_end,$end);
			#print join("\t",$chrom,"stringtie","exon",$start,$end,".",$strand,".","ID=$key||$key1;Parent=$key1"),"\n";
		}
		print $genename,"\t",$t_name,"\t",$tchrom,"\t",$tstrand,"\t",$tstart-1,"\t",$tend,"\t",$tstart-1,"\t",$tend,"\t",$exon_number,"\t",join(",",@list_start),",\t",join(",",@list_end),",\n";
		}
}


#DDX11L1	uc001aaa.3	chr1	+	11873	14409	11873	11873	3	11873,12612,13220,	12227,12721,14409,
#DDX11L1	uc010nxr.1	chr1	+	11873	14409	11873	11873	3	11873,12645,13220,	12227,12697,14409,
#DDX11L1	uc010nxq.1	chr1	+	11873	14409	12189	13639	3	11873,12594,13402,	12227,12721,14409,
#WASH7P	uc009vis.3	chr1	-	14361	16765	14361	14361	4	14361,14969,15795,16606,	14829,15038,15942,16765,
#WASH7P	uc009vit.3	chr1	-	14361	19759	14361	14361	9	14361,14969,15795,16606,16857,17232,17914,18267,18912,	14829,15038,15947,16765,17055,17742,18061,18366,19759,
#WASH7P	uc009viu.3	chr1	-	14361	19759	14361	14361	10	14361,14969,15795,16606,16857,17232,17914,18267,18500,18912,	14829,15038,15947,16765,17055,17742,18061,18369,18554,19759,
#WASH7P	uc001aae.4	chr1	-	14361	19759	14361	14361	10	14361,14969,15795,16606,16857,17232,17605,17914,18267,18912,	14829,15038,15947,16765,17055,17368,17742,18061,18366,19759,
#WASH7P	uc001aah.4	chr1	-	14361	29370	14361	14361	11	14361,14969,15795,16606,16857,17232,17605,17914,18267,24737,29320,	14829,15038,15947,16765,17055,17368,17742,18061,18366,24891,29370,
#WASH7P	uc009vir.3	chr1	-	14361	29370	14361	14361	10	14361,14969,15795,16606,16857,17232,17914,18267,24737,29320,	14829,15038,15947,16765,17055,17742,18061,18366,24891,29370,
#WASH7P	uc009viq.3	chr1	-	14361	29370	14361	14361	7	14361,15795,16606,16857,17605,24737,29320,	14829,15947,16765,17055,18061,24891,29370,
