use strict;
use warnings;
use List::Util qw(first max maxstr min minstr reduce shuffle sum);


#perl  trans_cds_gtf_to_MSU_likegff3.pl   D:\data\noncoding\pm\fastq_scripts\gff3_gtf\circRNA_related_to_MSU_like_gff3\lncRNA_gtf\atRTD\trans_atRTDv3.gtf  >  atRTD_MSU_likegff3.gff3



my $gtf_file=$ARGV[0]  || "trans_atRTDv3.gtf";


open FILE , $gtf_file;
my %hash=();
my %hash1=();
my %hash2=();
my $gene_flag=0;
my $mRNA_flag=0;
my $gene_name="";
my $transcript="";
my %hash_cds=();

while(<FILE>)
{
	chomp;
	 my ($chrom,$type,$start,$end,$strand,$str)=(split(/\t/,$_))[1-1,3-1,4-1,5-1,7-1,9-1];
	 #$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;	
	 if($type  eq "gene")
	 {
	 	$str=~/gene_id "(.*?)";/;
	 	$hash1{$1}=join("\t",$chrom,$start,$end,$strand);
		}
	 	if($type eq "transcript")
	 	{
	 		$mRNA_flag=1;
	 		$str=~/gene_id "(.*?)"; transcript_id "(.*?)";/;
	 	   $gene_name=$1;
	 		 $transcript=$2;
	 		 $hash2{$gene_name}{$transcript}=join("\t",$chrom,$start,$end,$strand);
	 	}
	 	if($type eq "exon")
	 	{
	 		my $key=join("\t",$chrom,$start,$end,$strand);
	 		$hash{$gene_name}{$transcript}.=$key."||";
	 	}
#	 	if($type eq "CDS")
#	 	{
#	 		my $key=join("\t",$chrom,$start,$end,$strand);
#	 		$hash_cds{$gene_name}{$transcript}.=$key."||";
#	 	}
}
close FILE ;

my $seq="";
my $i=1;
my $j=1;

foreach my $key  (sort keys %hash)
{
	my ($chrom,$start,$end,$strand)=split(/\t/,$hash1{$key});
	print join("\t",$chrom,"stringtie","gene",$start,$end,".",$strand,".","ID=$key;Name=$key"),"\n";
	foreach my $key1 (sort keys %{$hash{$key}})
	{
		###for exon
		my @list=split(/\|\|/,$hash{$key}{$key1});
		print join("\t",$chrom,"stringtie","transcript",$start,$end,".",$strand,".","ID=$key1;Name=$key1;Parent=$key"),"\n";
		$i=1;
		$j=1;
		foreach my $str (@list)
		{
			my ($chrom,$start,$end,$strand)=split(/\t/,$str);
			print join("\t",$chrom,"stringtie","exon",$start,$end,".",$strand,".","ID=$key1:exon_$i;Parent=$key1"),"\n";
			$i++;
		}
		###for CDS
#		if(exists $hash_cds{$key}{$key1})
#		{
#			my @list1=split(/\|\|/,$hash_cds{$key}{$key1});
#			foreach my $str (@list1)
#			{
#				my ($chrom,$start,$end,$strand)=split(/\t/,$str);
#				print join("\t",$chrom,"cufflinks","CDS",$start,$end,".",$strand,".","ID=$key1:cds_$j;Parent=$key1"),"\n";
#				$j++;
#			}
#		}
	}
}






#$hash{'orange'}{'red'} = 'red orange';
#$hash{'orange'}{'green'} = 'green orange';
#$hash{'apple'}{'red'} = 'red apple';
#$hash{'apple'}{'green'} = 'green apple';
# 
#foreach $fruit (keys %hash)
#{
#    foreach $color (keys %{$hash{$fruit}})
#    {
#        print $hash{$fruit}{$color},"\n";
#    }
#}



sub get_genome_seq_return
{
	my($genome_hash,$id,$strand,$start,$end,$fasta_title)=@_;
	if(defined($fasta_title))
	{
		if($strand eq "+")
		{
			#print ">",$fasta_title,"\n";
			return substr($$genome_hash{$id},$start-1,$end-$start+1);
		}
		else
		{
			#print ">",$fasta_title,"\n";
			return &reverse_com(substr($$genome_hash{$id},$start-1,$end-$start+1));
		}
  }
  else
  {
		if($strand eq "+")
		{
			#print ">",$id,"_",$start,"_",$end,"_",$strand,"\n";
			return substr($$genome_hash{$id},$start-1,$end-$start+1);
		}
		else
		{
			#print ">",$id,"_",$start,"_",$end,"_",$strand,"\n";
			return &reverse_com(substr($$genome_hash{$id},$start-1,$end-$start+1));
		}  	
  }
}


sub reverse_com
{
	my ($seq)=@_;
	$seq= reverse $seq;
	$seq=~tr/ATCGatcg/TAGCtagc/;
	return $seq;
}