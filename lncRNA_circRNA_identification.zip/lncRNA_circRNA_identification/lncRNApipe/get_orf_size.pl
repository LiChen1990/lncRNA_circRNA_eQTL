use strict;
use warnings;


##perl get_orf_size.pl   filter_len_200_intergenic.gtf.fasta  120 200  filered
##perl  get_orf_size.pl  lncRNA_gene_seq.fasta   120 200  filered 
my $inputfile=$ARGV[0];##your input fasta  file
my $maxorflength=$ARGV[1] ||120;
my $mintslength=$ARGV[2] ||200;
my $outfile_name=$ARGV[3] || "test";
my $pep_fasta=$ARGV[4] || "output_pep.fasta";

	my %oriseqhash=&getOriSeqinfo($inputfile);
	print "processing transcript length/ORF filter...\n";
	print "----------------------------------------------------------\n\n";
	#transcript length/ORF filter
	my $tslorf=$outfile_name."_RNAlen_ORFlen_info.txt";
	my $lenfilterleftseqfile=$outfile_name."_lenfilterleft.fa";
	open LENOUT,">$tslorf" || die "Cannot create result file:$!";
	open LEFTOUT,">$lenfilterleftseqfile" || die "Cannot create result file:$!";
	open PEP,">$pep_fasta";
	print LENOUT "seqname\ttranscriptlen\tORF1\tORF2\tORF3\trevORF1\trevORF2\trevORF3\n";
	while (my ($tkey,$tvalue)=each(%oriseqhash)){
		my $toutstr=$tkey;
		$toutstr.="\t".length($tvalue);
		my $checkstr=&checkprotein(translate_frame($tvalue, 1));
		my $checkstr2=&checkprotein(translate_frame($tvalue, 2));
		my $checkstr3=&checkprotein(translate_frame($tvalue, 3));
		$toutstr.="\t".length($checkstr)."\t".length($checkstr2)."\t".length($checkstr3);
		my $revcom = revcom($tvalue);
		my $checkstr4=&checkprotein(translate_frame($revcom, 1));
		my $checkstr5=&checkprotein(translate_frame($revcom, 2));
		my $checkstr6=&checkprotein(translate_frame($revcom, 3));
		$toutstr.="\t".length($checkstr4)."\t".length($checkstr5)."\t".length($checkstr6);
		print LENOUT $toutstr."\n";
		
					print PEP ">${tkey}_ORF1\n";
			print PEP $checkstr,"\n";
						print PEP ">${tkey}_ORF2\n";
			print PEP $checkstr2,"\n";
						print PEP ">${tkey}_ORF3\n";
			print PEP $checkstr3,"\n";
						print PEP ">${tkey}_ORF4\n";
			print PEP $checkstr4,"\n";
						print PEP ">${tkey}_ORF5\n";
			print PEP $checkstr5,"\n";
						print PEP ">${tkey}_ORF6\n";
			print PEP $checkstr6,"\n";
			
			
		if(length($checkstr)>$maxorflength || length($checkstr2)>$maxorflength || length($checkstr3)>$maxorflength || length($checkstr4)>$maxorflength || length($checkstr5)>$maxorflength || length($checkstr6)>$maxorflength || length($tvalue)<$mintslength){
			$oriseqhash{$tkey}="";
		}else{
			print LEFTOUT ">".$tkey."\n".$tvalue."\n";

		}
	}
	close(LEFTOUT);
	close(LENOUT);
	close PEP;
	print "transcript length/ORF filter completed\n";
	print "----------------------------------------------------------\n\n";
	print "processing protein db filter...\n";
	print "----------------------------------------------------------\n\n";
	
	
sub getOriSeqinfo(){
	my $orifile=shift;
	my %resarr;
	open ORI,$orifile or die "Cannot open $orifile:$!";
	my $tstr;
	while($tstr=<ORI>){
		if(trim($tstr) ne "" && $tstr=~/>/){
			my @tarr=split(/\s+/,trim($tstr));
			my $tseqstr="";
			my $nstr="";
			while ($nstr=<ORI>){
				if($nstr=~/>/){
					my $tname=substr(trim($tarr[0]),1);
					$resarr{$tname}=$tseqstr;
					seek(ORI,-length($nstr),1);
					last;
				}else{
					$tseqstr.=trim($nstr);
				}
			}
		}
	}
	close(ORI);
	return %resarr;
}


sub codon2aa {
    my($codon) = @_;

    $codon = uc $codon;
 
    my(%genetic_code) = (
    
    'TCA' => 'S',    # Serine
    'TCC' => 'S',    # Serine
    'TCG' => 'S',    # Serine
    'TCT' => 'S',    # Serine
    'TTC' => 'F',    # Phenylalanine
    'TTT' => 'F',    # Phenylalanine
    'TTA' => 'L',    # Leucine
    'TTG' => 'L',    # Leucine
    'TAC' => 'Y',    # Tyrosine
    'TAT' => 'Y',    # Tyrosine
    'TAA' => '*',    # Stop
    'TAG' => '*',    # Stop
    'TGC' => 'C',    # Cysteine
    'TGT' => 'C',    # Cysteine
    'TGA' => '*',    # Stop
    'TGG' => 'W',    # Tryptophan
    'CTA' => 'L',    # Leucine
    'CTC' => 'L',    # Leucine
    'CTG' => 'L',    # Leucine
    'CTT' => 'L',    # Leucine
    'CCA' => 'P',    # Proline
    'CCC' => 'P',    # Proline
    'CCG' => 'P',    # Proline
    'CCT' => 'P',    # Proline
    'CAC' => 'H',    # Histidine
    'CAT' => 'H',    # Histidine
    'CAA' => 'Q',    # Glutamine
    'CAG' => 'Q',    # Glutamine
    'CGA' => 'R',    # Arginine
    'CGC' => 'R',    # Arginine
    'CGG' => 'R',    # Arginine
    'CGT' => 'R',    # Arginine
    'ATA' => 'I',    # Isoleucine
    'ATC' => 'I',    # Isoleucine
    'ATT' => 'I',    # Isoleucine
    'ATG' => 'M',    # Methionine
    'ACA' => 'T',    # Threonine
    'ACC' => 'T',    # Threonine
    'ACG' => 'T',    # Threonine
    'ACT' => 'T',    # Threonine
    'AAC' => 'N',    # Asparagine
    'AAT' => 'N',    # Asparagine
    'AAA' => 'K',    # Lysine
    'AAG' => 'K',    # Lysine
    'AGC' => 'S',    # Serine
    'AGT' => 'S',    # Serine
    'AGA' => 'R',    # Arginine
    'AGG' => 'R',    # Arginine
    'GTA' => 'V',    # Valine
    'GTC' => 'V',    # Valine
    'GTG' => 'V',    # Valine
    'GTT' => 'V',    # Valine
    'GCA' => 'A',    # Alanine
    'GCC' => 'A',    # Alanine
    'GCG' => 'A',    # Alanine
    'GCT' => 'A',    # Alanine
    'GAC' => 'D',    # Aspartic Acid
    'GAT' => 'D',    # Aspartic Acid
    'GAA' => 'E',    # Glutamic Acid
    'GAG' => 'E',    # Glutamic Acid
    'GGA' => 'G',    # Glycine
    'GGC' => 'G',    # Glycine
    'GGG' => 'G',    # Glycine
    'GGT' => 'G',    # Glycine
    );

    if(exists $genetic_code{$codon}) {
        return $genetic_code{$codon};
    }#else{

#            print STDERR "Bad codon \"$codon\"!!\n";
#            exit;
#    }
}

sub dna2peptide {

    my($dna) = @_;

    # Initialize variables
    my $protein = '';

    # Translate each three-base codon to an amino acid, and append to a protein 
    for(my $i=0; $i < (length($dna) - 2) ; $i += 3) {
        $protein .= codon2aa( substr($dna,$i,3) );
    }

    return $protein;
}

sub translate_frame {

    my($seq, $start, $end) = @_;

    my $protein;

    # To make the subroutine easier to use, you won't need to specify
    #  the end point-it will just go to the end of the sequence
    #  by default.
    unless($end) {
        $end = length($seq);
    }

    # Finally, calculate and return the translation
    return dna2peptide ( substr ( $seq, $start - 1, $end -$start + 1) );
}

# revcom 
#
# A subroutine to compute the reverse complement of DNA sequence

sub revcom {

    my($dna) = @_;

    # First reverse the sequence
    my $revcom = reverse $dna;

    # Next, complement the sequence, dealing with upper and lower case
    # A->T, T->A, C->G, G->C
    $revcom =~ tr/ACGTacgt/TGCAtgca/;

    return $revcom;
}

sub checkprotein(){
	my $tstr=shift;
	my $resstr="";
	my @tarr=split(/\*/,trim($tstr));
	my $maxlen=0;
	my $maxstr="NA";
	my $tpro="";
	pop(@tarr);
	foreach $tpro(@tarr){
		if(trim($tpro) ne ""){
			if(index($tpro,"M")!=-1){
				if($maxlen<length(trim($tpro))-index(trim($tpro),"M")){
					$maxlen=length(trim($tpro))-index(trim($tpro),"M");
					$maxstr=substr(trim($tpro),index(trim($tpro),"M"));
				}
			}
		}
	}
	$resstr=$maxstr;
	return $resstr;
}

sub trim(){
	my $string=shift;
	$string=~s/^\s+//;
	$string=~s/\s+$//;
	return $string;
}