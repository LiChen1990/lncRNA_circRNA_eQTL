use strict;
use warnings;


my $file=$ARGV[0] || 'strtcmp.lncRNA.gene.gff3.tmap';
my $file1=$ARGV[1] || "strtcmp.annotated.gtf";


my %hash_gene_name_2_id=();
open FILE,$file1;
while(<FILE>)
{
	chomp;
	next if /^#/;
	my ($chrom,$start,$end,$type,$strand,$str)=(split(/\t/,$_))[1-1,4-1,5-1,3-1,7-1,9-1];
	#GL000008.2	StringTie	transcript	1	15611	.	+	.	transcript_id "LCLlnc.1.1"; gene_id "LCLlnc.1"; xloc "XLOC_000001"; class_code "u"; tss_id "TSS1";
	if($type eq "transcript")
	{
		my %hash=();
	  my (@list)=split(/; /,$str);
	  foreach my $str1 (@list)
	  {
	  	$str1=~s/;$//;
	    my @list1=split(/ /,$str1);
	    $list1[1]=~s/\"//g;
	    $hash{$list1[0]}=$list1[1];
	  }
	  my $gene_id=&check_exists_hash("gene_id",%hash);
	  my $transcript_id=&check_exists_hash("transcript_id",%hash);
	  my $class_code=&check_exists_hash("class_code",%hash);
	  my $gene_name=&check_exists_hash("gene_name",%hash);
	  if($gene_name ne "")
	  {
	    $hash_gene_name_2_id{$gene_name}=$gene_id;
	  }
	  
	}
}
close FILE;



open FILE,$file;
my %hash=();
while(<FILE>)
{
	chomp;
	my ($genename,$type,$lncRNAname)=(split(/\t/,$_))[1-1,3-1,4-1];
	if($type eq "x")
	{
		#print $lncRNAname,"\t",$genename,"\t","antisenselncRNA_x\n";
		
		if(exists $hash_gene_name_2_id{$lncRNAname})
		{
		 $hash{join("\t",$hash_gene_name_2_id{$lncRNAname},$genename,"antisenselncRNA_x")}++;
		}
		else 
			{
		$hash{join("\t",$lncRNAname,$genename,"antisenselncRNA_x")}++;
			}
		
	}
}
close FILE;

foreach  (sort keys %hash)
{
	print $_,"\n";
}


sub  str2hash
{
	my ($str)=@_;
	my %hash=();
	  my (@list)=split(/; /,$str);
	  foreach my $str1 (@list)
	  {
	  	$str1=~s/;$//;
	    my @list1=split(/ /,$str1);
	    $list1[1]=~s/\"//g;
	    $hash{$list1[0]}=$list1[1];
	  }
	  return %hash;
}


sub  check_exists_hash
{
	my ($key,%hash)=@_;
	if(exists $hash{$key})
	{
	  return $hash{$key};
	}
	else
	{
		return "";
	}
}
