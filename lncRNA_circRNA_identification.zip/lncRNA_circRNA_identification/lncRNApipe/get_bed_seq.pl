use strict;
use warnings;

###perl  $0   non_exon_list.bed   D:\genome_date\rice\Osativa_204.fa  > seq.fasta  
my $bed_file_name=$ARGV[0];
my $genome_fasta=$ARGV[1] || "/datacenter/disk2/cl/RNA-seq/ok/all.fa";
###H:\LncRNA\lncRNA_identification\araidopsis\Athaliana_167.fa
my %hash=&create_hash_($genome_fasta);

open FILE1,$bed_file_name;
while(<FILE1>)
{
	chomp;
	my ($chrom,$start,$end,$name,$strand)=(split(/\t/,$_))[1-1,2-1,3-1,4-1,6-1];
	if($strand eq ".")
	{
		$strand="+";
	}
	if(exists $hash{$chrom})
	{
		my $seq=&get_genome_seq_return(\%hash,$chrom,$strand,$start+1,$end,$name);
		print ">$name\n";
		print $seq,"\n";
	}
}
close FILE1;
#print &get_genome_seq_return(\%hash,$chrom,$strand,$start,$end),"\n";


sub create_hash_
{
	my ($file)=@_;
	my %hash=();
	open FILE, $file;
	my $title;
	while(<FILE>)
	{
		chomp;
		if(/>(.*)/)
		{
			$title=$1;
		}
		else
		{
			$hash{$title}.=$_;
		}
	}
	close FILE;
	return %hash;
}

sub get_genome_seq_return
{
	my($genome_hash,$id,$strand,$start,$end,$fasta_title)=@_;
	if(defined($fasta_title))
	{
		if($strand eq "+")
		{
			#print ">",$fasta_title,"\n";
			return substr($$genome_hash{$id},$start-1,$end-$start+1);
		}
		else
		{
			#print ">",$fasta_title,"\n";
			return &reverse_com(substr($$genome_hash{$id},$start-1,$end-$start+1));
		}
  }
  else
  {
		if($strand eq "+")
		{
			#print ">",$id,"_",$start,"_",$end,"_",$strand,"\n";
			return substr($$genome_hash{$id},$start-1,$end-$start+1);
		}
		else
		{
			#print ">",$id,"_",$start,"_",$end,"_",$strand,"\n";
			return &reverse_com(substr($$genome_hash{$id},$start-1,$end-$start+1));
		}  	
  }
}


sub reverse_com
{
	my ($seq)=@_;
	$seq= reverse $seq;
	$seq=~tr/ATCGatcg/TAGCtagc/;
	return $seq;
}