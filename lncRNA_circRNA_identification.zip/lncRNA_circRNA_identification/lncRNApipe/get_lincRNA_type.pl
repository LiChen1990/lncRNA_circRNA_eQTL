use strict;
use warnings;
use File::Basename;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;
##perl get_lincRNA_type.pl  flower_lncRNA_type.txt   final_candidate_lncRNA_list.txt final_candidate_lncRNA.gff3   /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3  1  lincRNA_class.txt

my $file1=$ARGV[0] || 'flower_lncRNA_type.txt';
my $file2=$ARGV[1] || "final_candidate_lncRNA_list.txt";
my $file3=$ARGV[2] || 'final_candidate_lncRNA.gff3';
my $genome_ann_gff3=$ARGV[3] || "/home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3";
my $num_neigh_bour=$ARGV[4] || 1;
my $output_file=$ARGV[5] || "lincRNA_class.txt";
my $genome_fa=$ARGV[6] || "";

&command_system(qq(perl $bin_path/get_ChrC_ChrM_name_list.pl  flower_lncRNA_type.txt > ChrC_ChrM_name_list.txt ),0);
&command_system(qq(perl $bin_path/get_lincRNA_list_gff3.pl $file1 $file2 $file3 >  lincRNA.gene.gff3 ),0);
&command_system(qq(perl $bin_path/get_lincRNA_neighbour_genes_list.pl lincRNA.gene.gff3 $genome_ann_gff3 $num_neigh_bour  lincRNA_class.txt),0);
&command_system(qq(perl $bin_path/classify-lincRNA.pl lincRNA_class.txt >  lincRNA_class.classify.txt ),0);
&command_system(qq(perl  $bin_path/gff2bed.pl  lincRNA.gene.gff3   | sort -k1,1 -k2,2n >  lincRNA.bed ),0);
&command_system(qq(cut -f 4 lincRNA.bed | sort | uniq >lincRNA_list_loci.txt  ),0);
#&command_system(qq(perl $bin_path/get_lincRNA_seq.pl lincRNA_list_loci.txt final_candidate_lncRNA.gtf.transcripts.fasta > lincRNA_list_loci_seq.fasta),0);
&command_system(qq(perl $bin_path/get_longest_transcripts_lincRNAs.pl lincRNA_list_loci.txt final_candidate_lncRNA.gtf.transcripts.fasta > lincRNA_transcripts_seq.fasta),0);
&command_system(qq(perl  $bin_path/get_bed_seq.pl  lincRNA.bed  $genome_fa > lincRNA_list_loci_seq.fasta ),0);
&command_system(qq(perl  $bin_path/get_list_gff3.pl  lincRNA_list_loci.txt final_candidate_lncRNA.gff3  > final_candidate_lincRNA.gff3 ),0);
&command_system(qq(perl  $bin_path/gff2gtf.pl  final_candidate_lincRNA.gff3  > final_candidate_lincRNA.gtf  ),0);
&command_system(qq(perl  $bin_path/gtf2refFlat.pl final_candidate_lincRNA.gtf  > final_candidate_lincRNA.refFlat.txt ),0);
&command_system(qq(perl  $bin_path/gtf2refFlat.pl final_candidate_lncRNA.gtf  > final_candidate_lncRNA.refFlat.txt ),0);
&command_system(qq(perl  $bin_path/refFlat2bed12_format.pl final_candidate_lincRNA.refFlat.txt  > final_candidate_lincRNA.bed12 ),0);
&command_system(qq(perl  $bin_path/refFlat2bed12_format.pl final_candidate_lncRNA.refFlat.txt  > final_candidate_lncRNA.bed12  ),0);

sub command_system
{
	my ($command,$bool_exec)=@_;
	print "CMD::\t",$command,"\n";
	system($command) if not $bool_exec;
}