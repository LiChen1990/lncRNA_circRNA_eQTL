use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use Parallel::ForkManager;


my $genome_file="";###genome_index_name
my $config_file="";
my $gtf_file="";
my $debug;
my %hash_config=();
my $thread_num;


###perl RNA_seq_mapping_DE_PE_thread.pl --conf rice_PE__RNA_seq_conf.txt --gtf /datacenter/disk2/cl/RNA-seq/ok/all.gtf --genome /datacenter/disk2/cl/RNA-seq/ok/all --thread 3
###perl  $0  --debug --conf RNA_seq_confFile_mapping_DE.txt --gtf genome.gtf --genome genome.fa --thread 2
#��more!��        ���� ! ��ѡ����ձ���(Ҳ���ǽ����治��Ҫ�Ӳ��� �Cmore ��ʹ�þ�����),ֻҪ�������г������������,�ͻ�Ĭ���� 1 ,���������ô򿪺͹ص�һ�����ܵ�>.�����ڲ���ǰ�� no ��ɸ�������-nomore.
GetOptions(
          "debug!"=>\$debug,
          "conf=s"=>\$config_file,
          "genome=s"=>\$genome_file,
          "gtf=s"=>\$gtf_file,
          "thread=i"=>\$thread_num
);

my  $conf = Config::General->new($config_file);
%hash_config = $conf->getall;

my @list1=();
my @list1_bam=();


my $MAX_PROCESSES=$thread_num;
my $pm = new Parallel::ForkManager($MAX_PROCESSES); 



foreach my $sample_name (keys %{$hash_config{"sample"}})
{
	push(@list1,(split(/,/,$hash_config{"sample"}{$sample_name}))[0]);
}

####tophat cufflinks cuffmerge 
if($debug)######debug
{
		&batch_hisat_mapping_thread_lncRNA_SE($genome_file,\@list1,$gtf_file,1);
		#&compare_ref_gtf1($gtf_file,"stringtie_merged.gtf",1);
}
else
{
		&batch_hisat_mapping_thread_lncRNA_SE($genome_file,\@list1,$gtf_file);
		#&compare_ref_gtf1($gtf_file,"stringtie_merged.gtf");
}
unlink("gtf_file_list.txt");


foreach my $fastq_name (@list1)
{
  my ($name_1, $path_1, $suffix_1) = fileparse ($fastq_name, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));
  push(@list1_bam,qq($name_1.bam));
}


foreach my $bam_name (@list1_bam)
{
	$pm->start and next;
	if($debug)
	{
		&stringtie_express($bam_name,"stringtie_merged.gtf",1);
	}
	else
	{
		&stringtie_express($bam_name,"stringtie_merged.gtf");
	}
	$pm->finish;
}
$pm->wait_all_children;



sub  compare_ref_gtf
{
	my ($ref_gtf_file,$gtf_file,$bool_exec)=@_;
	my $command1=qq(cuffcompare -o  compare_ref_results -r $ref_gtf_file $gtf_file);
	print $command1,"\n";
	system($command1) if not $bool_exec;
}

sub  compare_ref_gtf1
{
	my ($ref_gtf_file,$gtf_file,$bool_exec)=@_;
	my $command1=qq(gffcompare -r $ref_gtf_file  -G -o  compare_ref_results  $gtf_file);
	print $command1,"\n";
	system($command1) if not $bool_exec;
}



sub batch_hisat_mapping_lncRNA_SE
{
	my ($genome_index_file,$ref_fastq_list1,$bool_exec)=@_;
		my $i=0;
		my $command="";
	for($i=0;$i<scalar @$ref_fastq_list1 ;$i++)
	{
		if( $bool_exec)
		{
		 &hisat_mapping_lncRNA_SE($genome_index_file,$$ref_fastq_list1[$i],1);
	  }
	  else
	  {
	  	&hisat_mapping_lncRNA_SE($genome_index_file,$$ref_fastq_list1[$i]);
	  }
	}
	if((not $bool_exec) and (-e  "${genome_index_file}.fa") )
	{
		$command=qq(cuffmerge  -s ${genome_index_file}.fa  -p 8 gtf_file_list.txt );
		print $command,"\n";
		system($command) if not $bool_exec;
	}
	if((not $bool_exec) and (-e  "${genome_index_file}.fasta") )
	{
		$command=qq(cuffmerge   -s ${genome_index_file}.fasta  -p 8 gtf_file_list.txt );
		print $command,"\n";
		system($command) if not $bool_exec;
	}
		if((not $bool_exec) and (-e  ${genome_index_file}) )
	{
		$command=qq(cuffmerge   -s ${genome_index_file}  -p 8 gtf_file_list.txt );
		print $command,"\n";
		system($command) if not $bool_exec;
	}
	$command=qq(cuffmerge  -s ${genome_index_file}.fasta  -p 8 gtf_file_list.txt );
		print $command,"FOR DEBUG TEST\n";
}


sub batch_hisat_mapping_thread_lncRNA_SE
{
	my ($genome_index_file,$ref_fastq_list1,$gtf_file,$bool_exec)=@_;
		my $i=0;
		my $command="";
		my $pm1 = new Parallel::ForkManager($MAX_PROCESSES);
	for($i=0;$i<scalar @$ref_fastq_list1 ;$i++)
	{
		$pm1->start and next;
		if( $bool_exec)
		{
		 &hisat_mapping_lncRNA_SE_gtf($genome_index_file,$$ref_fastq_list1[$i],$gtf_file,1);
	  }
	  else
	  {
	  	&hisat_mapping_lncRNA_SE_gtf($genome_index_file,$$ref_fastq_list1[$i],$gtf_file);
	  }
	  $pm1->finish;
	}
	$pm1->wait_all_children;
	
	$command=qq(stringtie --merge -p 8 -G $gtf_file -o stringtie_merged.gtf gtf_file_list.txt );
	print $command,"\n";
	system($command) if not $bool_exec;
	
}

sub hisat_mapping_lncRNA_SE_gtf
{
	my ($genome_index_file,$fastq_file1,$gtf_file,$bool_exec)=@_;
	my ($name_1, $path_1, $suffix_1) = fileparse ($fastq_file1, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));	
	my $command="";
	&hisat_mapping_SE_output_BAM1($fastq_file1,$genome_index_file,$bool_exec);
	&stringtie_gtf(qq(${name_1}.bam),$gtf_file,$bool_exec);
	#cuffmerge  -g genes.gtf  -s genome.fa -p 30 gtf_file_list.txt &
		$command=qq(find \$(pwd)  -name "${name_1}.gtf" >>gtf_file_list.txt );
	print $command,"\n";
	system($command) if not $bool_exec;	
}



sub  hisat_mapping_SE_output_BAM1
{
	my ($fastq1_file,$hisat_index,$bool_exec)=@_;
	my $command="";
	my ($name_1, $path_1, $suffix_1) = fileparse ($fastq1_file, (".fastq",".fq",".fastq.gz",".fq.gz",".fastq.bz2",".fq.bz2"));
	$command=qq(hisat2 -x $hisat_index -p 10  --dta <(gzip -dc $fastq1_file)  2> $name_1.mapping_stat.txt | samtools  view -hbuS - | samtools  sort -T ${name_1} -o  ${name_1}.bam  );
  &command_system_bash($command,$bool_exec);	
}

sub  stringtie
{
	my ($bam_file,$bool_exec)=@_;
	my $command="";
	my ($name_1, $path_1, $suffix_1) = fileparse ($bam_file, (".bam"));
	$command=qq(stringtie $bam_file -p  10  -o ${name_1}.gtf);
		print $command,"\n";
	system($command)  if not $bool_exec;	
}


sub  stringtie_gtf
{
	my ($bam_file,$gtf_file,$bool_exec)=@_;
	my $command="";
	my ($name_1, $path_1, $suffix_1) = fileparse ($bam_file, (".bam"));
	$command=qq(stringtie $bam_file -p  10  -G $gtf_file -o ${name_1}.gtf);
		print $command,"\n";
	system($command)  if not $bool_exec;	
}

sub stringtie_express
{
		my ($bam_file,$gtf_file,$bool_exec)=@_;
	my $command="";
	my ($name_1, $path_1, $suffix_1) = fileparse ($bam_file, (".bam"));
	$command=qq(stringtie $bam_file -e -B -p  10  -G $gtf_file -o ballgown/${name_1}/${name_1}.expvalue.gtf);
		print $command,"\n";
	system($command)  if not $bool_exec;	
}

sub command_system_bash
{
	my ($command,$bool_exec)=@_;
	my $num=int(rand()*100000000);
	open FILE,">$num.sh";
	print FILE $command,"\n";
	close FILE;
	print $command,"\n";
	system("bash $num.sh") if not $bool_exec;
	unlink("$num.sh");
}
