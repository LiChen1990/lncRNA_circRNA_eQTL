use strict;
use warnings;

## perl  merge_gtf_files.pl  v2.0_gtf.txt  cuffcompare 
##perl  merge_gtf_files.pl  gtf_file_list.txt  stringtie   /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3

my $gtf_file_list=$ARGV[0];
my $method=$ARGV[1]|| "stringtie";
my $ref_gtf_file=$ARGV[2] ;
my $lncRNA_name=$ARGV[3]|| "Atly";
my $genome_fasta=$ARGV[4];



##https://ccb.jhu.edu/software/stringtie/
###stringtie
###cuffmerge
###nbt

if($method eq "stringtie")
{
	if($ref_gtf_file ne "")
	{
		&stringtie_merge($gtf_file_list,$ref_gtf_file);
	}
	else
	{
		&stringtie_merge_noRef($gtf_file_list);
	}
}

if($method eq "cuffmerge")
{
	if(defined($ref_gtf_file) and  defined($genome_fasta))
	{
		&cuffmerge($gtf_file_list,$ref_gtf_file,$genome_fasta);
	}
	elsif(defined($ref_gtf_file) and  (not defined($genome_fasta)))
	{
		&cuffmerge_noFa($gtf_file_list,$ref_gtf_file);
	}
	else
	{
		&cuffmerge_noRef($gtf_file_list);
	}
}

if($method eq "taco")
{
	&taco($gtf_file_list);
}


if($method eq "cuffcompare")
{
		if($ref_gtf_file ne "")
	{
		&compare_ref_gtf($gtf_file_list,$ref_gtf_file,0);
	}
	else
	{
		&compare_ref_gtf_noRef($gtf_file_list,0);
	}
}

#&compare_ref_gtf($gtf_file_list,$ref_gtf_file,0);


sub stringtie_merge
{
	my ($gtf_file_list,$ref_gtf_file)=@_;
	##stringtie --merge  -G  /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3 -o stringtie_merged_v2.0.gtf v2.0_gtf.txt
	##stringtie --merge   -o stringtie_merged_v2.0.noRef.gtf v2.0_gtf.txt
	&command_system(qq(stringtie --merge  -l $lncRNA_name  -G  $ref_gtf_file -o stringtie_merged_v.gtf $gtf_file_list),0);
}


#Transcript merge usage mode: 
#  stringtie --merge [Options] { gtf_list | strg1.gtf ...}
#With this option StringTie will assemble transcripts from multiple
#input files generating a unified non-redundant set of isoforms. In this mode
#the following options are available:
#  -G <guide_gff>   reference annotation to include in the merging (GTF/GFF3)
#  -o <out_gtf>     output file name for the merged transcripts GTF
#                    (default: stdout)
#  -m <min_len>     minimum input transcript length to include in the merge
#                    (default: 50)
#  -c <min_cov>     minimum input transcript coverage to include in the merge
#                    (default: 0)
#  -F <min_fpkm>    minimum input transcript FPKM to include in the merge
#                    (default: 1.0)
#  -T <min_tpm>     minimum input transcript TPM to include in the merge
#                    (default: 1.0)
#  -f <min_iso>     minimum isoform fraction (default: 0.01)
#  -g <gap_len>     gap between transcripts to merge together (default: 250)
#  -i               keep merged transcripts with retained introns; by default
#                   these are not kept unless there is strong evidence for them
#  -l <label>       name prefix for output transcripts (default: MSTRG)
  

sub stringtie_merge_noRef
{
	my ($gtf_file_list)=@_;
	##stringtie --merge -o stringtie_merged_v2.0.noRef.gtf v2.0_gtf.txt
	&command_system(qq(stringtie --merge -l $lncRNA_name  -o stringtie_merged_noRef.gtf $gtf_file_list),0);
}

###http://cole-trapnell-lab.github.io/cufflinks/cuffmerge/

sub cuffmerge
{
	my ($gtf_file_list,$ref_gtf_file,$genome_fasta)=@_;
	##cuffmerge  -s ${genome_index_file}.fa  -p 8 gtf_file_list.txt 
	##merged.gtf
	##cuffmerge -p 8 -g /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3 -s /home/lichen/organism_db/araidopsis/Athaliana_167.fa -o merged_asm v2.0_gtf.txt
	##cuffmerge -p 8 -g /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3  -o merged_asm_noFa v2.0_gtf.txt
	&command_system(qq(cuffmerge -g $ref_gtf_file -o merged_asm  -s $genome_fasta -p 8 $gtf_file_list ),0);
}

sub cuffmerge_noFa
{
	my ($gtf_file_list,$ref_gtf_file)=@_;
	##cuffmerge  -s ${genome_index_file}.fa  -p 8 gtf_file_list.txt 
	##merged.gtf
	##cuffmerge -p 8 -g /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3 -s /home/lichen/organism_db/araidopsis/Athaliana_167.fa -o merged_asm v2.0_gtf.txt
	##cuffmerge -p 8 -g /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3  -o merged_asm_noFa v2.0_gtf.txt
	&command_system(qq(cuffmerge -g $ref_gtf_file -o merged_asm_noFa  -p 8 $gtf_file_list ),0);
}

#-rwxrwx---. 1 root vboxsf 4.6M Nov  7 14:37 genes.fpkm_tracking
#-rwxrwx---. 1 root vboxsf  14M Nov  7 14:37 isoforms.fpkm_trackingd
#rwxrwx---. 1 root vboxsf 4.0K Nov  5 14:27 logs
#-rwxrwx---. 1 root vboxsf 219M Nov  7 14:39 merged.gtf
#-rwxrwx---. 1 root vboxsf    0 Nov  7 14:34 skipped.gtf
#-rwxrwx---. 1 root vboxsf 212M Nov  7 14:37 transcripts.gtf

##http://www.nature.com/nmeth/journal/v14/n1/full/nmeth.4078.html
##http://tacorna.github.io/
##[lichen@flower 200samples]$ more  /home/lichen/lncRNA_project_chen/SRR1661473_1.gtf 
# stringtie SRR1661473_1.bam -p 10 -G /home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3 -o SRR1661473_1.gtf
# StringTie version 1.2.4
#Chr1	StringTie	transcript	3677	4165	1000	+	.	gene_id "STRG.1"; transcript_id "STRG.1.1"; cov "4.147420"; FPKM "3.405298"; TPM "4.243431";
#Chr1	StringTie	exon	3677	3913	1000	+	.	gene_id "STRG.1"; transcript_id "STRG.1.1"; exon_number "1"; cov "4.291139";
#Chr1	StringTie	exon	3996	4165	1000	+	.	gene_id "STRG.1"; transcript_id "STRG.1.1"; exon_number "2"; cov "3.947059";

sub cuffmerge_noRef
{
	my ($gtf_file_list)=@_;
	##cuffmerge  -s ${genome_index_file}.fa  -p 8 gtf_file_list.txt 
	##merged.gtf
	##cuffmerge -p 8 -g mm9.ensgene.gff -s mm9.fa -o merged_asm assemblies.txt
	##cuffmerge -p 8  -o merged_asm_onRef v2.0_gtf.txt
	&command_system(qq(cuffmerge -o cuffmerge_noRef -p 8 $gtf_file_list ),0);
}



sub taco
{
	my ($gtf_file_list)=@_;
	##./taco_run --gtf-expr-attr FPKM -o my_output_dir v2.0_gtf.txt
  ##./taco_ref_comp -o <output_directory> -r <reference_gtf> -t <test_gtf> --cpat (optional flag to run coding potential prediction)
  &command_system(qq(taco_run --gtf-expr-attr FPKM -p 3 -o output_dir_taco $gtf_file_list),0);
}



sub  compare_ref_gtf
{
	my ($gtf_file_list,$ref_gtf_file,$bool_exec)=@_;
	my @list=&load_list_from_file($gtf_file_list);
	my $str_str=qq(cuffcompare -o  compare_ref_results -r $ref_gtf_file  );
	&long_command($str_str,\@list)
	#my $command1=qq(cuffcompare -o  compare_ref_results -r $ref_gtf_file $str);
	#print $command1,"\n";
	#system($command1) if not $bool_exec;
}

sub  compare_ref_gtf_noRef
{
	my ($gtf_file_list,$bool_exec)=@_;
	my @list=&load_list_from_file($gtf_file_list);
	my $str_str=qq(cuffcompare -R  -o  compare_ref_results_noRef );
	&long_command($str_str,\@list)
}



 sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}

sub long_command
{
	my ($str,$ref_list)=@_;
	#cuffcompare -o  compare_ref_results -r $ref_gtf_file $str
	my @list=();
	foreach  (@$ref_list)
	{
		push(@list,"command+=\" ".$_." \"  ");
	}
	my $str1=join("\n",@list);
	
my $command= <<END;
command="$str"
$str1 
\$command

END
	open FILE,">long_command_bash.sh";
	print FILE $command,"\n";
	close FILE;
	system("bash  long_command_bash.sh");
}



sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}

