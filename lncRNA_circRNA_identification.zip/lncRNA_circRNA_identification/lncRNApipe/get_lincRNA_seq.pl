use strict;
use warnings;

my $listfile=$ARGV[0];
my $fasta=$ARGV[1];

my %hash=&create_hash_($fasta);
my @list=&load_list_from_file($listfile);

foreach (@list)
{
	if(exists $hash{$_})
	{
		print ">$_\n";
		print $hash{$_},"\n";
	}
}


sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}

sub create_hash_
{
	my ($file)=@_;
	my %hash=();
	open FILE, $file;
	my $title;
	while(<FILE>)
	{
		chomp;
		if(/>(.*)/)
		{
			my @list1=split(/ /,$1);
			$title=$list1[1];
		}
		else
		{
			$hash{$title}.=$_;
		}
	}
	close FILE;
	return %hash;
}