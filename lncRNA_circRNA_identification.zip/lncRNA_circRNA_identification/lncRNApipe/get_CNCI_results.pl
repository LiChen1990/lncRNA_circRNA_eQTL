use strict;
use warnings;

my $file=$ARGV[0];

my %hash=();
open FILE,$file;
while(<FILE>)
{
	chomp;
	next if $.==1;
	my ($id ,$type)=(split(/\t/,$_))[1-1,2-1];
	if($type eq "noncoding")
	{
		if($id=~/(.*)\.(\d+)/)
		{
		##MSTRG.10016.3
		$hash{$1}++;
		}
	}
}
close FILE;

foreach (sort keys %hash)
{
	print $_,"\n";
}



__DATA__
 python /mnt/hgfs/H/Linux/software/CNCI_package/CNCI.py -f /home/lichen/lncRNA_project_chen/lncRNA_v3.0/re_identification/pv1.2/candidate_TU.gtf.fasta -o output_dir -m pl  -p 8 

CNCI.index
Transcript ID	index	score	start	end	length
Atlnc.5175.1	noncoding	-0.0004096	Atlnc.5175	0	0
Atlnc.5742.1	noncoding	-0.0048153969428	Atlnc.5742	486	-0.0455102734931
Atlnc.4166.1	noncoding	-0.00428316885965	Atlnc.4166	516	0.194866837696
Atlnc.6571.1	noncoding	-0.0004096	Atlnc.6571	0	0
Atlnc.2750.1	noncoding	-0.0145321800595	Atlnc.2750	0	0.122702602142
Atlnc.4019.1	noncoding	-0.0313000801282	Atlnc.4019	48	0.0264478408246
Atlnc.3917.1	noncoding	-0.0004096	Atlnc.3917	0	0
Atlnc.2840.1	noncoding	-0.0226056134259	Atlnc.2840	0	0.368211579262
Atlnc.4970.1	coding	282.0	Atlnc.4970	225	0.0405732305738
Atlnc.3744.1	coding	1029.0	Atlnc.3744	867	0.0603362900175
Atlnc.3973.1	noncoding	-0.0004096	Atlnc.3973	0	0