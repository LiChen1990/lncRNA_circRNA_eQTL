use strict;
use warnings;

my $file=$ARGV[0] || "";
##https://genome.ucsc.edu/FAQ/FAQformat.html
##https://bedtools.readthedocs.io/en/latest/content/general-usage.html
#BED12: A BED file where each feature is described by all twelve columns listed above.
#For example: chr1 11873 14409 uc001aaa.3 0 + 11873 11873 0 3 354,109,1189, 0,739,1347,
#track name=pairedReads description="Clone Paired Reads" useScore=1
#chr22 1000 5000 cloneA 960 + 1000 5000 0 2 567,488, 0,3512
#chr22 2000 6000 cloneB 900 - 2000 6000 0 2 433,399, 0,3601
#
#The first three required BED fields are:
#
#chrom - The name of the chromosome (e.g. chr3, chrY, chr2_random) or scaffold (e.g. scaffold10671).
#chromStart - The starting position of the feature in the chromosome or scaffold. The first base in a chromosome is numbered 0.
#chromEnd - The ending position of the feature in the chromosome or scaffold. The chromEnd base is not included in the display of the feature, however, the number in position format will be represented. For example, the first 100 bases of chromosome 1 are defined as chrom=1, chromStart=0, chromEnd=100, and span the bases numbered 0-99 in our software (not 0-100), but will represent the position notation chr1:1-100. Read more here.
#The 9 additional optional BED fields are:
#
#name - Defines the name of the BED line. This label is displayed to the left of the BED line in the Genome Browser window when the track is open to full display mode or directly to the left of the item in pack mode.
#score - A score between 0 and 1000. If the track line useScore attribute is set to 1 for this annotation data set, the score value will determine the level of gray in which this feature is displayed (higher numbers = darker gray). This table shows the Genome Browser's translation of BED score values into shades of gray:
#shade	 	 	 	 	 	 	 	 	 
#score in range  	�� 166	167-277	278-388	389-499	500-611	612-722	723-833	834-944	�� 945
#strand - Defines the strand. Either "." (=no strand) or "+" or "-".
#thickStart - The starting position at which the feature is drawn thickly (for example, the start codon in gene displays). When there is no thick part, thickStart and thickEnd are usually set to the chromStart position.
#thickEnd - The ending position at which the feature is drawn thickly (for example the stop codon in gene displays).
#itemRgb - An RGB value of the form R,G,B (e.g. 255,0,0). If the track line itemRgb attribute is set to "On", this RBG value will determine the display color of the data contained in this BED line. NOTE: It is recommended that a simple color scheme (eight colors or less) be used with this attribute to avoid overwhelming the color resources of the Genome Browser and your Internet browser.
#blockCount - The number of blocks (exons) in the BED line.
#blockSizes - A comma-separated list of the block sizes. The number of items in this list should correspond to blockCount.
#blockStarts - A comma-separated list of block starts. All of the blockStart positions should be calculated relative to chromStart. The number of items in this list should correspond to blockCount.

open FILE,$file;
while(<FILE>)
{
	chomp;
	my ($g_name,$t_name,$chrom,$strand,$start1,$end1,$start2,$end2,$exon_num,$str_start,$str_end)=split(/\t/,$_);
	$str_start=~s/,$//;
	$str_end=~s/,$//;
	my @start=split(/,/,$str_start);
	my @end=split(/,/,$str_end);
	my @lens=();
	my @start_f=();
	for(my $i=0;$i<scalar @start;$i++)
	{
		push(@lens,$end[$i]-$start[$i]+1);
		push(@start_f,$start[$i]-$start1-1);
	}
	my $str_len=join(",",@lens);
	 $str_len =$str_len.",";
	my $str_start_f=join(",",@start_f);
	 $str_start_f =$str_start_f.",";
	print join("\t",$chrom,$start1,$end1,$t_name,0,$strand,$start1,$end1,0,$exon_num,$str_len,$str_start_f),"\n";
}
close FILE;
