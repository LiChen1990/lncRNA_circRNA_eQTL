use strict;
use warnings;

##perl get_orf_results_list.pl test_lenfilterleft.fa > orf.txt
my $file=$ARGV[0] || 'test_lenfilterleft.fa';
my %hash=&create_hash_($file);

foreach my $key (keys %hash)
{
  print $key,"\n";
}



sub create_hash_
{
	my ($file)=@_;
	my %hash=();
	open FILE, $file;
	my $title;
	while(<FILE>)
	{
		chomp;
		if(/>(.*)/)
		{
			$title=$1;
		}
		else
		{
			$hash{$title}.=$_;
		}
	}
	close FILE;
	return %hash;
}