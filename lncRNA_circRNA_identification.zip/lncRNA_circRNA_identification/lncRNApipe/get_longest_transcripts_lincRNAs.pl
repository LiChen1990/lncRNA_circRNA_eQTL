use strict;
use warnings;


my $lincRNA_list_file=$ARGV[0] ;
my $fasta_file=$ARGV[1] || "final_candidate_lncRNA.gtf.transcripts.fasta";

my @linc=&load_list_from_file($lincRNA_list_file);
my %hash=&create_hash_($fasta_file);
open FILE, $fasta_file;
my $title;
my ($t,$l_gene);

my %hash1=();
my %hash2=();
foreach (keys %hash)
{
	($t,$l_gene)=split(/ /,$_);
	$hash1{$l_gene}.=$hash{$_}.",";
	my $len=length($hash{$_});
	$hash2{$l_gene}.=$len.",";
}

my %hash3=();
foreach (keys %hash1)
{
	$hash2{$_}=~s/,$//;
	$hash1{$_}=~s/,$//;
	my @lens=split(/,/,$hash2{$_});
	my @list_seq=split(/,/,$hash1{$_});
	my $index_num=&mymax_index( @lens);
	$hash3{$_}=$list_seq[$index_num];
}

#my @list_test=(10,4,6,76,45,34);
#my $num=&mymax_index(@list_test);
#my $num1=&mymin_index(@list_test);
#
#print $num,"\n"; 3
#print $num1,"\n";1 


foreach (@linc)
{
	if(exists $hash3{$_})
	{
		print ">",$_,"\n";
		print $hash3{$_},"\n";
	}
}

sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}

sub create_hash_
{
	my ($file)=@_;
	my %hash=();
	open FILE, $file;
	my $title;
	while(<FILE>)
	{
		chomp;
		if(/>(.*)/)
		{
			$title=$1;
		}
		else
		{
			$hash{$title}.=$_;
		}
	}
	close FILE;
	return %hash;
}

sub mymin_index
{
	my (@list)=@_;
	my $min_val=$list[0];
	my $index_num=0;
	for(my $i=0; $i<scalar @list;$i++)
	{
		if($list[$i]< $min_val)
		{
			$min_val=$list[$i];
			$index_num=$i;
		}
	}
	return $index_num;
}


sub mymax_index
{
	my (@list)=@_;
	my $max_val=$list[0];
	my $index_num=0;
	for(my $i=0; $i<scalar @list;$i++)
	{
		if($list[$i]> $max_val)
		{
			$max_val=$list[$i];
			$index_num=$i;
		}
	}
	return $index_num;
}
