use strict;
use warnings;

my $file_lnc=$ARGV[0] || 'H:\LncRNA\lncRNA_identification\public_datasets\plant_genome_wide_lnc\all_ath_lncRNA\antisense_parentgene\antisense_lncRNA.bed';
my $file_g=$ARGV[1] || 'H:\LncRNA\lncRNA_identification\public_datasets\plant_genome_wide_lnc\all_ath_lncRNA\antisense_parentgene\g_bed.bed';
my $parent_file=$ARGV[2] || 'H:\LncRNA\lncRNA_identification\public_datasets\plant_genome_wide_lnc\all_ath_lncRNA\antisense_parentgene\antisense_lncRNA_parentgene.txt';
my $ratio_res=$ARGV[3] ||1;

my %hash_lnc=&bed_to_hash($file_lnc);
my %hash_g=&bed_to_hash($file_g);

open FILE1,$parent_file;
while(<FILE1>)
{
	chomp;
	my ($lncRNA_name,$t_id,$gene_name)=split(/\t/,$_);
	my ($lchrom,$lstart,$lend,$lstrand);
	my ($gchrom,$gstart,$gend,$gstrand);
	if(exists $hash_lnc{$lncRNA_name})
	{
		($lchrom,$lstart,$lend,$lstrand)=split(/\t/,$hash_lnc{$lncRNA_name});
	}
	else
	{
		next;
	}
	
	if(exists $hash_g{$gene_name})
	{
		($gchrom,$gstart,$gend,$gstrand)=split(/\t/,$hash_g{$gene_name});
	}
	else
	{
		next;
	}
	
	if($lstrand eq ".")
	{
		print $_,"\t",join("\t",$lstrand,$gstrand,0),"\t","antisenselncRNA.unknownstrand\n";
		next;
	}
	
	if($lstrand eq "+" and $gstrand eq "-" and $lstart<$gstart and $gstart<$lend and $lend <$gend)
	{
		my $ratio=($lend-$gstart)/($lend-$lstart);
		if($ratio<=$ratio_res)
		{
			print $_,"\t",join("\t",$lstrand,$gstrand,$ratio),"\t","antisense.convergent.terminator\n";
			next;
		}
	}
		if($lstrand eq "-" and $gstrand eq "+" and $gstart<$lstart and $lstart<$gend and $gend <$lend)
	{
		my $ratio=($gend-$lstart)/($lend-$lstart);
		if($ratio<=$ratio_res)
		{
			print $_,"\t",join("\t",$lstrand,$gstrand,$ratio),"\t","antisense.convergent.terminator\n";
			next;
		}
	}
	
	if($lstrand eq "-" and $gstrand eq "+" and $lstart<$gstart and $gstart<$lend and $lend <$gend)
	{
	my $ratio=($lend-$gstart)/($lend-$lstart);
		if($ratio<=$ratio_res)
		{
			print $_,"\t",join("\t",$lstrand,$gstrand,$ratio),"\t","antisense.divergent.promoter\n";
			next;
		}
	}
	
		if($lstrand eq "+" and $gstrand eq "-" and $gstart<$lstart and $lstart<$gend and $gend <$lend)
	{
		my $ratio=($gend-$lstart)/($lend-$lstart);
		if($ratio<=$ratio_res)
		{
			print $_,"\t",join("\t",$lstrand,$gstrand,$ratio),"\t","antisense.divergent.promoter\n";
			next;
		}
	}
	print $_,"\t",join("\t",$lstrand,$gstrand,"0"),"\t","antisense.other\n";
}


sub bed_to_hash
{
	my ($filename)=@_;
	open FILE,$filename;
	my %hash=();
	while(<FILE>)
	{
		chomp;
		my ($chrom,$start,$end,$name,$score,$strand)=split(/\t/,$_);
		$hash{$name}=join("\t",$chrom,$start,$end,$strand);
	}
	return %hash;
}