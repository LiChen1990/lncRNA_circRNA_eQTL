use strict;
use warnings;

my $file=$ARGV[0] || 'flower_lncRNA_type.txt';
my $file2=$ARGV[1] || "final_candidate_lncRNA_list.txt";
my $file1=$ARGV[2] || 'final_candidate_lncRNA.gff3';
my $file3=$ARGV[3] || "ChrC_ChrM_name_list.txt";


open FILE,$file2;
my %hash_e;
while(<FILE>)
{
	chomp;
	my ($name)=(split)[0];
	$hash_e{$name}++;
}
close FILE;


open FILE,$file3;
my %hash_x;
while(<FILE>)
{
	chomp;
	my ($name)=(split)[0];
	$hash_x{$name}++;
}
close FILE;


my %hash_antisenselncRNA_x=();
open FILE,$file;
while(<FILE>)
{
	chomp;
	my ($name,$type)=(split(/\t/,$_))[0,2];
	if($type eq "antisenselncRNA_x")
	{
		$hash_antisenselncRNA_x{$name}++;
	}
}
close FILE;


my %hash=();

open FILE,$file;
while(<FILE>)
{
	chomp;
	my ($name,$type)=(split(/\t/,$_))[0,2];
	#if(($type eq "lincRNA_p" or $type eq "lincRNA_u") and exists $hash_e{$name} and (not exists $hash_x{$name})  and (not exists $hash_antisenselncRNA_x{$name}) )
	if(($type eq "lincRNA_p" or $type eq "lincRNA_u") and exists $hash_e{$name} and (not exists $hash_x{$name})   )
	{
		$hash{$name}++;
	}
}
close FILE;

open FILE1,$file1;
while(<FILE1>)
{
	chomp;
	my ($str)=(split(/\t/,$_))[9-1];
	##gene_id "MSTRG.3884";
	##ID=MSTRG.21060;Name=MSTRG.21060
	$str=~/ID=(.*?);/;
	if(exists $hash{$1})
	{
		print $_,"\n";
	}
}