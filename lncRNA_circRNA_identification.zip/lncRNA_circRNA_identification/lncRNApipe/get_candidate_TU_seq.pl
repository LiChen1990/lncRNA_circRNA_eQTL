use strict;
use warnings;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path=$Bin;
my $pwd=cwd;
my $bin_name=$0;

##perl  get_candidate_TU_seq.pl   stringtie_merged_flower.gtf 

my $merged_gtf_file=$ARGV[0] || "stringtie_merged_v.gtf";
my $reference_ann_file=$ARGV[1] || "/home/lichen/organism_db/araidopsis/Athaliana_167_gene.gff3";
my $ref_genome_fasta=$ARGV[2] || "/home/lichen/organism_db/araidopsis/Athaliana_167.fa";

&command_system(qq(perl $bin_path/cmp_gtf_files.pl  $merged_gtf_file gffcompare $reference_ann_file ),0);
&command_system(qq(perl $bin_path/get_lncRNA_type_forgffcompare.pl  strtcmp.annotated.gtf > flower_lncRNA_type.txt),0);
&command_system(qq(perl $bin_path/get_candidate_TU_gtf.pl flower_lncRNA_type.txt  $merged_gtf_file>  candidate_TU.gtf ),0);
&command_system(qq(perl $bin_path/trinityrnaseq-Trinity-v2.4.0/util/cufflinks_gtf_genome_to_cdna_fasta.pl candidate_TU.gtf  $ref_genome_fasta  > candidate_TU.gtf.fasta ),0);


sub command_system
{
	my ($command,$bool_exec)=@_;
	print "CMD::\t",$command,"\n";
	system($command) if not $bool_exec;
}
