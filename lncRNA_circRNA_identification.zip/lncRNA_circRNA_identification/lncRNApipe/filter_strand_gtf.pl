use strict;
use warnings;

##
my $gtf_file=$ARGV[0] || "candidate_TU.gtf";
my $type=$ARGV[1] || "stringtie"; ##stringtie  taco cuffmerge

open FILE,$gtf_file;

while(<FILE>)
{
	chomp;
	next if /^#/;
	my ($chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str)=split(/\t/,$_);
	#$chrom=~s/Chr/chr/;
	if($strand eq ".")
	{
		##$strand="+";
		next;
	}
	if($chrom ne "chrC" or   $chrom ne "chrM")
	{
		#print join("\t",$chrom,@list),"\n";
		print join("\t",$chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str),"\n";
	}
}

close FILE;