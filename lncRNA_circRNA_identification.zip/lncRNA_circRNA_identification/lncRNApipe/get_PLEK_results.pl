use strict;
use warnings;

my $file=$ARGV[0];

my %hash=();
open FILE,$file;
while(<FILE>)
{
	chomp;
	#next if $.==1;
	my ($id ,$type)=(split(/\t/,$_))[3-1,1-1];
	$id=~s/^>//;
	if($type eq "Non-coding")
	{
		if($id=~/(.*)\.(\d+)/)
		{
		##MSTRG.10016.3
		$hash{$1}++;
		}
	}
}
close FILE;

foreach (sort keys %hash)
{
	print $_,"\n";
}



__DATA__
 python PLEKModelling.py -mRNA TAIR10_cds_20101214_updated.fasta   -lncRNA   lincRNA.gene.gff3.fasta   -prefix arab
 python PLEK.py   -range maize_ens_linli.range -model maize_ens_linli.model  -fasta PLEK_test.fa -out predicted -thread 10
[lichen@flower pv1.2]$ more  predicted 
Non-coding	-2.226330	>Atlnc.5175.1 Atlnc.5175
Non-coding	-1.187150	>Atlnc.5742.1 Atlnc.5742
Non-coding	-1.811150	>Atlnc.4166.1 Atlnc.4166
Non-coding	-2.337960	>Atlnc.6571.1 Atlnc.6571
Non-coding	-0.904321	>Atlnc.2750.1 Atlnc.2750
Non-coding	-2.057440	>Atlnc.4019.1 Atlnc.4019
Non-coding	-2.373530	>Atlnc.3917.1 Atlnc.3917