use strict;
use warnings;
use File::Basename;


##perl filter_DGE_genes_DESeq2.pl  DEFILE_list.txt  2  0.05   >  newdata_DEres.txt
my $file_list=$ARGV[0];
my $fc_min=$ARGV[1] || 2;
my $q_value_max=$ARGV[2] || 0.05;


my @list=&load_list_from_file($file_list);
##id	Stage0_vs_Stage4	DESeq2	log2FoldChange	pvalue	padj
print join("\t","id","Cmp_group","DE_method","log2FoldChange","pvalue","padj"),"\n";

foreach my $file (sort @list)
{
	#print "processing $file\n";
	&filter_file($file);
}

sub filter_file
{
	my ($file_name)=@_;
	##table_count.txt.Air_treatment_vs_E-vapor.edgeR.DE_results
	##gene_count_matrix.csv.ag-11_ap2-43_rep_vs_ag-11_rep.DESeq2.DE_results
	my ($name_1, $path_1, $suffix_1) = fileparse ($file_name, (".DE_results"));
	$name_1=~/txt\.(.*)\.(.*)$/;
	##print $name_1,"\n";
	my $comp=$1;
	my $method=$2;
	open FILE, $file_name;
	while(<FILE>)
	{
		chomp;
		if(/log2FoldChange/)
		{
			next;
		}
		my ($name,$fc,$p_value,$q_value)=(split(/\t/,$_))[1-1,7-1,10-1,11-1];
		if($q_value<=$q_value_max and ($fc<=-$fc_min or  $fc>=$fc_min) )
		{
			print $name,"\t",join("\t",$comp,$method,$fc,$p_value,$q_value),"\n";
		}
	}
	close FILE;
}

sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	return @list;
}


__DATA__
id	baseMeanA	baseMeanB	baseMean	log2FoldChange	lfcSE	stat	pvalue	padj
AT4G08950	0	2612.01004750307	1306.00502375153	8.56484290149686	0.280325416064056	30.5532156939339	5.12494486232377e-205	9.33303708877782e-201
AT3G04790	1498.51495363776	0	749.257476818878	-7.79237638057361	0.289950665584335	-26.8748352926512	4.3244384030001e-159	3.93761738785174e-155
AT2G34430	945.913845406639	0	472.95692270332	-7.2610382298061	0.295964657581442	-24.5334638572785	6.49419664479243e-133	3.9421938366105e-129
AT3G18420	544.923412141049	0	272.461706070525	-6.52527084263762	0.309422119488698	-21.088572637988	1.01271255665188e-98	4.61062709229683e-95
AT2G46510	617.555244475032	0	308.777622237516	-6.48543822759664	0.316758614534665	-20.4743862676761	3.64308077583469e-93	1.32688288017451e-89
AT4G32290	0	497.133365729042	248.566682864521	6.40614689342454	0.314638018042761	20.3603713666729	3.757251738323e-92	1.14038852344334e-88
AT3G24070	420.609351673644	0	210.304675836822	-6.22644863642828	0.313783395614442	-19.8431425099337	1.26311029461553e-87	3.28607165360621e-84
AT1G02000	0	417.60668869793	208.803344348965	6.2306035906375	0.316272587610108	19.7001062840085	2.15167909222802e-86	4.89802849357057e-83
AT1G69760	0	411.826787878035	205.913393939017	6.20228103125639	0.31714818203147	19.5564136345607	3.63781530311778e-85	7.36091716500865e-82