use strict;
use warnings;
use Getopt::Long;
use File::Basename;
use Config::General;
use FindBin qw($Bin);
use Cwd qw(cwd);


my $bin_path= $Bin;
my $pwd=cwd;
my $bin_name=$0;

my $genome_file="";###genome_index_name
my $config_fileSE="";
my $config_filePE="";
my $gtf_file="";
my $debug;
my %hash_config=();
my $thread_num;
my $averfile="";
my $suffixname="";

GetOptions(
          "debug!"=>\$debug,
          "confSE=s"=>\$config_fileSE,
          "confPE=s"=>\$config_filePE,
          "genome=s"=>\$genome_file,
          "thread=i"=>\$thread_num,
          "averfile=s"=>\$averfile,
          "gtf_file=s"=>\$gtf_file,
          "suffix=s"=>\$suffixname
);

&command_system(qq(mkdir SE ),$debug);
&command_system(qq(mkdir PE ),$debug);
command_system_cd("PE",$debug);

if(not $debug)
{
	&command_system(qq(perl  $bin_path/hisat2_stringtie_PE_thread_for_lncRNA_no_compare.pl  --conf  ../$config_filePE     --genome  $genome_file        --gtf  $gtf_file    --debug  >  run_PE.sh  ),$debug);
	&command_system(qq(bash  run_PE.sh    ),$debug);
	&command_system(qq(find \$(pwd) -maxdepth 2  -name "*mapping_stat.txt"  >  mapping.txt ),$debug);
	&command_system(qq(perl $bin_path/get_mapping_stat-PE.pl  mapping.txt  >  map.PE.data.txt ),$debug);
}
else
{
	&command_system(qq(perl  $bin_path/hisat2_stringtie_PE_thread_for_lncRNA_no_compare.pl  --conf  ../$config_filePE     --genome  $genome_file        --gtf  $gtf_file    --debug  >  run_PE.sh  ),$debug);
	&command_system(qq(find \$(pwd) -maxdepth 2  -name "*mapping_stat.txt"  >  mapping.txt ),$debug);
	&command_system(qq(perl $bin_path/get_mapping_stat-PE.pl  mapping.txt  >  map.PE.data.txt ),$debug);
}

command_system_cd("../SE",$debug);

if(not $debug)
{
	&command_system(qq(perl  $bin_path/hisat2_stringtie_SE_thread_for_lncRNA_no_compare.pl  --conf  ../$config_fileSE     --genome  $genome_file        --gtf  $gtf_file    --debug  >  run_SE.sh  ),$debug);
	&command_system(qq(bash  run_SE.sh  ),$debug);
	&command_system(qq(find \$(pwd) -maxdepth 2  -name "*mapping_stat.txt"  >  mapping.txt ),$debug);
	&command_system(qq(perl $bin_path/get_mapping_stat-SE.pl  mapping.txt  >  map.SE.data.txt ),$debug);
}
else
{
	&command_system(qq(perl  $bin_path/hisat2_stringtie_SE_thread_for_lncRNA_no_compare.pl  --conf  ../$config_fileSE     --genome  $genome_file        --gtf  $gtf_file    --debug  >  run_SE.sh  ),$debug);
	&command_system(qq(find \$(pwd) -maxdepth 2  -name "*mapping_stat.txt"  >  mapping.txt ),$debug);
	&command_system(qq(perl $bin_path/get_mapping_stat-SE.pl  mapping.txt  >  map.SE.data.txt ),$debug);
}

command_system_cd("../");
&command_system(qq(mkdir linc ),$debug);
command_system_cd("linc",$debug);


&command_system(qq(cat  ../SE/gtf_file_list.txt  ../PE/gtf_file_list.txt  >  gtffiles_all.txt   ),$debug);
&command_system(qq(xargs -n 10 -d '\\n' grep  -l "gene_id" < gtffiles_all.txt >   matched.list.txt ),$debug);


&command_system(qq(perl  $bin_path/merge_gtf_files.pl   matched.list.txt    stringtie     $gtf_file    $suffixname  ),$debug);
&command_system(qq(perl   $bin_path/process_strand_gtf.pl  stringtie_merged_v.gtf  > stringtie_merged_v_strand.gtf   ),$debug);

&command_system(qq(mkdir linc ),$debug);
command_system_cd("linc",$debug);

&command_system(qq(perl    $bin_path/get_final_candidate_lncRNA.pl  ../stringtie_merged_v_strand.gtf  $bin_path/db_filter_list.txt   $gtf_file  $genome_file     CPC2  > log2.txt  ),$debug);


sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}

sub command_system_cd
{
	my ($command,$bool_exec)=@_;
	print "cd  ",$command,"\n";
	chdir($command) if not $bool_exec;
}