use strict;
use warnings;


##perl  cmp_gtf_files.pl  stringtie_merged_v.gtf  gffcompare  /home/lichen/lncRNA_project_chen/lncRNA_v2.0/merge_all_lncRNA_mapping/Athaliana_167_gene.gff3
my $gtf_file=$ARGV[0] ;
my $ref_gtf_file=$ARGV[2] || '/home/lichen/lncRNA_project_chen/lncRNA_v2.0/merge_all_lncRNA_mapping/Athaliana_167_gene.gff3';
my $method=$ARGV[1] || 'gffcompare';
###taco_refcomp
###cuffcompare  #compare_ref_results.lncRNA.gene.gff3.tmap
###gffcompare  #strtcmp.annotated.gtf

if($method eq "gffcompare")
{
	&gffcompare($gtf_file,$ref_gtf_file);
}
if($method eq "taco_refcomp")
{
	&taco_ref_comp($gtf_file,$ref_gtf_file);
}
if($method eq "cuffcompare")
{
	&compare_ref_gtf($ref_gtf_file,$gtf_file,0);
}

###cmp gtf file with reference gtf

###cuffcmp
###stringcmp 
###bedtools

sub  gffcompare
{
	my ($gtf_file,$ref_gtf_file)=@_;
	#gffcompare -R -r mm10.gff -o cuffcmp cufflinks_asm.gtf
	# -R option is used here in order to adjust the sensitivity calculation as to only consider the "expressed" genes, which are those reference genes for which gffcompare found at least one overlapping transfrag in the given assembly data (*_asm.gtf file). 
	#https://ccb.jhu.edu/software/stringtie/gff.shtml#gffcompare
	&command_system(qq( gffcompare  -r $ref_gtf_file -o strtcmp  $gtf_file),0);
}

# strtcmp.combined.gtf
#   strtcmp.loci
#   strtcmp.stats
#   strtcmp.tracking
#   strtcmp.stringtie_asm.gtf.refmap
#   strtcmp.stringtie_asm.gtf.tmap

##lncRNA   i intronic lncRNA; linRNA p u ; anitisense lncRNA x s; sense lncRNA  e o  c  =;
##stringtie.ann.gtf lncRNA   i intronic lncRNA; linRNA p u ; anitisense lncRNA x s; sense lncRNA  e o ; 
#Class code	Description
#=	Predicted transcript has exactly the same introns as the reference transcript
#c	Predicted transcript is contained within the reference transcript
#j	Predicted transcript is a potential novel isoform that shares at least one splice junction with a reference transcript
#e	Predicted single-exon transcript overlaps a reference exon plus at least 10 bp of a reference intron, indicating a possible pre-mRNA fragment
#i	Predicted transcript falls entirely within a reference intron
#o	Exon of predicted transcript overlaps a reference transcript
#p	Predicted transcript lies within 2 kb of a reference transcript (possible polymerase run-on fragment)
#r	Predicted transcript has >50% of its bases overlapping a soft-masked (repetitive) reference sequence
#u	Predicted transcript is intergenic in comparison with known reference transcripts
#x	Exon of predicted transcript overlaps reference but lies on the opposite strand
#s	Intron of predicted transcript overlaps a reference intron on the opposite strand

##http://cole-trapnell-lab.github.io/cufflinks/cuffcompare/
sub  compare_ref_gtf
{
	my ($ref_gtf_file,$gtf_file,$bool_exec)=@_;
	my $command1=qq(cuffcompare -o  compare_ref_results -r $ref_gtf_file $gtf_file);
	print $command1,"\n";
	system($command1) if not $bool_exec;
}

##lncRNA   i intronic lncRNA; linRNA p u ; anitisense lncRNA x s; sense lncRNA  e o  c  =;
#Priority	Code	Description
#1	=	Complete match of intron chain
#2	c	Contained
#3	j	Potentially novel isoform (fragment): at least one splice junction is shared with a reference transcript
#4	e	Single exon transfrag overlapping a reference exon and at least 10 bp of a reference intron, indicating a possible pre-mRNA fragment.
#5	i	A transfrag falling entirely within a reference intron
#6	o	Generic exonic overlap with a reference transcript
#7	p	Possible polymerase run-on fragment (within 2Kbases of a reference transcript)
#8	r	Repeat. Currently determined by looking at the soft-masked reference sequence and applied to transcripts where at least 50% of the bases are lower case
#9	u	Unknown, intergenic transcript
#10	x	Exonic overlap with reference on the opposite strand
#11	s	An intron of the transfrag overlaps a reference intron on the opposite strand (likely due to read mapping errors)
#12	.	(.tracking file only, indicates multiple classifications)


##http://tacorna.github.io/
##gtf files
sub taco_ref_comp
{
	my ($gtf_file,$ref_gtf_file)=@_;
	##./taco_run --gtf-expr-attr FPKM -o my_output_dir list_of_files.txt
  ##./taco_ref_comp -o <output_directory> -r <reference_gtf> -t <test_gtf> --cpat (optional flag to run coding potential prediction)
  &command_system(qq(taco_refcomp -r $ref_gtf_file -t $gtf_file -o output_cmp_taco ),0);
}


   
 sub command_system
{
	my ($command,$bool_exec)=@_;
	print $command,"\n";
	system($command) if not $bool_exec;
}
