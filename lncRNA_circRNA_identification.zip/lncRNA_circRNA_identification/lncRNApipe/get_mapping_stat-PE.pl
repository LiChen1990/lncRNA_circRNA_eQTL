use strict;
use warnings;

my $file_list=$ARGV[0];
my @list=&load_list_from_file($file_list);

print join("\t","total_reads","aligned_concordantly_0_times","aligned_concordantly_0_times","aligned_concordantly_exactly_1_time","aligned_concordantly_exactly_1_time","aligned_concordantly_>1_times","aligned_concordantly_>1_times","overall_alignment_rate"),"\n";



foreach my $file_name ( @list )
{
	&process_file($file_name);
}


sub process_file
{
	my ($file_name)=@_;
	open FILE,$file_name;
	print $file_name,"\t";
	while(<FILE>)
	{
		chomp;
		
		if(/(\d+) reads; of these:/)
		{
			print $1,"\t";
		}
		if(/(\s*\d+) \((.*\%)\) aligned concordantly 0 times/)
		{
			print $1,"\t",$2,"\t";
		}
				if(/\s*(\d+) \((.*\%)\) aligned concordantly exactly 1 time/)
		{
			print $1,"\t",$2,"\t";
		}
				if(/\s*(\d+) \((.*\%)\) aligned concordantly >1 times/)
		{
			print $1,"\t",$2,"\t";
		}
		if(/(.*\%) overall alignment rate/)
		{
			 print $1,"\n";
		}
	}
	close FILE;
}


sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}




__DATA__
[lichen@flower chrX_data]$ more ERR188044_chrX_1.fastq.gz.mapping_stat.txt 
1321477 reads; of these:
  1321477 (100.00%) were paired; of these:
    112297 (8.50%) aligned concordantly 0 times
    998272 (75.54%) aligned concordantly exactly 1 time
    210908 (15.96%) aligned concordantly >1 times
    ----
    112297 pairs aligned concordantly 0 times; of these:
      4596 (4.09%) aligned discordantly 1 time
    ----
    107701 pairs aligned 0 times concordantly or discordantly; of these:
      215402 mates make up the pairs; of these:
        108730 (50.48%) aligned 0 times
        86195 (40.02%) aligned exactly 1 time
        20477 (9.51%) aligned >1 times
95.89% overall alignment rate

[lichen@flower chrX_data]$ find $(pwd) -name "*mapping_stat.txt"  
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188428_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188044_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188257_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188383_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188401_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR204916_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188104_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188454_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188234_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188337_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188245_chrX_1.fastq.gz.mapping_stat.txt
/home/lichen/lncRNA_test_cufflinks/human_data_test/chrX_data/ERR188273_chrX_1.fastq.gz.mapping_stat.txt
[lichen@flower chrX_data]$ find $(pwd) -name "*mapping_stat.txt"   > stat_file.list 


[lichen@flower data]$ more  /home/lichen/lncRNA_project_chen/lncRNA_v2.0/chip/datasets/at/data/SRR851694_1.mapping_stat.txt  
40853093 reads; of these:
  40853093 (100.00%) were unpaired; of these:
    13101461 (32.07%) aligned 0 times
    21212488 (51.92%) aligned exactly 1 time
    6539144 (16.01%) aligned >1 times
67.93% overall alignment rate


