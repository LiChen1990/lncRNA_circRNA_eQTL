use strict;
use warnings;


my @list=&load_list_from_file($ARGV[0]);
my $gff3_file=$ARGV[1] || "final_candidate_lncRNA.gff3";

my %hash1=();
my %hash2=();
my %hash3=();
open FILE,$gff3_file;
while(<FILE>)
{
	chomp;
	next if /^#/;
	my ($chrom,$source,$type,$start,$end,$score,$strand,$str1,$str2)=split(/\t/,$_);
	if($type eq "gene")
	{
#		if($str2=~/ID=(.*?);/)
#		{
#			$hash1{$1}=$_;
#		}
		my %hash=&str2hash($str2);
		$hash1{$hash{"ID"}}=$_;
	}
	if($type eq "transcript" or $type eq "mRNA")
	{
#		if($str2=~/ID=(.*?);.*Parent=(.*)/)
#		{
#			$hash2{$2}{$1}.=$_."//";
#		}
		my %hash=&str2hash($str2);
		$hash2{$hash{"Parent"}}{$hash{"ID"}}=$_;
	}
		if($type eq "exon")
	{
#		if($str2=~/ID=(.*?);.*Parent=(.*)/)
#		{
#			$hash3{$2}{$1}.=$_."//";
#		}
		my %hash=&str2hash($str2);
		$hash3{$hash{"Parent"}}{$hash{"ID"}}=$_;
	}
}
close FILE;


foreach  my $name (@list)
{
	if(exists $hash1{$name})
	{
		my $gene_str=$hash1{$name};
		print $gene_str,"\n";
			foreach my $key1 (keys %{$hash2{$name}})
			{
				my @list_mRNA=split(/\/\//,$hash2{$name}{$key1});
				foreach my $name1 (@list_mRNA)
				{
					print $name1,"\n";
					foreach my $key2 (keys %{$hash3{$key1}})
					{
						my @list_exon=split(/\/\//,$hash3{$key1}{$key2});
						foreach my $name2 (@list_exon)
						{
							print $name2,"\n";
						}
					}
				}
			}
		

	}
}


sub load_list_from_file
{
	my ($file_name)=@_;
	my @list=();
	open FILE,$file_name;
	while(<FILE>)
	{
		chomp;
		push(@list,$_);
	}
	close FILE;
	return @list;
}


sub  str2hash
{
	my ($str)=@_;
	my %hash=();
	  my (@list)=split(/;/,$str);
	  foreach my $str1 (@list)
	  {
	    my @list1=split(/=/,$str1);
	    $hash{$list1[0]}=$list1[1];
	  }
	  return %hash;
}

