use strict;
use warnings;

my $file=$ARGV[0] || 'antisense_parentgene.txt';
my $file1=$ARGV[1] || 'final_candidate_lncRNA_list.txt';
my $file2=$ARGV[2] || 'flower_lncRNA_type.txt';



my %hash=();

open FILE,$file1;
while(<FILE>)
{
	chomp;
	my ($name)=(split(/\t/,$_))[0];
	$hash{$name}++;
}
close FILE;


my %hash_intron=();
my %hash_lincRNA=();
my %hash_antisense=();
open FILE1,$file2;
while(<FILE1>)
{
	chomp;
	my ($g_id,$t_id,$type)=(split(/\t/,$_))[1-1,2-1,3-1];
	if($type eq "IntronicLnRNA_i")
	{
	 $hash_intron{$g_id}++;
	}
	
}
close FILE1;

open FILE1,$file2;
while(<FILE1>)
{
	chomp;
	my ($g_id,$t_id,$type)=(split(/\t/,$_))[1-1,2-1,3-1];
	if($type eq "lincRNA_p" or $type eq "lincRNA_u")
	{
	 $hash_lincRNA{$g_id}++;
	}
	
}
close FILE1;

open FILE1,$file2;
while(<FILE1>)
{
	chomp;
	my ($g_id,$t_id,$type)=(split(/\t/,$_))[1-1,2-1,3-1];
	if($type eq "antisenselncRNA_x" )
	{
	 $hash_antisense{$g_id}++;
	}
	
}
close FILE1;


my %hash_g=();
open FILE1,$file2;
while(<FILE1>)
{
	chomp;
	my ($g_id,$t_id,$type)=(split(/\t/,$_))[1-1,2-1,3-1];
	if(exists $hash_antisense{$g_id})
	{
	  next;
	}
	if(exists $hash{$t_id} and $type eq "IntronicLnRNA_i" and (not exists $hash_lincRNA{$g_id})  )
	{
	 $hash_g{$g_id}.=$t_id."||";
	}
	
}
close FILE1;

open FILE,$file;
while(<FILE>)
{
	chomp;
	my ($g_id,$partent_gene)=(split(/\t/,$_))[0,1];
	if(exists $hash_g{$g_id})
	{
	 $hash_g{$g_id}=~s/\|\|$//;
	 my @list=split(/\|\|/,$hash_g{$g_id});
	 foreach my $t_id (@list) 
	 {
	   print join("\t",$g_id,$t_id,$partent_gene,"IntronicLnRNA_i"),"\n";
	 }
	}
}
close FILE;

