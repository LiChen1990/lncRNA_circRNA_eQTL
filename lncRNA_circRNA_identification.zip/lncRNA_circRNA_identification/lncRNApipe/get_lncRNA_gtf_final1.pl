use strict;
use warnings;


my $list_file=$ARGV[0]|| 'H:\LncRNA\lncRNA_identification\pipeline_hisat2_stringtie\identification_lncRNA\final_results\final_lncRNA_list.txt';
my $gtf_file=$ARGV[1] || 'H:\LncRNA\lncRNA_identification\pipeline_hisat2_stringtie\identification_lncRNA\trans_stringtie_merged_v2.0.gtf';


open FILE,$list_file;
my %hash=();


while(<FILE>)
{
	chomp;
	my ($name)=split(/\t/,$_);
	$hash{$name}++;
}
close FILE;

open FILE1,$gtf_file;
while(<FILE1>)
{
	chomp;
	next if /^#/;
	my ($type,$str)=(split(/\t/,$_))[3-1,9-1];
	my $g_id="";
	my $t_id="";
	if($type eq "transcript" or $type eq "exon")
	{
		$str=~/transcript_id \"(.*?)\";/;
		$t_id=$1;
		$str=~/gene_id \"(.*?)\";/;
		$g_id=$1;
	}
	if(exists $hash{$t_id})
	{
	 print $_,"\n";
	}
}
close FILE1;

