use strict;
use warnings;


my $gff3_file=$ARGV[0] || 'H:\LncRNA\lncRNA_identification\chip-data\lncRNA_all_gene.gff3';
my $l=$ARGV[1] || 0;
my $r=$ARGV[2] || 0;

open FILE,$gff3_file;
while(<FILE>)
{
	chomp;
	my ($chrom,$sourc,$type,$start,$end,$x,$strand,$y,$str)=split(/\t/,$_);
	$str=~/ID=(.*?);/;
	my $id=$1;
	if($strand eq "+" or $strand eq ".")
	{
				my $ssss;
		if($start-1-$l<=0)
		{
		  $ssss=0;
		}
		else
		{
			$ssss=$start-1-$l;
		}
		print join("\t",$chrom,$ssss,$end+$r,$id,0,$strand),"\n";
	}
	else
	{
		my $ssss;
		if($start-1-$r<=0)
		{
		  $ssss=0;
		}
		else
		{
			$ssss=$start-1-$r;
		}
		print join("\t",$chrom,$ssss,$end+$l,$id,0,$strand),"\n";
	}
}
close FILE;